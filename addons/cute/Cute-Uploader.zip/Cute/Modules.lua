-- SPDX-License-Identifier: GPL-3.0-or-later
-- Modules: the window's pages and what joins them. Cute's core is the shell (the window and its tabs, the flat skin,
-- Settings, the guild channel, the roster, the policy, the stats registry and the knowledge model); every page
-- registers itself here, and the tabs and Settings' sections are drawn from this list:
--   C:RegisterModule({ id, title, order, page, settings, stats, events, officer, builtin, default, window, group, base })
--   page      function(ui, scroll): draws into its window's scroll area and band with the window's own pieces
--             (UI.Button, UI.Check, UI.Text, UI.FitText, the pools and virtual lists, ui:SetBand), so it looks like
--             one addon
--   window    the window its page is a tab of: "guild" (J, the default), "quests" (L), "map" (M)
--   group     its Settings section's group: "cute", "guild" or "quests" (by its window where not said)
--   base      always on (the quests window and its Route tab: no box, no choice)
--   settings  function(ui, column): its own section in Settings, drawn with the column Settings.lua hands it
--   stats     function(D): registry entries, D as Stats.lua's S.def; defined the first time the module is on in a
--             session and kept until the next login
--   events    { EVENT = function(...) }: heard while the module is on
--   officer   for officer ranks only: no tab and no section for members
-- Three kinds:
--   core      the dashboard (Race, Prog, Hall of Shame, Statistics, Officers, Me): always on, never listed
--   built-in  shipped inside Cute, switched on in Settings > Modules (the Guide, off on a fresh install)
--   external  an addon folder of its own whose toc says "## Dependencies: Cute" and "## X-Cute-Module: 1", ideally
--             "## LoadOnDemand: 1" and "## X-Cute-Title: <its primary's title>": listed in Settings > Modules from
--             the client's addon list (C_AddOns, documented
--             in Forever's AddOnsDocumentation.lua) and loaded with C_AddOns.LoadAddOn when switched on, no reload;
--             its files call Cute:RegisterModule as they load. Switched off, its tab, section and events go at once
--             and it is not loaded at the next login (Cute loads only what is on, and the game's AddOns list has it
--             off for this character)
-- The choice is per character (CuteDB.chars[me].modules, by module id or, for an external one, its folder). A module
-- addon whose toc says "## X-Cute-Base: 1" is the base, always on and loaded at every login (Cute_Quest: the quests
-- window with its Route tab). A change in Settings > Modules is staged (M.Stage) and applies on reload (M.Commit): the
-- engine's hooks on the world map, tooltips, minimap and taxi cannot be taken out by an addon, so a module switched in
-- play left a dead engine running; the reload path is the login's.
local _, C = ...
local M = { list = {}, byId = {}, found = {}, failed = {}, pending = {} }
C.Modules = M

-- Settings' own sections and the Settings tab: no module takes these ids
local RESERVED = { settings = true, general = true, vis = true, rules = true, modules = true, keys = true, columns = true, layout = true }
local WINDOWS = { guild = true, quests = true, map = true }

local function note(msg) C.Err.Note(msg, "modules") end
local function sortList()
  table.sort(M.list, function(a, b)
    if a.order ~= b.order then return a.order < b.order end
    return a.id < b.id
  end)
end

-- this character's choices: key = a module id, or an external module's folder; true or false, nil for its default
local function choices()
  local ch = C.Char()
  if type(ch.modules) ~= "table" then ch.modules = {} end
  return ch.modules
end

----------------------------------------------------------------------------
-- registering
----------------------------------------------------------------------------
function C:RegisterModule(def)
  if type(def) ~= "table" or type(def.id) ~= "string" or not def.id:match("^[%l%d_]+$") or #def.id > 24
    or type(def.title) ~= "string" or def.title == "" then
    note("a module without a lowercase id or a title was not registered")
    return false
  end
  local id = def.id
  if RESERVED[id] or M.byId[id] then note("module " .. id .. " was not registered: the id is taken"); return false end
  for _, k in ipairs({ "page", "settings", "stats" }) do
    if def[k] ~= nil and type(def[k]) ~= "function" then note("module " .. id .. " was not registered: " .. k .. " is no function"); return false end
  end
  if def.events ~= nil and type(def.events) ~= "table" then note("module " .. id .. " was not registered: events is no table"); return false end
  def.order = tonumber(def.order) or 100
  if def.window ~= nil and not WINDOWS[def.window] then note("module " .. id .. ": no window " .. tostring(def.window) .. ", the guild's"); def.window = nil end
  if not (def.core or def.builtin) then
    -- an external module: the folder it came from, as it says or as Cute is loading it now
    def.addon = type(def.addon) == "string" and def.addon or M.loading
    if not def.addon then note("module " .. id .. " was not registered: no addon folder named"); return false end
  end
  if def.addon then
    -- an addon's first module is its primary, keyed by the folder (Settings > Modules names the folder by its toc's
    -- X-Cute-Title, else its title, until it registers); the rest are keyed under it, each its own row and choice
    local first = true
    for _, d in ipairs(M.list) do if d.addon == def.addon then first = false end end
    def.primary = first
    def.key = first and def.addon or (def.addon .. ":" .. id)
  else
    def.key = id
  end
  if def.onToggle ~= nil and type(def.onToggle) ~= "function" then note("module " .. id .. " was not registered: onToggle is no function"); return false end
  def.active = def.core == true -- (the dashboard is on from the start; the rest as Apply finds them)
  M.byId[id] = def
  M.list[#M.list + 1] = def
  sortList()
  if M.started then M.Apply(def) end
  if C.UI and C.UI.frame and C.UI.frame:IsShown() then C.UI:Refresh() end
  return true
end

-- the one global Cute makes for module addons: Cute:RegisterModule({ ... }) from their own files, external always; and
-- what a module's pages need of the window and the core without reaching into them. Made where no other addon holds
-- the name (0.7.0 wrote over whatever was there): one that does keeps it, and /cute errors says so
local Cute = { version = C.version, isCute = true }
C.API = Cute
local held = _G.Cute
if held == nil or (type(held) == "table" and held.isCute) then _G.Cute = Cute
else C.Err.Note("another addon holds the global Cute: Cute's module addons cannot reach it", "modules") end
-- the one external module that starts on: Cute_Quest's Reminders (its camp module), so a character who answers the
-- first-run card "Not now" still gets them (the reminders design's section 6); every other default is dropped
local KEEPS_DEFAULT = { ["Cute_Quest:camp"] = true }
function Cute:RegisterModule(def)
  -- (an external module is never core nor built in, and starts off: a fresh install starts with the dashboard)
  if type(def) == "table" then
    local addon = type(def.addon) == "string" and def.addon or M.loading
    local keep = def.default == true and KEEPS_DEFAULT[tostring(addon) .. ":" .. tostring(def.id)] or nil
    def.core, def.builtin, def.default = nil, nil, keep
  end
  return C:RegisterModule(def)
end
function Cute.Open(page, section) C.UI:Open(page, section) end
function Cute.Refresh() if C.UI and C.UI.RefreshAll then C.UI.RefreshAll() end end
-- (merge3) Cute_Quest's reminders laid out again (Band.lua, after each refresh of Reminders): what the dashboard reads of
-- them may have changed (Stats.lua S.PullChanged: your own Ready while Before the pull shows something)
function Cute.QuestReadsChanged() if C.Stats and C.Stats.PullChanged then C.Stats.PullChanged() end end
-- a Settings section of a module addon's own, without a module (Settings.lua ST.Add)
function Cute.AddSection(def) return C.SettingsPage.Add(def) end
function Cute.Print(msg) C.Print(msg) end
function Cute.Page() return C.UI and C.UI.page or nil end
function Cute.ModuleOn(id) local def = M.byId[id]; return def ~= nil and def.active == true end
function Cute.Safe(fn, where) return C.Safe(fn, where) end
function Cute.Font() return C.UI and C.UI.FONT or "Fonts\\ARIALN.TTF" end
function Cute.Host(ui, key, side) return ui:Host(key, side) end
-- (the windows round) a column of its own on the window's right, w wide (UI:Side); its hosts: Cute.Host(ui, key, true)
function Cute.Side(ui, w) return ui:Side(w) end
-- (the windows round) a box of its own on the window's left that does not scroll, w wide (UI:LeftBox)
function Cute.LeftBox(ui, w) return ui:LeftBox(w) end
-- a window by key ("guild", "quests"): what a module's page draws in (Cute_Quest's step frame reads a quest in its own)
function Cute.Window(key) return C.UI and C.UI.Window(key) or nil end

----------------------------------------------------------------------------
-- on and off
----------------------------------------------------------------------------
-- whether a module (or an external module's folder, by key) is on for this character; the base always is
function M.OnKey(key, default)
  if M.Base(key) then return true end
  local v = choices()[key]
  if v == nil then return default == true end
  return v == true
end
function M.On(def)
  if def.core or def.base then return true end
  return M.OnKey(def.key, def.default)
end
-- the base: a module that says so, or the folder of a module addon whose toc says "## X-Cute-Base: 1"
function M.Base(key)
  for _, a in ipairs(M.found) do if a.base and a.name == key then return true end end
  for _, def in ipairs(M.list) do if def.key == key and def.base then return true end end
  return false
end
-- the folder of a key ("Cute_Quest:route" is Cute_Quest's)
local function folderOf(key) return key:match("^(.-):") or key end
-- is any of an addon's modules wanted by this character: the primary's key (the folder) or one keyed under it
function M.AddonWanted(name)
  if M.Base(name) then return true end
  for key, v in pairs(choices()) do if v == true and folderOf(key) == name then return true end end
  return false
end
-- is any of an addon's registered modules on
function M.AddonOn(name)
  for _, def in ipairs(M.list) do if def.addon == name and M.On(def) then return true end end
  return false
end

-- the stats a module defines, in Stats.lua's registry and read like the rest (Sample.lua adopts them once it runs)
local function defineStats(def)
  if def.statsDone or not def.stats then return end
  def.statsDone = true
  local new = {}
  def.stats(function(id, label, cat, o)
    local d = C.Stats.def(id, label, cat, o)
    d.module = def.id
    new[#new + 1] = d
    return d
  end)
  if #new > 0 and C.Sample and C.Sample.Adopt then C.Sample:Adopt(new) end
end

-- the module's live state made to match its choice: its stats (once a session) and its events
function M.Apply(def)
  local on = M.On(def)
  if on == def.active then return end
  def.active = on
  if def.onToggle then C.Safe(def.onToggle, "module " .. def.id .. ": toggle")(on) end
  if on then
    C.Safe(defineStats, "module " .. def.id .. ": stats")(def)
    if def.events and next(def.events) then
      if not def.frame then
        def.frame = CreateFrame("Frame")
        def.frame:SetScript("OnEvent", C.Safe(function(_, event, ...)
          local fn = def.active and def.events[event]
          if type(fn) == "function" then fn(...) end
        end, "module " .. def.id .. ": event"))
      end
      for event in pairs(def.events) do pcall(def.frame.RegisterEvent, def.frame, event) end
    end
  elseif def.frame then
    for event in pairs(def.events) do pcall(def.frame.UnregisterEvent, def.frame, event) end
  end
end

-- a module addon ticked (its own box, the folder's) that waits for combat to end before it loads, its modules not
-- registered yet (a page that stands in for one of them says so)
function M.Waiting()
  for name in pairs(M.pending) do
    if M.OnKey(name) and not M.byId[name] then
      local found = false
      for _, def in ipairs(M.list) do if def.addon == name then found = true end end
      if not found then return true end
    end
  end
  return false
end

-- a module whose page shows for this viewer: on, registered, and an officer's where it is for officers
function M.Page(id, officer)
  local def = M.byId[id]
  if def and def.page and def.active and (not def.officer or officer) then return def end
  return nil
end
-- the pages that show, in a window (window nil: every one)
function M.Pages(officer, window)
  local out = {}
  for _, def in ipairs(M.list) do
    if M.Page(def.id, officer) and (window == nil or (def.window or "guild") == window) then out[#out + 1] = def end
  end
  return out
end
-- the modules with a Settings section for this viewer
function M.Sections(officer)
  local out = {}
  for _, def in ipairs(M.list) do
    if def.settings and def.active and (not def.officer or officer) then out[#out + 1] = def end
  end
  return out
end

----------------------------------------------------------------------------
-- module addons: found in the client's addon list, loaded on demand
----------------------------------------------------------------------------
local function addons() return type(C_AddOns) == "table" and C_AddOns or nil end
-- the character the game's AddOns list keeps a choice for: the GUID, as the mainline client's own code passes it
-- (Blizzard_Minimap/Mainline/AddonCompartment.lua:79, GetAddOnEnableState(addonIndex, UnitGUID("player")))
local function character() return C.MyGUID() or C.Get(UnitName, "player") end
local function save()
  local A = addons()
  if A and type(A.SaveAddOns) == "function" then pcall(A.SaveAddOns) end
end
local function plainTitle(s, fallback)
  s = C.Plain(s)
  if type(s) ~= "string" or s == "" or C.IsKstring(s) then return fallback end
  s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
  return s ~= "" and s or fallback
end
-- does the addon at index i name Cute among its dependencies (where the client can say)
local function needsCute(A, i)
  if type(A.GetAddOnDependencies) ~= "function" then return true end
  local deps = { C.Get(A.GetAddOnDependencies, i) }
  for _, d in ipairs(deps) do if type(d) == "string" and d:lower() == "cute" then return true end end
  return false
end
-- every module addon the client lists: { name, title, notes, lod }. Asked once a session, at the first loading screen
-- (the list does not change while you play)
function M.Scan()
  local A, out = addons(), {}
  if not (A and type(A.GetNumAddOns) == "function" and type(A.GetAddOnInfo) == "function" and type(A.GetAddOnMetadata) == "function") then return out end
  local n = C.Num(A.GetNumAddOns) or 0
  for i = 1, math.min(n, 500) do
    local name, title, notes = C.Get(A.GetAddOnInfo, i)
    if type(name) == "string" and name ~= "" and name:lower() ~= "cute" and tonumber(C.Get(A.GetAddOnMetadata, i, "X-Cute-Module")) == 1 and needsCute(A, i) then
      -- (its row's title before it registers: "## X-Cute-Title", its primary's, else the toc's title, the AddOns list's)
      local own = plainTitle(C.Get(A.GetAddOnMetadata, i, "X-Cute-Title"), nil)
      out[#out + 1] = { name = name, title = own or plainTitle(title, name), notes = plainTitle(notes, nil),
        lod = type(A.IsAddOnLoadOnDemand) == "function" and C.Get(A.IsAddOnLoadOnDemand, i) == true,
        base = tonumber(C.Get(A.GetAddOnMetadata, i, "X-Cute-Base")) == 1 }
    end
  end
  table.sort(out, function(a, b) return a.title:lower() < b.title:lower() end)
  return out
end
function M.Found(name) for _, a in ipairs(M.found) do if a.name == name then return a end end end
local function loaded(name)
  local A = addons()
  return A and type(A.IsAddOnLoaded) == "function" and C.Get(A.IsAddOnLoaded, name) == true or false
end
local function registered(name) for _, def in ipairs(M.list) do if def.addon == name then return def end end end
-- the base's window, not registered yet but on its way: its addon waits for a fight's end to load (one that failed
-- to load, or that the client lacks, is no window: the card and the keys leave it out)
function M.BaseComing()
  for _, a in ipairs(M.found) do if a.base and M.pending[a.name] and not registered(a.name) then return true end end
  return false
end

-- the game's AddOns list for this character: on before Cute loads one (a module switched off before is off there),
-- off when it is switched off, so a module that is no LoadOnDemand one stays out at the next login too
local function enable(name, on)
  local A = addons()
  if not A then return end
  local me = character()
  if on then
    local state = type(A.GetAddOnEnableState) == "function" and C.Get(A.GetAddOnEnableState, name, me) or nil
    if type(state) == "number" and state > 0 then return end
    if type(A.EnableAddOn) == "function" and pcall(A.EnableAddOn, name, me) then save() end
  elseif type(A.DisableAddOn) == "function" and pcall(A.DisableAddOn, name, me) then save() end
end

-- the regen frame: a module switched on in combat loads when combat ends (loading one may make frames, and Cute
-- changes nothing secure in combat)
local regen
local function inCombat() return C.Callable("InCombatLockdown") and C.Get(InCombatLockdown) == true end
function M.Load(name)
  local A = addons()
  if not (A and type(A.LoadAddOn) == "function") then M.failed[name] = "C_AddOns.LoadAddOn is missing on this client"; return end
  if inCombat() then
    M.pending[name] = true
    if not regen then
      regen = CreateFrame("Frame")
      regen:SetScript("OnEvent", C.Safe(function()
        pcall(regen.UnregisterEvent, regen, "PLAYER_REGEN_ENABLED")
        for n in pairs(M.pending) do M.pending[n] = nil; if M.OnKey(n) then M.Load(n) end end
        -- (the keys count a window whose addon has loaded now, or has failed to: Keys.lua K.Windows)
        if C.Keys and C.Keys.started then C.Keys.Apply() end
        if C.UI and C.UI.frame and C.UI.frame:IsShown() then C.UI:Draw() end
      end, "modules: after combat"))
    end
    pcall(regen.RegisterEvent, regen, "PLAYER_REGEN_ENABLED")
    return
  end
  M.pending[name] = nil
  enable(name, true)
  if loaded(name) then return end
  M.loading, C.lastErr = name, nil
  local ok, why = C.Get(A.LoadAddOn, name)
  M.loading = nil
  if ok then M.failed[name] = nil
  else
    -- the client's own words for why, where it has them (ADDON_DISABLED, ADDON_MISSING...)
    local reason = type(why) == "string" and why or (C.lastErr or "unknown")
    local said = C.Plain(_G["ADDON_" .. reason])
    M.failed[name] = type(said) == "string" and said ~= "" and said or reason
    note("module " .. name .. " did not load: " .. M.failed[name])
  end
end

-- this character's choice set, and made true at once: a built-in module's tab, section and events come and go now; an
-- external one is loaded now (or after combat) and registers as it loads, and off it is off in the game's AddOns list
function M.Set(key, on)
  on = on and true or false
  choices()[key] = on
  for _, def in ipairs(M.list) do if def.key == key then M.Apply(def) end end
  local name = folderOf(key)
  if M.Found(name) then
    if on then if not registered(name) then M.Load(name) else enable(name, true) end
    elseif not M.AddonWanted(name) then M.pending[name] = nil; enable(name, false) end
  end
  -- (the redraw on its own: an error in it leaves the choice made and recorded under /cute errors)
  if C.UI and C.UI.frame and C.UI.frame:IsShown() then C.Safe(function() C.UI:Draw() end, "modules: set " .. key)() end
end

----------------------------------------------------------------------------
-- the reload rule: a box in Settings > Modules stages its change (the box shows it at once), and the change applies on
-- reload, where the login's one path loads what is on and leaves out what is off (Reload now, Undo; closing Settings
-- asks, Setup.lua). Keys, layout and every other setting apply at once
----------------------------------------------------------------------------
M.staged = {}
function M.InCombat() return inCombat() end
-- a box's value with its change staged
function M.StagedOn(key, on)
  local v = M.staged[key]
  if v == nil then return on end
  return v
end
function M.Stage(key, on)
  on = on and true or false
  local def
  for _, d in ipairs(M.list) do if d.key == key then def = d end end
  if on == M.OnKey(key, def and def.default) then M.staged[key] = nil else M.staged[key] = on end
end
function M.Staged() return next(M.staged) ~= nil end
-- a choice written for the next login, nothing applied now (the setup card's Start and M.Commit, each before a
-- reload): this character's choice, and a module addon on or off in the game's AddOns list as M.Set leaves it
function M.Choose(key, on)
  on = on and true or false
  choices()[key] = on
  local name = folderOf(key)
  if M.Found(name) then
    if on then enable(name, true) elseif not M.AddonWanted(name) then enable(name, false) end
  end
end
function M.Undo() M.staged = {} end
-- the staged changes written (this character's choices, and a module addon on or off in the game's AddOns list as
-- M.Set leaves it) and the interface reloaded (C_UI.Reload, documented with no restriction: UIManagerDocumentation.lua
-- :65), where the login applies them. Never in a fight: Settings greys the button and its popup waits
function M.Commit()
  if not M.Staged() or inCombat() then return false end
  for key, on in pairs(M.staged) do M.Choose(key, on) end
  M.staged = {}
  local reload = (type(C_UI) == "table" and C_UI.Reload) or ReloadUI
  if type(reload) == "function" then reload() end
  return true
end

-- what Settings > Modules lists: the built-in modules and the module addons the client has, each { key, title, on,
-- status, notes }; an external one is named by its toc (X-Cute-Title, else the title) until it registers
function M.Available(officer)
  local out = {}
  for _, def in ipairs(M.list) do
    if def.builtin and (not def.officer or officer) then out[#out + 1] = { key = def.key, title = def.title, notes = def.notes, def = def } end
  end
  for _, a in ipairs(M.found) do
    local primary = registered(a.name)
    if not (primary and primary.officer and not officer) then
      out[#out + 1] = { key = a.name, title = primary and primary.title or a.title, notes = (primary and primary.notes) or a.notes, def = primary, addon = a }
    end
    -- the rest of the folder's modules, each its own row, once it has registered them
    for _, def in ipairs(M.list) do
      if def.addon == a.name and not def.primary and (not def.officer or officer) then
        out[#out + 1] = { key = def.key, title = def.title, notes = def.notes, def = def, addon = a }
      end
    end
  end
  for _, e in ipairs(out) do
    e.base = M.Base(e.key)
    e.on = M.OnKey(e.key, e.def and e.def.default)
    -- a few words where something is not as the box says: waiting for combat to end, refused by the client, loaded
    -- but never registered, or switched off with stats that stay until the next login
    if e.on and M.pending[e.key] then e.status = "loads after combat"
    elseif e.on and M.failed[e.key] then e.status = "did not load: " .. M.failed[e.key]
    elseif e.on and e.addon and not e.def and loaded(e.key) then e.status = "loaded, no page"
    elseif not e.on and e.def and e.def.statsDone then e.status = "its stats leave at the next login" end
  end
  return out
end

-- at the first loading screen of a session: the built-in modules that are on start, the module addons are found, and
-- the ones on for this character load. One the player switched off in the game's AddOns list since is the player's
-- word: its box goes unticked, and only a tick in Settings turns it on again. Not the base: it has no box to tick, and
-- 0.7 itself put Cute_Quest off there for a character whose quest modules were all off (its M.Set), so the base is
-- switched on there and loaded whatever the list says (M.Load enables it first)
local function offInList(name)
  local A = addons()
  local state = A and type(A.GetAddOnEnableState) == "function" and C.Get(A.GetAddOnEnableState, name, character()) or nil
  return state == 0
end
function M.Start()
  if M.started then return end
  M.started = true
  for _, def in ipairs(M.list) do M.Apply(def) end
  M.found = M.Scan()
  for _, a in ipairs(M.found) do
    if M.AddonWanted(a.name) and not registered(a.name) then
      if offInList(a.name) and not a.base then for key in pairs(choices()) do if folderOf(key) == a.name then choices()[key] = false end end else M.Load(a.name) end
    end
  end
end
