-- SPDX-License-Identifier: GPL-3.0-or-later
-- The Guide (6.0): what to do next, as a list of steps, from the one target (Target.lua), the planned route
-- (Model.lua) and your quest log. No frames here: StepFrame.lua draws the list, and Cute's leveling module may read it.
--   steps     accept A from X; kill/collect/use for A (the objective spots of the route's quests, clustered within
--             CLUSTER yards, the nearest first); hand in A at X; travel steps the arrow's way gives (Travel.lua);
--             Train at X; Kill around X until level N; Run to your corpse; Choose a reward
--   first     the target of 5.4.4: the route's first stop, its kept objective spot or a hand-in in reach, so the arrow,
--             the minimap, the Map page and the step frame agree, and the first step changes only on a real event
--   done      a step completes when the game says so: the quest accepted, every objective of its spots done or the
--             quest complete, the quest handed in, the flight landed, the level reached
--   skipped   "Not now" for an hour (QuestBankDB.chars[key].guide.later), "Drop" for good (QB:SetSkipped)
--   reward    a hand-in with a choice: Auto.lua hands it here (G.HoldReward), the step says QuestBank's pick, the
--             frame marks it over the game's button; nothing is chosen for you
--   party     the fill weighs what the party holds (G.Rank); each member's first step comes by Sync's 1G line
--             (G.MemberSteps) for the frame
--   time      "about 14 min to level 6" (G.TimeToLevel): the plan's XP a minute, then the measured XP an hour
--   train     at your level's new spells, the trainer of your class nearest a hand-in stop (D.TRAINER, or learned at
--             its window into QuestBankDB.disc.trainer); none in reach: a reminder line, no step
-- Replan runs after each re-plan (Core.lua, QB:Changed) and on the Guide's own events; it reuses its tables, so a
-- re-plan makes a few kilobytes and a tick none.
local _, QB = ...
if QB.dormant then return end
local G = { steps = {}, ver = 0, later = nil }
QB.Guide = G

local CLUSTER = 150        -- yards: objective spots this close are one step
local LATER = 3600         -- seconds "Not now" holds
local AUTO_MAX = 8         -- auto picks at once (G.Fill)
G.CLUSTER, G.LATER, G.AUTO_MAX = CLUSTER, LATER, AUTO_MAX
G.GIVER_MERGE, G.GIVER_MAX = 30, 40 -- the minimap's ! (Minimap.lua): givers this close are one pin; at most this many

local plain = QB.Plain
local sqrt, huge = math.sqrt, math.huge
local pool, used = {}, 0   -- step tables reused from one Replan to the next
local wbuf, meBuf = {}, {}

local function step(kind)
  used = used + 1
  local s = pool[used]
  if not s then s = {}; pool[used] = s end
  for k in pairs(s) do s[k] = nil end
  s.kind = kind
  return s
end

local function npcName(idx)
  local n = idx and QB.Data.NPC[idx]
  return n and n[1] or "?"
end
local function questName(id)
  local q = QB.Quest.Get(id)
  return q and q.name or plain(QB.state.log[id] and QB.state.log[id].title) or ("Quest " .. tostring(id))
end

-- "Kobold Vermin slain: 3/8" -> "Kobold Vermin", 3, 8; "Investigate Echo Ridge: 0/1" -> "Investigate Echo Ridge", 0, 1
local function parseLine(text)
  text = plain(text)
  if type(text) ~= "string" then return nil end
  local name, have, need = text:match("^(.-):%s*(%d+)%s*/%s*(%d+)")
  if not name then return text, nil, nil end
  name = name:gsub(" slain$", ""):gsub(" killed$", "")
  return name, tonumber(have), tonumber(need)
end
G.ParseLine = parseLine

-- the verb for a spot kind (Data.lua's D.SPOT kinds)
local VERB = { k = "Kill", c = "Collect", u = "Use", b = "Buy", e = "Go to", f = "Gather", s = "Find", d = "Do" }

-- the words of a step, made when asked (the frame asks each refresh; no string is kept on the step)
function G.Text(s)
  if not s then return "" end
  local k = s.kind
  if k == "accept" then return "Accept " .. questName(s.qid) .. " from " .. npcName(s.npc)
  elseif k == "handin" then
    if s.near then return s.n and s.n > 1 and string.format("Hand in %d quests here", s.n) or ("Hand in " .. questName(s.qid) .. " here") end
    return s.n and s.n > 1 and string.format("Hand in %d quests at %s", s.n, npcName(s.npc)) or ("Hand in " .. questName(s.qid))
  elseif k == "objective" then
    -- a quest with no objective spot in the world (a dungeon's: its objectives are inside): "Do <quest> in <dungeon>",
    -- or, with the way in not known, "Do <quest> (<dungeon>: entrance not known yet)"; no dungeon: "Do <quest>"
    if s.obj == "d" then
      local t = "Do " .. questName(s.qid)
      if s.dungeon then t = t .. (s.noEntrance and (" (" .. s.dungeon .. ": entrance not known yet)") or (" in " .. s.dungeon)) end
      return t
    end
    local e = QB.state.log[s.qid]
    local o = e and e.objectives and e.objectives[s.slot or 1]
    local name, have, need = parseLine(o and o.text)
    local verb = VERB[s.obj] or "Do"
    local what = name or questName(s.qid)
    local t = (have and need) and string.format("%s %s %d/%d", verb, what, have, need) or (verb .. " " .. what)
    if s.n and s.n > 1 then t = t .. string.format(", and %d more here", s.n - 1) end
    return t
  elseif k == "travel" then return s.text or "Travel"
  elseif k == "train" then return "Train at " .. (s.name or "your class trainer")
  elseif k == "grind" then return s.text or "Kill around here"
  elseif k == "corpse" then return "Run to your corpse"
  elseif k == "reward" then
    local r = G.reward
    if r and r.qid == s.qid and r.reading then return "Choose a reward: reading the rewards..." end
    if r and r.qid == s.qid and not r.pick then return "Choose a reward: first choice, no better pick known" end
    return "Choose a reward: " .. (s.name or "the marked one") .. " is " .. (QB.NAME or "QuestBank") .. "'s pick"
  end
  return s.text or ""
end

-- (the windows round) an objective step's words and its count apart, for a host that draws the count on the right (Cute's
-- step frame and band): "Collect Iron Rivet", 3, 5; a step of another kind, or one with no count: its words alone
function G.Parts(s)
  if not (s and s.kind == "objective" and s.obj ~= "d") then return G.Text(s), nil, nil end
  local e = QB.state.log[s.qid]
  local o = e and e.objectives and e.objectives[s.slot or 1]
  local name, have, need = parseLine(o and o.text)
  if not (have and need) then return G.Text(s), nil, nil end
  return (VERB[s.obj] or "Do") .. " " .. (name or questName(s.qid)), have, need
end

-- the shorter words, when the frame's row cannot hold the whole line: "Accept X" without the giver (the row's
-- tooltip names them); nil for the other kinds, which are cut with "..." as before
function G.Short(s)
  if s and s.kind == "accept" then return "Accept " .. questName(s.qid) end
  return nil
end

-- (the launch round) the step frame's words in parts: the owner's frame read "Hand in In Nightmares" / "Hand in The
-- Absent Minded Prospector" / "Hand in Ziz Fizziks", one stop or three trips nobody could tell, and five quests share
-- the Prospector's name. Now a step carries its leg of the route (s.stop, s.mins, s.way, s.leg: Replan) and the frame
-- shows, beside the kind's game icon, the name (G.Title), who and where (G.Where, "Mathrengyl Bearwalker - Darnassus";
-- G.Place, the stop alone) and the minutes to that stop (G.Mins)
-- the name: a quest's for a pick-up or a hand-in (the icon says which), "3 quests to hand in" for several, else the
-- step's own words
function G.Title(s)
  if not s then return "" end
  local k = s.kind
  if k == "accept" then return questName(s.qid) end
  if k == "handin" then return (s.n and s.n > 1) and string.format("%d quests to hand in", s.n) or questName(s.qid) end
  return G.Text(s)
end
-- where: the leg's stop (the town, or a place out in a zone), an objective's own (Replan: spotPlace), else the zone the
-- step's spot is in
function G.Place(s)
  if not s then return nil end
  return s.stop or (s.m and QB.Data.MAPNAME and QB.Data.MAPNAME[s.m]) or nil
end
-- (the review round) an objective's place: its dungeon for a Do step, else the town within 150 yards of its spot, else
-- the spot's zone. (The launch round gave it its quest's hand-in stop and that leg's trip: Blackrock Menace's kills
-- read "Blackrock Menace - Lakeshire" out at the Blackrock camps, and the hand-in after them lost its place)
local function spotPlace(s)
  if s.obj == "d" and s.dungeon then return s.dungeon end
  local TV = QB.Travel
  return (TV and TV.TownNear and TV.TownNear(s.c, s.wx, s.wy, 150)) or (s.m and QB.Data.MAPNAME and QB.Data.MAPNAME[s.m]) or nil
end
-- who: the NPC of a pick-up or a hand-in, the quest of an objective spot; nil where nobody is to be found (a dungeon's
-- Do step, travel, training)
function G.Who(s)
  if not s then return nil end
  if (s.kind == "accept" or s.kind == "handin") and s.npc then return npcName(s.npc) end
  if s.kind == "objective" and s.obj ~= "d" and s.qid then return questName(s.qid) end
  return nil
end
-- who and where: G.Who, then the place; the place alone where nobody is to be found
function G.Where(s)
  if not s then return nil end
  local place, who = G.Place(s), G.Who(s)
  if who and place and who ~= place then return who .. " - " .. place end
  return who or place
end
-- the minutes to the step's stop from the stop before it (the plan's leg), where a new leg starts: nil on the leg of the
-- step before it (prev), for a step of no leg, and under half a minute
function G.Mins(s, prev)
  if not (s and s.leg and s.mins) then return nil end
  if prev and prev.leg == s.leg then return nil end
  if s.mins < 0.5 then return nil end
  return math.floor(s.mins + 0.5)
end

-- the place of a stop's NPC, in continent yards and on its map (Data.lua's D.NPC row: name, uiMap, x, y, continent,
-- world x, world y)
local function placeNpc(s, idx)
  local n = idx and QB.Data.NPC[idx]
  if not n then return end
  s.npc, s.m, s.x, s.y = idx, n[2], n[3], n[4]
  s.c, s.wx, s.wy = n[5], n[6], n[7]
end

-- the objective steps of one quest: its open spots (QuestMap.OpenSpots: finished objectives left out) clustered within
-- CLUSTER yards, nearest to `me` first; the kept spot (Target.lua's cur) leads when it is this quest's. Returns how
-- many steps it made
local spotsOf, spotPool, taken = {}, {}, {}
local function objectiveSteps(e, me, lead)
  local QM, M = QB.QuestMap, QB.Model
  if not (QM and QM.OpenSpots) or e.complete then return 0 end
  for k = #spotsOf, 1, -1 do spotsOf[k] = nil end
  for k in pairs(taken) do taken[k] = nil end
  local n = 0
  for _, sp in ipairs(QM.OpenSpots(e)) do
    local w = M.World(sp.m, sp.x * 100, sp.y * 100, wbuf)
    if w then
      n = n + 1
      local a = spotPool[n]
      if not a then a = {}; spotPool[n] = a end
      a.sp, a.c, a.wx, a.wy = sp, w.c, w.wx, w.wy
      a.d = (me and me.c == w.c) and ((w.wx - me.wx) ^ 2 + (w.wy - me.wy) ^ 2) or huge
      spotsOf[n] = a
    end
  end
  table.sort(spotsOf, function(a, b)
    if lead and (a.sp == lead) ~= (b.sp == lead) then return a.sp == lead end
    return a.d < b.d
  end)
  local made = 0
  for i, a in ipairs(spotsOf) do
    if not taken[i] then
      made = made + 1
      local s = step("objective")
      s.qid, s.obj, s.slot = e.id, a.sp.kind, a.sp.slot > 0 and a.sp.slot or nil
      s.c, s.wx, s.wy, s.m, s.x, s.y = a.c, a.wx, a.wy, a.sp.m, a.sp.x * 100, a.sp.y * 100
      s.n = 1 -- (the spawn spots merged here are one objective; other quests' steps near it are counted below)
      for j = i + 1, #spotsOf do
        local b = spotsOf[j]
        if not taken[j] and b.c == a.c and (b.wx - a.wx) ^ 2 + (b.wy - a.wy) ^ 2 <= CLUSTER * CLUSTER then taken[j] = true end
      end
      G.steps[#G.steps + 1] = s
    end
  end
  return made
end

-- a quest in your log, not complete, with no objective step (no spot in the world: a dungeon's, done inside): never a
-- "Hand in" step (6.0.0 made one, and the owner in Ironforge was told to hand in Old Ironforge Incursion at 0/1), but
-- "Do <quest> in <dungeon>" at the dungeon's entrance when the catalog has one (D.CAT's entrance), else at the hand-in
-- NPC, worded "(<dungeon>: entrance not known yet)"; a quest of no dungeon: "Do <quest>" at its hand-in NPC
local function doStep(e, q, turnIdx)
  local s = step("objective")
  s.qid, s.obj, s.n = e.id, "d", 1
  local cat = q and q.cat
  if cat and cat.dungeon then
    s.dungeon = cat.name
    local ent = cat.entrance
    local w = ent and QB.Model.World(ent.m, ent.x, ent.y, wbuf)
    if w then
      s.c, s.wx, s.wy, s.m, s.x, s.y = w.c, w.wx, w.wy, ent.m, ent.x, ent.y
      G.steps[#G.steps + 1] = s
      return s
    end
    s.noEntrance = true
  end
  placeNpc(s, turnIdx)
  G.steps[#G.steps + 1] = s
  return s
end

-- "and N more here": the objective steps of other quests within CLUSTER yards of a step (one quest's spawn spots
-- are one objective, never "more"); counted once the list is whole
local function countNear(steps)
  for i = 1, #steps do
    local a = steps[i]
    if a.kind == "objective" then
      a.n = 1
      for j = 1, #steps do
        local b = steps[j]
        if j ~= i and b.kind == "objective" and b.qid ~= a.qid and b.c == a.c and b.wx and a.wx
          and (b.wx - a.wx) ^ 2 + (b.wy - a.wy) ^ 2 <= CLUSTER * CLUSTER then a.n = a.n + 1 end
      end
    end
  end
end

-- "Not now": the quests put off, by character, for LATER seconds
local function laterDB()
  QuestBankDB = QuestBankDB or {}
  QuestBankDB.chars = QuestBankDB.chars or {}
  local key = QB:CharKey()
  local c = QuestBankDB.chars[key]
  if type(c) ~= "table" then c = {}; QuestBankDB.chars[key] = c end
  if type(c.guide) ~= "table" then c.guide = {} end
  if type(c.guide.later) ~= "table" then c.guide.later = {} end
  return c.guide
end
G.DB = laterDB
local function putOff(id)
  local at = laterDB().later[id]
  if not at then return false end
  if (time and time() or 0) - at < LATER then return true end
  laterDB().later[id] = nil
  return false
end
G.PutOff = putOff

-- dead: where your corpse lies (C_DeathInfo.GetCorpseMapPosition, DeathInfoDocumentation.lua, on the map you are on),
-- in continent yards; nil alive or where the client won't say. One table, read again once a second (the arrow asks
-- 20 times a second). G.dead: whether the last look found you a ghost (Target.lua's look turns the Guide on a client
-- that fires none of the death events)
local corpse = { kind = "corpse", name = "Your corpse" }
local corpseAt, corpseHad = -1, false
local function ghost()
  if type(UnitIsDeadOrGhost) ~= "function" then return false end
  local ok, v = pcall(UnitIsDeadOrGhost, "player")
  return ok and plain(v) == true
end
function G.Corpse()
  if not ghost() then G.dead = false; corpseAt = -1; return nil end
  G.dead = true
  if not (C_DeathInfo and C_DeathInfo.GetCorpseMapPosition) then return nil end
  local now = GetTime and GetTime() or 0
  if corpseAt >= 0 and now - corpseAt < 1 then return corpseHad and corpse or nil end
  corpseAt, corpseHad = now, false
  local m = QB.API.MapID()
  if type(m) ~= "number" then return nil end
  local ok, pos = pcall(C_DeathInfo.GetCorpseMapPosition, m)
  pos = ok and plain(pos) or nil
  if type(pos) ~= "table" then return nil end
  local x, y = plain(pos.x), plain(pos.y)
  if pos.GetXY then
    local ok2, gx, gy = pcall(pos.GetXY, pos)
    if ok2 then x, y = plain(gx), plain(gy) end
  end
  if type(x) ~= "number" or type(y) ~= "number" then return nil end
  local w = QB.Model.World(m, x * 100, y * 100, wbuf)
  if not w then return nil end
  corpse.m, corpse.x, corpse.y, corpse.c, corpse.wx, corpse.wy = m, x * 100, y * 100, w.c, w.wx, w.wy
  corpseHad = true
  return corpse
end

-- the pick-ups: the quests of the plan (your own list, and the Guide's picks while it is on) you don't hold, each by
-- the giver of its first open step (Arrow.lua's A.FirstStep: a chain's next step you can take), or, when all that is
-- left of its chain is a step you hold, by its own giver: it comes right after that hand-in, so the frame shows it as
-- the step after. (The arrow's pick-up list, A.ListFor("pickup"), leaves those out, as the arrow cannot lead to them
-- yet.) Ids and givers only: { qid, idx }, pooled
local pickups, pickPool, pickIds = {}, {}, {}
local function readPickups()
  local Q, A = QB.Quest, QB.Arrow
  local p = QB:Plan()
  local n = 0
  for k = #pickups, 1, -1 do pickups[k] = nil end
  local function add(id)
    for i = 1, n do if pickups[i].qid == id then return end end
    local q = Q.Get(id)
    if not q or QB.state.log[id] or QB.API.IsDone(id) or QB:IsSkipped(id) or putOff(id) then return end
    local st = QB:Status(q)
    if st.code ~= "todo" and st.code ~= "prereq" then return end
    local g, held = q, false
    if A and A.FirstStep then g, held = A.FirstStep(q, st) end
    if held or not g then g = q end
    if not (g.giveIdx and g.giveIdx > 0 and g.give and not g.give.inside) or QB.state.log[g.id] or QB.API.IsDone(g.id) then return end
    for i = 1, n do if pickups[i].qid == g.id then return end end
    n = n + 1
    local d = pickPool[n]
    if not d then d = {}; pickPool[n] = d end
    d.qid, d.idx = g.id, g.giveIdx
    pickups[n] = d
  end
  -- (in id order: the list is the same from one re-plan to the next)
  for k = #pickIds, 1, -1 do pickIds[k] = nil end
  for id in pairs(p.add) do pickIds[#pickIds + 1] = id end
  if QB:GuideOn() then for id in pairs(p.auto) do if not p.add[id] then pickIds[#pickIds + 1] = id end end end
  table.sort(pickIds)
  for _, id in ipairs(pickIds) do add(id) end
  return pickups
end

-- the fill: the quests worth your time by XP a minute (UI:Candidates' rank: the quest's XP and the steps its chain
-- carries, over the trip and its own minutes; a quarter when probably behind you), the best place's set first (the Now
-- view's first place, UI.PlaceGroups: where to go), half again as much when a party member holds or can take it (Sync);
-- never under the floor of XP a minute (c.waste: a 340-XP delivery across two zones is no pick), never a step behind
-- another (its head carries it), never grey unless its chain pays the planner's low-value line, never more than two
-- levels above you, never one you put off or skipped, never one on your own list; up to the log's free slots minus two,
-- at most AUTO_MAX. Picks already made stay while they still qualify, and new ones are made on a real event alone (your
-- level, your log, a hand-in, a jump in place, what you skip, the party's quests: fillAt), never for walking on: the
-- owner saw the route flip from Southshore to Alterac mid-run.
-- Its reach: a giver within 20 minutes, but 3 + your level minutes under 17 (a level-1 character is led around its
-- own valley, not 2,700 yards across the mountains to Coldridge: the straight-line minutes make that 8), and under
-- level 10 only a giver placed on your own map, never one the catalog cannot place; from level 10 the best place's set
-- wherever it is (its trip is in its XP a minute already)
local partyHas = function(id) return QB.Model.PartyHas(id) end
function G.Rank(c, level)
  return (c.rank or 0) * (partyHas(c.id) and 1.5 or 1)
end
local ranked, best, fillAt, candOf, NONE = {}, {}, {}, {}, {}
local function byRank(a, b)
  local ba, bb = best[a.id] and 1 or 0, best[b.id] and 1 or 0
  if ba ~= bb then return ba > bb end
  if a.grank ~= b.grank then return a.grank > b.grank end
  return a.id < b.id
end
-- the party's quests, told apart without a string: their ids summed, and how many (not the members' steps, which change
-- with every kill they make: Sync's stepVer)
local function partyMark()
  local S = QB.Sync
  if not (S and S.members) then return 0 end
  local n = 0
  for _, m in pairs(S.members) do
    if m.quests then for id in pairs(m.quests) do if type(id) == "number" then n = n + 1 + id end end end
  end
  return n
end
-- a real event since the last fill: the inputs it was made from, in fillAt
-- (n: the picks still standing; fewer than the fill left, one was put off or no longer qualifies: fill again)
local function fillChanged(level, n)
  local s = QB.state
  local skip = QB.UI and QB.UI.SkipMark and QB.UI.SkipMark(QB:Settings()) or 0
  local party = partyMark()
  if fillAt.level == level and fillAt.log == (s.logCount or 0) and fillAt.done == (QB.doneVer or 0) and fillAt.jump == (QB.jumpVer or 0)
    and fillAt.skip == skip and fillAt.skipQ == (QB.skipVer or 0) and fillAt.party == party and fillAt.survey == (QB.surveyVer or 0)
    and fillAt.char == QB.charKey and fillAt.n and n >= fillAt.n then
    return false
  end
  fillAt.level, fillAt.log, fillAt.done, fillAt.jump, fillAt.skip, fillAt.skipQ, fillAt.party, fillAt.survey, fillAt.char =
    level, s.logCount or 0, QB.doneVer or 0, QB.jumpVer or 0, skip, QB.skipVer or 0, party, QB.surveyVer or 0, QB.charKey
  return true
end
function G.Fill(level)
  local p = QB:Plan()
  local s = QB.state
  local free = QB.LOG_SLOTS - (s.logCount or 0) - 2
  local line = QB.Model.CHEAP * QB.Scale(level)
  local function qualifies(id)
    local q = QB.Quest.Get(id)
    if not q or q.lvl > level + 2 or (q.req or 1) > level then return false end
    if p.add[id] or putOff(id) or QB:IsSkipped(id) or s.log[id] or QB.API.IsDone(id) then return false end
    local st = QB:Status(q)
    -- (a chain's later step picked before: the pick-ups lead to the chain's first open step)
    if st.code ~= "todo" and st.code ~= "item" and st.code ~= "prereq" then return false end
    if QB.QuestMap and QB.QuestMap.Grey(q, level) and QB:ChainLead(id) < line then return false end
    return true
  end
  -- what is held already: dropped once it no longer qualifies
  local n = 0
  for id in pairs(p.auto) do
    if qualifies(id) then n = n + 1 else p.auto[id] = nil end
  end
  if not fillChanged(level, n) then return n end
  -- a pick no longer worth the time (under the floor of XP a minute now: a level gained, your pace, one made by
  -- 6.1.1's rule and saved) or behind a step not taken goes, at a fill alone, never while you walk
  local cands = QB.UI and QB.UI.Candidates and QB.UI:Candidates(nil, level) or NONE
  for k in pairs(candOf) do candOf[k] = nil end
  for _, c in ipairs(cands) do candOf[c.id] = c end
  local moved = false
  for id in pairs(p.auto) do
    local c = candOf[id]
    if c and (c.waste or c.locked) then p.auto[id], n, moved = nil, n - 1, true end
  end
  for k in pairs(candOf) do candOf[k] = nil end
  fillAt.n = n
  if free <= n or n >= AUTO_MAX then return n, moved end
  -- the best place's set: what you could take there now (the Now view's first place you don't skip; alone, its first
  -- place out of a dungeon: a run is a party's)
  for k in pairs(best) do best[k] = nil end
  if QB.UI and QB.UI.PlaceGroups and not QB:Banking() then
    local grouped = QB.UI.Grouped and QB.UI.Grouped() or false -- (as the Now view tells it: Lists.lua)
    for _, g in ipairs(QB.UI.PlaceGroups(level, true)) do
      if not g.skipped and (grouped or not g.cat.dungeon) then
        for _, it in ipairs(g.set) do if it.grp == 2 then best[it.id] = true end end
        break
      end
    end
  end
  local reach, myMap = math.min(20, 3 + level), s.mapID
  local function inReach(c)
    if best[c.id] and level >= 10 then return true end
    if c.mins == nil then return level >= 10 end
    if c.mins > reach then return false end
    if level < 10 and myMap then
      local g = c.give and c.give > 0 and QB.Data.NPC[c.give]
      if not (g and g[2] == myMap) then return false end
    end
    return true
  end
  for k = #ranked, 1, -1 do ranked[k] = nil end
  for _, c in ipairs(cands) do
    if not p.auto[c.id] and not c.waste and not c.locked and inReach(c) and qualifies(c.id) then
      c.grank = G.Rank(c, level)
      ranked[#ranked + 1] = c
    end
  end
  table.sort(ranked, byRank)
  local was = n
  for _, c in ipairs(ranked) do
    if n >= free or n >= AUTO_MAX then break end
    p.auto[c.id] = true
    n = n + 1
  end
  fillAt.n = n
  if QB.tracing and (n > was or moved) then QB.Trace("fill: %d pick(s) made, %d in all, the best place's first%s", n - was, n, moved and "; one or more no longer worth the time dropped" or "") end
  return n, moved or n > was
end

-- the Train step: something to train (G.Trainable) and a trainer of your class (the seed D.TRAINER, or one learned at
-- its window: QuestBankDB.disc.trainer) within TRAIN_MIN minutes' walk of a route stop with a hand-in: "Train at <name>"
-- goes before that stop's hand-in. No trainer known in reach: the step frame's Train line (G.Reminder)
local TRAIN_MIN = 3
G.TRAIN_MIN = TRAIN_MIN
local trainStepWas -- (Replan's last word on the route's Train step)

local function classID()
  if type(UnitClass) ~= "function" then return nil, nil end
  local ok, _, tok, id = pcall(UnitClass, "player")
  if not ok then return nil, nil end
  return plain(id), plain(tok)
end

-- (the hud round) what there is to train, the spellbook's own answer: a spell of your class's line that the book holds
-- as not learned yet (Enum.SpellBookItemType.FutureSpell) whose level learned is at or under yours, the client's own
-- "trainable" (Blizzard_SpellBookItem.lua:234-247 reads C_SpellBook.GetSpellBookItemLevelLearned so). Until 6.1.1 the
-- Guide asked whether this very level was one a class learns at (D.SPELL_LV) and whether the trainer's window last read
-- 0 to learn: the step never cleared while one spell stayed unbought, and a level-10 spell left at 10 was forgotten at 11.
-- Never counted: a spell a quest teaches (QUEST_TAUGHT), one a class trainer's window did not list at a level it could
-- (learned per character: notSold), and one you left at the trainer (TRAINER_CLOSED: skip, still named in the tooltip).
-- QUEST_TAUGHT: the class spells CMaNGOS Classic's quest_template (GPL-3.0) rewards, its RewSpell or RewSpellCast taken
-- through the Forever client's own learn-spell effects (SpellEffect.csv, effect 36, 1.60.1.70338): Summon Voidwalker 697,
-- Bear Form 5487 and the rest; a reward that only casts a buff on you (Mark of the Wild) teaches nothing and is not here
G.QUEST_TAUGHT = {
  [71] = true, [355] = true, [688] = true, [691] = true, [697] = true, [712] = true, [883] = true, [982] = true, [1066] = true,
  [1122] = true, [1515] = true, [2458] = true, [2641] = true, [2651] = true, [2652] = true, [2842] = true, [3599] = true,
  [5149] = true, [5394] = true, [5487] = true, [5502] = true, [6795] = true, [6807] = true, [6991] = true, [7328] = true,
  [7386] = true, [8071] = true, [8946] = true, [9035] = true, [10140] = true, [10797] = true, [13819] = true, [13896] = true,
  [13908] = true, [18137] = true, [18540] = true, [20252] = true, [23214] = true, [28272] = true, [1277324] = true, [1277331] = true,
}
-- the class's line of the spellbook (C_SpellBook.GetClassSkillLineInfo, else the line at Enum.SpellBookSkillLineIndex.Class,
-- SpellBookConstantsDocumentation.lua): its first slot and how many; nil on a client without the calls
local function classLine()
  local SB = C_SpellBook
  if not (SB and type(SB.GetSpellBookItemInfo) == "function" and type(SB.GetSpellBookItemLevelLearned) == "function") then return nil end
  local info
  if type(SB.GetClassSkillLineInfo) == "function" then
    local ok, v = pcall(SB.GetClassSkillLineInfo)
    if ok and type(v) == "table" then info = v end
  end
  if not info and type(SB.GetSpellBookSkillLineInfo) == "function" then
    local idx = Enum and Enum.SpellBookSkillLineIndex and Enum.SpellBookSkillLineIndex.Class or 2
    local ok, v = pcall(SB.GetSpellBookSkillLineInfo, idx)
    if ok and type(v) == "table" then info = v end
  end
  local first, n = info and plain(info.itemIndexOffset), info and plain(info.numSpellBookItems)
  if type(first) ~= "number" or type(n) ~= "number" then return nil end
  return first, math.min(n, 400)
end
local FUTURE = 2 -- (Enum.SpellBookItemType.FutureSpell)
local trainBuf, skipBuf, rankNames = {}, {}, {} -- the spells to train and the ones left at the trainer, ids, reused
local trainFor, trainKnown = nil, nil -- (the level and the reads it was made for: G.TrainDirty)
G.trainVer = 0
-- the spells to train now: how many, their ids (a list reused) and the ones left at the trainer (another); a client
-- without the spellbook's calls: nil, and the Guide goes by D.SPELL_LV as before (NeedsTraining)
function G.Trainable()
  local level = QB.state and QB.state.level or 1
  if trainFor == level and trainKnown ~= nil then return trainKnown and #trainBuf or nil, trainBuf, skipBuf end
  -- (the hud review: never read in a fight; the last read stands until after it)
  if trainKnown ~= nil and InCombatLockdown and InCombatLockdown() then return trainKnown and #trainBuf or nil, trainBuf, skipBuf end
  for k = #trainBuf, 1, -1 do trainBuf[k] = nil end
  for k = #skipBuf, 1, -1 do skipBuf[k] = nil end
  trainFor = level
  local first, n = classLine()
  if not first then trainKnown = false return nil, trainBuf, skipBuf end
  trainKnown = true
  local db = laterDB()
  local skip, notSold = type(db.skip) == "table" and db.skip or nil, type(db.notSold) == "table" and db.notSold or nil
  local bank = Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player or 0
  local SB = C_SpellBook
  -- (a diagnostic for the live client, the design's section 11: whether the book holds higher ranks of spells you know
  -- as FutureSpell; if none do, Train needs the generated rank table. Counts alone, QuestBankDB.diag.remind)
  local future, ranks, knownName = 0, 0, rankNames
  for k in pairs(knownName) do knownName[k] = nil end
  for slot = first + 1, first + n do
    local ok, it = pcall(SB.GetSpellBookItemInfo, slot, bank)
    if ok and type(it) == "table" and plain(it.itemType) ~= FUTURE then
      local nm = plain(it.name)
      if type(nm) == "string" then knownName[nm] = true end
    end
  end
  for slot = first + 1, first + n do
    local ok, it = pcall(SB.GetSpellBookItemInfo, slot, bank)
    local id = ok and type(it) == "table" and plain(it.spellID) or nil
    if type(id) == "number" and plain(it.itemType) == FUTURE then
      future = future + 1
      local nm = plain(it.name)
      if type(nm) == "string" and knownName[nm] then ranks = ranks + 1 end
    end
    if type(id) == "number" and plain(it.itemType) == FUTURE and not G.QUEST_TAUGHT[id] and not (notSold and notSold[id]) then
      local okL, lv = pcall(SB.GetSpellBookItemLevelLearned, slot, bank)
      lv = okL and plain(lv) or nil
      if type(lv) == "number" and lv > 0 and lv <= level then
        if skip and skip[id] then skipBuf[#skipBuf + 1] = id else trainBuf[#trainBuf + 1] = id end
      end
    end
  end
  if QB.Remind and QB.Remind.Diag then QB.Remind.Diag("trainFuture", future); QB.Remind.Diag("trainRanks", ranks) end
  return #trainBuf, trainBuf, skipBuf
end
-- the spellbook changed (a spell learned, a level, the trainer's window shut): read again at the next ask, which is
-- never in a fight; the plan made again when the count moved, looked at half a second on (the hud review: once for a
-- burst, a level bringing three of these events and a login a dozen SPELLS_CHANGED, each a read of the whole book
-- until now) and after a fight where the look fell in one
local trainSoon, trainWas, trainAfter = false, nil, false
function G.TrainDirty()
  if not trainSoon then trainWas = trainKnown and #trainBuf or nil end
  trainFor = nil
  if trainSoon then return end
  trainSoon = true
  if C_Timer and C_Timer.After then C_Timer.After(0.5, QB.Safe(G.TrainCheck, "guide: train")) else G.TrainCheck() end
end
function G.TrainCheck()
  trainSoon = false
  if InCombatLockdown and InCombatLockdown() then trainAfter = true return end
  trainAfter = false
  local now = G.Trainable()
  if now ~= trainWas then G.trainVer = G.trainVer + 1; QB:MarkDirty() end
end

function G.NeedsTraining(level)
  if not level or level <= 1 then return false end -- (a new character holds its first spells)
  local n = G.Trainable()
  if n ~= nil then return n > 0 end
  -- (a client without the spellbook's calls: the levels a class learns at, and the window's last word)
  local _, tok = classID()
  local levels = tok and QB.Data.SPELL_LV and QB.Data.SPELL_LV[tok]
  if not levels then return false end
  if (laterDB().trained or 0) >= level then return false end
  for _, l in ipairs(levels) do if l == level then return true end end
  return false
end

-- the trainers of your class as places ({name, c, wx, wy, m, x, y, hub = 0, walk = 0}: on foot, M.Between): the seed's
-- rows and those learned in play; made again only when the seed table or the learned count changed
local trainerBuf, trainerFor, trainerN, trainerCls = {}, nil, -1, nil
local function trainers()
  local id = classID()
  local disc = QB.Discover and QB.Discover.DB and QB.Discover.DB()
  local learned = disc and disc.trainer
  local n = 0
  if learned then for _ in pairs(learned) do n = n + 1 end end
  if trainerFor == QB.Data.TRAINER and trainerN == n and trainerCls == id then return trainerBuf end
  trainerFor, trainerN, trainerCls = QB.Data.TRAINER, n, id
  for k = #trainerBuf, 1, -1 do trainerBuf[k] = nil end
  if not id then return trainerBuf end
  for _, t in ipairs(QB.Data.TRAINER or {}) do
    if t[3] == id then trainerBuf[#trainerBuf + 1] = { name = t[2], c = t[4], wx = t[5], wy = t[6], m = t[7], x = t[8], y = t[9], hub = 0, walk = 0 } end
  end
  for _, t in pairs(learned or {}) do
    if t.cl == id and t.m and t.x and t.y then
      local w = QB.Model.World(t.m, t.x, t.y, wbuf)
      if w then trainerBuf[#trainerBuf + 1] = { name = t.n, c = w.c, wx = w.wx, wy = w.wy, m = t.m, x = t.x, y = t.y, hub = 0, walk = 0 } end
    end
  end
  return trainerBuf
end

-- the nearest trainer of your class within TRAIN_MIN minutes of a stop (a place: {c, wx, wy, hub, walk})
function G.Trainer(stop)
  if not (stop and stop.c and stop.hub) then return nil end
  local M = QB.Model
  local mf = M.Factor(QB:Mounted())
  local best, bm
  for _, t in ipairs(trainers()) do
    if t.c == stop.c then
      local m = M.Between(stop, t, QB.faction, mf)
      if m and m <= TRAIN_MIN and (not bm or m < bm) then best, bm = t, m end
    end
  end
  return best
end

-- the seed knows this NPC already (by id): nothing to write down
local function seeded(key)
  local id = tonumber(key and key:match("^c(%d+)$"))
  if not id then return false end
  for _, t in ipairs(QB.Data.TRAINER or {}) do if t[1] == id then return true end end
  return false
end

-- (the hud review) the names of your class's line of the spellbook, known and to learn (the book's own, else
-- C_Spell.GetSpellName of its spell), a set reused; empty where the book gives none
local nameBuf = {}
local function classNames()
  for k in pairs(nameBuf) do nameBuf[k] = nil end
  local first, n = classLine()
  if not first then return nameBuf end
  local SB, getName = C_SpellBook, C_Spell and C_Spell.GetSpellName
  local bank = Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player or 0
  for slot = first + 1, first + n do
    local ok, it = pcall(SB.GetSpellBookItemInfo, slot, bank)
    if ok and type(it) == "table" then
      local nm, sp = plain(it.name), plain(it.spellID)
      if type(nm) ~= "string" and type(sp) == "number" and type(getName) == "function" then
        local okN, v = pcall(getName, sp)
        nm = okN and plain(v) or nil
      end
      if type(nm) == "string" and nm ~= "" then nameBuf[nm] = true end
    end
  end
  return nameBuf
end
-- (the hud review) whether the trainer's window open now is your class trainer's: not a profession's
-- (IsTradeskillTrainer), nor a pet trainer's or any kind but the general one (C_Trainer.GetTrainerType,
-- TrainerDocumentation.lua:20; Enum.TrainerType General 0, Pet 3, TrainerConstantsDocumentation.lua; the game's own
-- window tells a pet trainer apart so, Blizzard_TrainerUI_Camelot.lua:4); and of your class: the seed's trainer of it,
-- else a window whose list names a spell of your class's line (a weapon master's names weapons; one written down by
-- an earlier window that names none is let go), else one written down at an earlier window when this one lists
-- nothing. A book that names no spell can't tell: the general kind is enough, as before. Until 6.2 every window but a
-- profession's counted, and a hunter at a pet trainer had every spell to train marked not sold and left there
local function classTrainer(key, n)
  if type(IsTradeskillTrainer) == "function" then
    local ok, trade = pcall(IsTradeskillTrainer)
    if ok and plain(trade) == true then return false end
  end
  local CT = C_Trainer
  if CT and type(CT.GetTrainerType) == "function" then
    local ok, kind = pcall(CT.GetTrainerType)
    kind = ok and plain(kind) or nil
    local general = Enum and Enum.TrainerType and Enum.TrainerType.General or 0
    if type(kind) == "number" and kind ~= general then return false end
  end
  local id = classID()
  local npc = tonumber(key and key:match("^c(%d+)$"))
  if npc and id then
    for _, t in ipairs(QB.Data.TRAINER or {}) do if t[1] == npc then return t[3] == id end end
  end
  local disc = QB.Discover and QB.Discover.DB and QB.Discover.DB()
  local known = key and disc and type(disc.trainer) == "table" and disc.trainer[key]
  local names = classNames()
  if next(names) ~= nil and type(n) == "number" and n > 0 and type(GetTrainerServiceInfo) == "function" then
    for i = 1, math.min(n, 300) do
      local ok, sname = pcall(GetTrainerServiceInfo, i)
      sname = ok and plain(sname) or nil
      if type(sname) == "string" and names[sname] then return true end
    end
    if type(known) == "table" and known.cl then disc.trainer[key] = nil end
    return false
  end
  if type(known) == "table" and known.cl then return known.cl == id end
  return next(names) == nil
end

-- the trainer's window: the NPC is written down as a trainer of your class (classTrainer above), and with nothing left
-- to learn, this level is trained. Nothing said in chat
local function onTrainer()
  G.atClassTrainer = false
  local okG, guid, okN, name = false, nil, false, nil
  if type(UnitGUID) == "function" then okG, guid = pcall(UnitGUID, "npc") end
  if type(UnitName) == "function" then okN, name = pcall(UnitName, "npc") end
  local key = okG and QB.Discover and QB.Discover.Key and QB.Discover.Key(guid)
  local okS, n = false, 0
  if type(GetNumTrainerServices) == "function" then okS, n = pcall(GetNumTrainerServices) end
  n = okS and plain(n) or 0
  if not classTrainer(key or nil, n) then return end
  G.atClassTrainer = true
  local id = classID()
  name = okN and plain(name) or nil
  if key and type(name) == "string" and id and not seeded(key) and QB.Discover.DB then
    local m = plain(QB.API.MapID())
    local pos = type(m) == "number" and C_Map and C_Map.GetPlayerMapPosition and select(2, pcall(C_Map.GetPlayerMapPosition, m, "player"))
    pos = plain(pos)
    local x, y = type(pos) == "table" and plain(pos.x), type(pos) == "table" and plain(pos.y)
    if type(x) == "number" and type(y) == "number" then
      local disc = QB.Discover.DB()
      disc.trainer = disc.trainer or {}
      local t = disc.trainer[key]
      if type(t) ~= "table" then t = {}; disc.trainer[key] = t end
      t.n, t.cl, t.m, t.x, t.y = name, id, m, x * 100, y * 100
    end
  end
  local avail = 0
  if type(n) == "number" and type(GetTrainerServiceInfo) == "function" then
    for i = 1, n do
      local okI, _, kind = pcall(GetTrainerServiceInfo, i)
      if okI and plain(kind) == "available" then avail = avail + 1 end
    end
  end
  if avail == 0 then laterDB().trained = QB.state.level or 1 end
  G.LearnSold(n)
  QB:MarkDirty()
end

-- (the hud round) the class trainer's window lists what it sells (GetTrainerServiceInfo: name, available, unavailable or
-- used): a spell to train whose name it does not list at all is one no trainer sells this class (a quest's, or one
-- Forever moved), never counted again for this character (notSold). Only while the window lists what you can learn
-- (its "available" filter on, GetTrainerServiceTypeFilter, Blizzard_TrainerUI.lua:243), so a filter never hides a spell
function G.LearnSold(n)
  if type(n) ~= "number" or n <= 0 or type(GetTrainerServiceInfo) ~= "function" then return end
  if type(GetTrainerServiceTypeFilter) == "function" then
    local ok, on = pcall(GetTrainerServiceTypeFilter, "available")
    if ok and plain(on) == false then return end
  end
  local count, list = G.Trainable()
  if not count or #list == 0 then return end
  local sold = {}
  for i = 1, math.min(n, 300) do
    local ok, name = pcall(GetTrainerServiceInfo, i)
    name = ok and plain(name) or nil
    if type(name) == "string" then sold[name] = true end
  end
  local db = laterDB()
  local changed = false
  for _, id in ipairs(list) do
    local name = C_Spell and type(C_Spell.GetSpellName) == "function" and plain(select(2, pcall(C_Spell.GetSpellName, id))) or nil
    if type(name) == "string" and name ~= "" and not sold[name] then
      if type(db.notSold) ~= "table" then db.notSold = {} end
      db.notSold[id] = true
      changed = true
    end
  end
  if changed then G.TrainDirty() end
end
-- the window shut (TRAINER_CLOSED, a class trainer's): what stayed to train is skipped (laterDB().skip[id] = level),
-- no longer counted and still named in the Train line's tooltip; a new level counts it again only if it is new
function G.TrainerClosed()
  local count, list = G.Trainable()
  if not count or #list == 0 then G.TrainDirty() return end
  local db = laterDB()
  if type(db.skip) ~= "table" then db.skip = {} end
  local lvl = QB.state.level or 1
  for _, id in ipairs(list) do db.skip[id] = lvl end
  local n = 0
  for _ in pairs(db.skip) do n = n + 1 end
  if n > 64 then
    -- (kept small: the ones you have learned since go)
    for id in pairs(db.skip) do if QB.Camp and QB.Camp.Knows(id) then db.skip[id] = nil end end
  end
  G.TrainDirty()
end

-- nothing worth taking in reach: where to kill until the next level that opens quests, and where they are. The
-- whole catalog is scanned for the nearest kill spot, but only when the list is empty (rare); one table reused
local grind = { kind = "grind" }
function G.Grind(level, me)
  local UI, D, M = QB.UI, QB.Data, QB.Model
  if not (UI and UI.Candidates) then return nil end
  local nextReq, nextCat
  for _, cand in ipairs(UI:Candidates(nil, level, level + 3)) do
    if cand.req and cand.req > level and (not nextReq or cand.req < nextReq or (cand.req == nextReq and (cand.mins or huge) < (nextCat and nextCat.mins or huge))) then
      nextReq, nextCat = cand.req, cand
    end
  end
  if not nextReq then return nil end
  -- the nearest kill spot of a quest around your level, for you
  local best, bd, bname
  local bit = QB.API.ClassBit()
  if me and D.SPOT and QB.QuestMap and QB.QuestMap.Spots then
    for id, r in pairs(D.Q) do
      if r[1] >= level - 2 and r[1] <= level + 1 and D.SPOT[id] then
        local side, cls = r[3], r[9]
        if (side == 0 or (side == 1 and QB.faction == "A") or (side == 2 and QB.faction == "H")) and (cls == 0 or bit == 0 or math.floor(cls / bit) % 2 == 1) then
          for _, sp in ipairs(QB.QuestMap.Spots(D.SPOT[id]) or {}) do
            if sp.kind == "k" then
              local w = M.World(sp.m, sp.x * 100, sp.y * 100, wbuf)
              if w and w.c == me.c then
                local d = (w.wx - me.wx) ^ 2 + (w.wy - me.wy) ^ 2
                if not bd or d < bd then
                  best, bd = sp, d
                  bname = (sp.name and D.SN and D.SN[sp.name]) or (D.MAPNAME and D.MAPNAME[sp.m]) or nil
                  grind.c, grind.wx, grind.wy, grind.m, grind.x, grind.y = w.c, w.wx, w.wy, sp.m, sp.x * 100, sp.y * 100
                end
              end
            end
          end
        end
      end
    end
  end
  local cat = D.CAT[nextCat.cat]
  local where = cat and cat.name or "the next zone"
  grind["until"] = nextReq
  if best then
    grind.text = string.format("Kill around %s until level %d, then %s", bname or "here", nextReq, where)
  else
    grind.text = string.format("Kill around here until level %d, then %s", nextReq, where)
    grind.c, grind.wx, grind.wy, grind.m, grind.x, grind.y = nil, nil, nil, nil, nil, nil
  end
  return grind
end

-- "about 14 min to level 6": the XP still needed (the game's bar, else D.TO_NEXT) over the plan's XP a minute (its
-- travel and its quests' minutes) until ten minutes of play have been measured (Timer.XPPerHour), then over the
-- measured rate; nil at the cap or with nothing to go on. Returns the words, the minutes and whether they are measured
local function spanText(mins)
  if mins < 1 then return "under a minute" end
  if mins < 90 then return string.format("about %d min", math.floor(mins + 0.5)) end
  local h = math.floor(mins / 60)
  local m = math.floor((mins - h * 60) / 10 + 0.5) * 10
  if m == 60 then h, m = h + 1, 0 end
  return m > 0 and string.format("about %d h %d min", h, m) or string.format("about %d h", h)
end
G.SpanText = spanText
-- (the words are kept while they would read the same: the frame asks twice a second, and a tick makes no string)
local ttlLevel, ttlKey, ttlText = nil, nil, nil
function G.TimeToLevel()
  local s = QB.state
  local level = s.level or 1
  if level >= QB.MAXLEVEL or level >= (QB.CAP or QB.MAXLEVEL) then return nil end
  local max = (s.xpMax and s.xpMax > 1) and s.xpMax or QB.Data.TO_NEXT[level] or 0
  local need = max - (s.xp or 0)
  if need <= 0 then return nil end
  local rate = QB.Timer and QB.Timer.XPPerHour and QB.Timer.XPPerHour()
  local mins, measured
  if rate and rate > 0 then
    mins, measured = need / rate * 60, true
  else
    local r = QB.routePlan
    if not (r and r.xp and r.xp > 0 and r.t and r.t > 0) then return nil end
    -- the plan's XP a minute: its travel and hand-ins, and the work its quests still ask (the quest minutes, Model.lua:
    -- route.W; a route planned before them counted a minute a quest)
    local perMin = r.xp / (r.t + (r.W or r.count or 0))
    mins, measured = need / perMin, false
  end
  -- the minutes as the words round them: under one, whole minutes to 90, then tens
  local key = mins < 1 and 0 or (mins < 90 and math.floor(mins + 0.5) or math.floor(mins / 10 + 0.5) * 10)
  if level ~= ttlLevel or key ~= ttlKey then
    ttlLevel, ttlKey, ttlText = level, key, spanText(mins) .. " to level " .. (level + 1)
  end
  return ttlText, mins, measured
end

-- the quest's usable item, for the frame's button (GetQuestLogSpecialItemInfo, as the objective tracker's button:
-- link, texture, charges, showItemWhenComplete): id, link, texture; nil without one
function G.ItemFor(s)
  if not (s and s.qid and type(GetQuestLogSpecialItemInfo) == "function") then return nil end
  local e = QB.state.log[s.qid]
  if not (e and e.index) then return nil end
  local ok, link, tex = pcall(GetQuestLogSpecialItemInfo, e.index)
  link, tex = ok and plain(link) or nil, ok and plain(tex) or nil
  local id = type(link) == "string" and tonumber(link:match("item:(%d+)"))
  if not id then return nil end
  return id, link, tex
end

-- a hand-in with a reward to choose: the Guide holds QuestBank's pick (UI.BestReward's gear, else the first trinket,
-- else the first) and the frame marks it; nothing is chosen for you. G.reward = { qid, n, index, name, ... } while the
-- window with the choice is open; the list is made again so the step says so
-- (the review round) the window's items as the client sends them: while a choice's link is missing, the pick is read
-- again a fifth of a second after QUEST_ITEM_UPDATE (the quest window's own event, QuestFrame.lua) or
-- GET_ITEM_INFO_RECEIVED. (The launch round read them once, 0.05 s after QUEST_COMPLETE: a link not loaded yet left
-- "First choice: no better pick known" up all the while, a better pick known)
local rewardFrame, rewardSoon = nil, false
local function rereadRewards()
  rewardSoon = false
  local r = G.reward
  if r and r.unloaded then G.HoldReward(r.qid, r.n) end
end
local function watchRewards(on)
  if on and not rewardFrame then
    rewardFrame = CreateFrame("Frame")
    G.rewardFrame = rewardFrame
    rewardFrame:SetScript("OnEvent", QB.Safe(function()
      if rewardSoon or not (G.reward and G.reward.unloaded) then return end
      rewardSoon = true
      C_Timer.After(0.2, QB.Safe(rereadRewards, "guide: rewards"))
    end, "guide: rewards"))
  end
  if not rewardFrame or (on and true or false) == (rewardFrame.qbOn == true) then return end
  rewardFrame.qbOn = on and true or nil
  for _, e in ipairs({ "QUEST_ITEM_UPDATE", "GET_ITEM_INFO_RECEIVED" }) do
    if on then pcall(rewardFrame.RegisterEvent, rewardFrame, e) else pcall(rewardFrame.UnregisterEvent, rewardFrame, e) end
  end
end
function G.HoldReward(qid, n)
  local level = QB.state.level or 1
  local UI = QB.UI
  local best = UI and UI.BestReward and (UI.BestReward(qid, "gear", level) or UI.BestReward(qid, "trinket", level)) or nil
  -- (the launch round) a pick only where the Gear finder's best is among the items the window gives; else the first
  -- choice, marked and said as no more than that (nothing known fits you: 6.1 marked it as a pick all the same). link:
  -- the pick's, for the frame's line (its stats). (The review round) an item whose link is not loaded yet is told by
  -- its id all the same (GetQuestItemInfo's sixth value, as QuestInfo.lua and Discover.lua read it); with an item not
  -- told at all and a pick known, the window is still being read (reading: no mark yet, the line says so)
  local index, name, link, firstName, firstLink, untold, unloaded = nil, nil, nil, nil, nil, false, false
  if type(GetQuestItemLink) == "function" then
    for i = 1, n do
      local ok, l = pcall(GetQuestItemLink, "choice", i)
      l = ok and plain(l) or nil
      if type(l) ~= "string" then l, unloaded = nil, true end
      local id = l and tonumber(l:match("item:(%d+)"))
      if not id and type(GetQuestItemInfo) == "function" then
        local okI, _, _, _, _, _, itemID = pcall(GetQuestItemInfo, "choice", i)
        itemID = okI and plain(itemID) or nil
        if type(itemID) == "number" and itemID > 0 then id = itemID end
      end
      if not id then untold = true end
      if i == 1 and l then firstName, firstLink = l:match("%[(.-)%]"), l end
      if id and best and id == best and not index then index, name, link = i, l and l:match("%[(.-)%]"), l end
    end
  end
  local reading = best ~= nil and not index and untold
  G.reward = { qid = qid, n = n, index = index or ((not reading) and 1 or nil), name = index and name or firstName, link = index and link or firstLink,
               item = index and best or nil, pick = index ~= nil, reading = reading or nil, unloaded = unloaded or nil }
  watchRewards(unloaded)
  G.Replan()
  if QB.StepFrame and QB.StepFrame.MarkReward then QB.StepFrame.MarkReward() end
end
function G.DropReward()
  if not G.reward then return end
  G.reward = nil
  watchRewards(false)
  G.Replan()
  if QB.StepFrame and QB.StepFrame.MarkReward then QB.StepFrame.MarkReward() end
end

-- the steps, anew: the target first (its quest's objective spot, or its stop's hand-ins), then the rest of the route
-- stop by stop (each stop: the objectives of its quests on the way, its hand-ins, then the pick-ups there: what you
-- hand in to an NPC comes before what you take from the same one), then the pick-ups at no stop of the route,
-- the nearest first
local doneQ, byNpc, left = {}, {}, {}
-- a pick-up belongs to a stop when its giver is one of the stop's hand-in NPCs (stop.seen, Model.lua) or stands
-- within CLUSTER yards of one of its places on the same continent (Deputy Willem, twenty yards from the abbey's
-- hand-ins, is no hand-in of anyone's quest yet)
local function atStop(stop, idx)
  if stop.seen and stop.seen[idx] then return true end
  local n = QB.Data.NPC[idx]
  if not (n and n[5] == stop.c) then return false end
  local places = stop.places
  if places and #places > 0 then
    for _, p in ipairs(places) do
      if (p.wx - n[6]) ^ 2 + (p.wy - n[7]) ^ 2 <= CLUSTER * CLUSTER then return true end
    end
    return false
  end
  return stop.wx ~= nil and (stop.wx - n[6]) ^ 2 + (stop.wy - n[7]) ^ 2 <= CLUSTER * CLUSTER
end
local function byFar(a, b) if a.far ~= b.far then return a.far < b.far end return a.qid < b.qid end
function G.Replan()
  if not (QB:Settings().guide and QB:Settings().guide.on) then
    if #G.steps > 0 then for k = #G.steps, 1, -1 do G.steps[k] = nil end; G.ver = G.ver + 1 end
    return
  end
  if QB:GuideOn() then
    local before = QB:Plan().auto
    local n0 = 0
    for _ in pairs(before) do n0 = n0 + 1 end
    local n1, moved = G.Fill(QB.state.level or 1)
    if (n1 ~= n0 or moved) and not G.filling then
      -- new picks: the route is planned again with them, and Replan runs again from QB:Changed
      G.filling = true
      QB.sigPlan, QB.sigNow = nil, nil
      QB:Recompute(true)
      G.filling = false
    end
  end
  local wasKey = G.FirstKey()
  for k = #G.steps, 1, -1 do G.steps[k] = nil end
  used = 0
  local T, A = QB.Target, QB.Arrow
  local me = QB.API.WorldPosition(nil, meBuf)
  local log = QB.state.log or {}
  local cur = T and T.Get(me)
  local r = T and T.Route()
  local legs = r and r.legs or {}
  for k in pairs(doneQ) do doneQ[k] = nil end
  -- dead: the corpse first; the route's steps follow, so the frame still shows what comes after
  local k = G.Corpse()
  if k then
    local s = step("corpse")
    s.c, s.wx, s.wy, s.m, s.x, s.y = k.c, k.wx, k.wy, k.m, k.x, k.y
    G.steps[1] = s
  end
  -- a hand-in in reach: first, whatever its value (Target.lua)
  if cur and cur.name and cur.near and not k then
    local s = step("handin")
    s.qid, s.n, s.near, s.xp = cur.qid, cur.quests, true, 0
    placeNpc(s, cur.near)
    G.steps[1] = s
    for id in pairs(cur.ids or {}) do
      if type(id) == "number" then doneQ[id] = true; s.xp = s.xp + ((QB:Value(id)) or 0) end
    end
  end
  local pickups = readPickups()
  local function pickupsAt(stop)
    for _, d in ipairs(pickups) do
      if d.qid and not doneQ[d.qid] and not putOff(d.qid) and d.idx and atStop(stop, d.idx) then
        local s = step("accept")
        s.qid = d.qid
        placeNpc(s, d.idx)
        G.steps[#G.steps + 1] = s
        doneQ[d.qid] = true
      end
    end
  end
  for li, leg in ipairs(legs) do
    local stop = leg.stop
    if stop then
      local n0 = #G.steps
      local place = QB.Travel.StopPlace(stop) -- ("Northshire Abbey", not "Elwynn Forest (48, 43)")
      -- the objectives of this stop's quests still open (the target's quest is moved first below); one with no spot
      -- in the world gets its Do step (doStep) and no hand-in until it is complete
      for _, row in ipairs(leg.rows or {}) do
        local e = log[row.q.id]
        if e and not e.complete and not putOff(e.id) and not doneQ[e.id] and objectiveSteps(e, me, nil) == 0 then
          doStep(e, row.q, row.q.turnIdx)
          doneQ[e.id] = true
        end
      end
      -- its hand-ins, one step per NPC: the quests ready now, and the ones still to do after their objectives
      for k in pairs(byNpc) do byNpc[k] = nil end
      for _, row in ipairs(leg.rows or {}) do
        local e = log[row.q.id]
        if e and not doneQ[e.id] and not putOff(e.id) then
          local idx = row.q.turnIdx
          local s = byNpc[idx]
          if not s then
            s = step("handin")
            s.qid, s.n, s.xp = e.id, 0, 0
            placeNpc(s, idx)
            byNpc[idx] = s
            G.steps[#G.steps + 1] = s
          end
          s.n, s.xp = s.n + 1, s.xp + (row.xp or 0) -- (the quests' XP together: the frame's tooltip)
          if e.id < s.qid then s.qid = e.id end
          doneQ[e.id] = true
        end
      end
      pickupsAt(stop)
      -- the leg on each step made for the stop (its hand-ins and pick-ups): its stop's name, the minutes to it from the
      -- stop before, how, which leg. An objective on the way is where its spot is, on no trip of the route's (below)
      for i = n0 + 1, #G.steps do
        local s = G.steps[i]
        if s.kind ~= "objective" then s.stop, s.mins, s.way, s.leg = place, leg.travel, leg.kind, li end
      end
    end
  end
  -- the quests held and not done that the route leaves out (Model.lua's route.waiting: a dungeon's, nothing to hand
  -- in yet, no spot to lead to): their Do steps, after the route's
  for _, w in ipairs(r and r.waiting or {}) do
    local e = log[w.q.id]
    if e and not e.complete and not doneQ[e.id] and not putOff(e.id) and objectiveSteps(e, me, nil) == 0 then
      doStep(e, w.q, w.q.turnIdx)
      doneQ[e.id] = true
    end
  end
  -- pick-ups at no stop of the route (a giver away from every hand-in): after the route, the nearest to you first
  -- (off your continent last, then by id)
  for k = #left, 1, -1 do left[k] = nil end
  for _, d in ipairs(pickups) do
    if d.qid and not doneQ[d.qid] and not putOff(d.qid) then
      local n = QB.Data.NPC[d.idx]
      d.far = (me and n and n[5] == me.c) and ((n[6] - me.wx) ^ 2 + (n[7] - me.wy) ^ 2) or huge
      left[#left + 1] = d
    end
  end
  table.sort(left, byFar)
  for _, d in ipairs(left) do
    local s = step("accept")
    s.qid = d.qid
    placeNpc(s, d.idx)
    s.stop = QB.Travel.TownNear(s.c, s.wx, s.wy, 150) or (s.m and QB.Data.MAPNAME and QB.Data.MAPNAME[s.m]) or nil -- (no stop of the route: its town or zone)
    G.steps[#G.steps + 1] = s
    doneQ[d.qid] = true
  end
  countNear(G.steps)
  -- the first step is the target's: when the target leads to an objective spot of a quest, that quest's nearest
  -- objective step goes first (Target.lua keeps the quest and the spot; the list follows it, never the other way); so
  -- does its Do step when the target is a dungeon's entrance, or a hand-in with nothing done yet (cur.pending)
  if cur and cur.name and (cur.obj or cur.pending) and cur.qid and not (G.steps[1] and (G.steps[1].near or G.steps[1].kind == "corpse")) then
    for i, s in ipairs(G.steps) do
      if s.kind == "objective" and s.qid == cur.qid then
        if i > 1 then table.remove(G.steps, i); table.insert(G.steps, 1, s) end
        s.c, s.wx, s.wy, s.m, s.x, s.y = cur.c, cur.wx, cur.wy, cur.m, cur.x, cur.y
        break
      end
    end
  end
  -- each objective's place, from its spot as it stands now (the target's above included)
  for _, s in ipairs(G.steps) do
    if s.kind == "objective" then s.stop = spotPlace(s) end
  end
  -- new spells to learn: Train at the trainer nearest a stop with a hand-in to come, before that hand-in; none within
  -- reach: the step frame's Train line (G.Reminder), until you train
  local level = QB.state.level or 1
  G.trainStep = false
  if G.NeedsTraining(level) then
    local placed = false
    for i, s in ipairs(G.steps) do
      if s.kind == "handin" and not s.near then
        local stop
        for _, leg in ipairs(legs) do if leg.stop and leg.stop.seen and leg.stop.seen[s.npc] then stop = leg.stop break end end
        local t = stop and G.Trainer(stop)
        if t then
          local ts = step("train")
          ts.name, ts.c, ts.wx, ts.wy, ts.m, ts.x, ts.y = t.name, t.c, t.wx, t.wy, t.m, t.x, t.y
          table.insert(G.steps, i, ts)
          placed = true
          break
        end
      end
    end
    G.trainStep = placed
  end
  -- a reward to choose in the open window: that first, whatever else stands
  if G.reward then
    local s = step("reward")
    s.qid, s.name = G.reward.qid, G.reward.name
    table.insert(G.steps, 1, s)
  end
  -- the arrow's step on the way to the first step (a flight master, a pier, the tram: Target.lua's T.Step) goes before it
  local ts, onWay = nil, false
  if QB.Target and QB.Target.Step then ts, onWay = QB.Target.Step() end
  if ts and onWay and G.steps[1] and G.steps[1].kind ~= "corpse" and G.steps[1].kind ~= "reward" then
    local s = step("travel")
    s.text, s.c, s.wx, s.wy = ts.name, ts.c, ts.wx, ts.wy
    s.atlas, s.icon = ts.atlas, ts.icon
    table.insert(G.steps, 1, s)
  end
  -- nothing at all: where to grind until the next level opens quests
  if #G.steps == 0 then
    local g = G.Grind(QB.state.level or 1, me)
    if g then
      local s = step("grind")
      s.text, s["until"], s.c, s.wx, s.wy, s.m, s.x, s.y = g.text, g["until"], g.c, g.wx, g.wy, g.m, g.x, g.y
      G.steps[1] = s
    end
  end
  local nowKey = G.FirstKey()
  G.ver = G.ver + 1 -- (the texts may have changed: the frame redraws on any Replan; the key feeds the trace)
  -- (the step frame's line: the route's Train step or not, looked at again when that changed)
  if G.trainStep ~= trainStepWas then trainStepWas = G.trainStep; if QB.Remind and QB.Remind.Dirty then QB.Remind.Dirty("class") end end
  if QB.tracing and nowKey ~= wasKey then QB.Trace("guide: first step %s -> %s", wasKey ~= "" and wasKey or "none", nowKey ~= "" and nowKey or "none") end
end

function G.Current() return G.steps[1] end

-- the party's steps (Sync's 1G line, one a member, received into m.step), by name: one list and its rows reused,
-- made again only when Sync's member-step version moved (a member came, went, or sent a step or status) or the
-- group state changed; a tick with nothing changed makes no table and no string (S:Members makes a list each call).
-- G.memberVer tells the frame which list it has
local memberSteps, memberPool = {}, {}
local memberFor, memberGrouped = -1, false
G.memberVer = 0
local function byName(x, y) return x.name < y.name end
function G.MemberSteps()
  local S = QB.Sync
  local grouped = (S and S.Members and S.members and IsInGroup and IsInGroup()) and true or false
  local ver = S and S.stepVer or 0
  if ver == memberFor and grouped == memberGrouped then return memberSteps end
  memberFor, memberGrouped = ver, grouped
  G.memberVer = G.memberVer + 1
  for k = #memberSteps, 1, -1 do memberSteps[k] = nil end
  if not grouped then return memberSteps end
  local n = 0
  -- (merge4) every member with a step: Sync takes a 1G from your group's channel alone (a whisper's sender, whom anyone
  -- of your faction can be, never has one), and drops every step once you are out of a group. The launch audit's test
  -- of the last channel heard hid a party member who shares your guild: their status there came after their step
  for _, m in ipairs(S:Members()) do
    if type(m.step) == "string" and m.step ~= "" then
      n = n + 1
      local row = memberPool[n]
      if not row then row = {}; memberPool[n] = row end
      row.name, row.class, row.text = m.name or m.key, m.class, m.step
      memberSteps[n] = row
    end
  end
  table.sort(memberSteps, byName)
  return memberSteps
end
function G.Steps() return G.steps end

-- the first step told apart as the target tells stops: its kind, its quest, its NPC and its place
function G.FirstKey()
  local s = G.steps[1]
  if not s then return "" end
  return s.kind .. ":" .. tostring(s.qid) .. ":" .. tostring(s.npc) .. ":" .. tostring(s.wx and math.floor(s.wx) or "")
end

-- "Not now" (an hour) or "Drop" (for good); the list is made again
function G.Skip(id, how)
  if not id then return end
  if how == "drop" then QB:SetSkipped(id, true)
  else laterDB().later[id] = time and time() or 0 end
  QB:MarkDirty()
end

-- the game's events, from Core.lua's frame (and Target.lua's look, for a death the client did not announce)
function G.OnEvent(event, a1, a2)
  if event == "PLAYER_DEAD" or event == "PLAYER_UNGHOST" or event == "PLAYER_ALIVE" then
    -- (no re-plan: a release is no jump, and the route stands; the list is made again with or without the corpse)
    G.Replan()
    if QB.Arrow and QB.Arrow.Invalidate then QB.Arrow.Invalidate() end
    return
  end
  if event == "TRAINER_SHOW" then onTrainer() return end
  if event == "QUEST_FINISHED" then G.DropReward() return end
  if event == "QUEST_ACCEPTED" or event == "QUEST_TURNED_IN" or event == "PLAYER_LEVEL_UP" then
    QB:MarkDirty() -- (Core.lua marks it too: the list is made again after the re-plan)
  end
end

----------------------------------------------------------------------------
-- (the hud round) the step frame's line, from here: Train and Flight path, providers of Remind.lua (piece "step"); the
-- Sleeping bag's is Camp.lua's. One source for QuestBank's step frame and Cute's band: G.Reminder
----------------------------------------------------------------------------
local R = QB.Remind
local DOT = " \194\183 "
-- the nearest trainer of your class you know of, and its minutes from you
function G.NearestTrainer(me)
  local best, bm
  for _, t in ipairs(trainers()) do
    local m = R.Minutes(me, t)
    if m and (not bm or m < bm) then best, bm = t, m end
  end
  return best, bm
end
local trainText, trainFor2 = nil, nil -- (the words while the count and the trainer stand)
R.Add({ key = "train", neverName = "Training", piece = "step", order = 210, row = "class", groups = { "class" }, untilLevel = true, timed = true,
  read = function(add, ctx)
    if G.trainStep or ctx.level <= 1 then return end -- (the route holds its Train step: one thing, one place)
    local n = G.Trainable()
    -- (a client without the spellbook's calls: the levels a class learns at say there is something, not how much)
    if n == nil and G.NeedsTraining(ctx.level) then n = -1 end
    if not n or n == 0 then return end
    local t, m = G.NearestTrainer(ctx.me)
    local rec = add()
    local cls = QB.state and QB.state.class
    local tc = type(CLASS_ICON_TCOORDS) == "table" and cls and CLASS_ICON_TCOORDS[cls] -- (SharedConstants.lua:27)
    rec.tex = (QB.Data.TEX and QB.Data.TEX.classes) or 131146
    if type(tc) == "table" and tc[4] then rec.tc = tc end
    local key = n .. ":" .. tostring(t and t.name)
    if trainFor2 ~= key then
      trainFor2 = key
      local spells = n < 0 and "new spells" or n == 1 and "1 new spell" or (n .. " new spells")
      trainText = t and ("Train: " .. spells .. DOT .. t.name) or ("Train: " .. spells .. " at your class trainer")
    end
    rec.text, rec.lit, rec.name = trainText, false, "Training"
    if t then
      rec.mins, rec.word, rec.timed = m, R.MinWord(m), true
      rec.go = { name = t.name, c = t.c, wx = t.wx, wy = t.wy }
      rec.clickWord = "show " .. t.name .. " on the arrow"
    else
      rec.word = "Train"
    end
  end,
  tip = function(tt)
    local _, list, skipped = G.Trainable()
    local name = function(id) return C_Spell and C_Spell.GetSpellName and plain(select(2, pcall(C_Spell.GetSpellName, id))) or nil end
    for i = 1, math.min(6, #list) do tt:AddLine(name(list[i]) or ("Spell " .. list[i]), 0.86, 0.86, 0.86) end
    if #skipped > 0 then
      local names = {}
      for i = 1, math.min(4, #skipped) do names[#names + 1] = name(skipped[i]) or ("Spell " .. skipped[i]) end
      tt:AddLine("Left at the trainer: " .. table.concat(names, ", ") .. ".", 0.58, 0.58, 0.58, true)
    end
  end,
})
-- the trainer's window shut, a spell learned, a new level: the spells to train read again
R.Hear("TRAINER_CLOSED", function() if G.atClassTrainer then G.atClassTrainer = false; G.TrainerClosed() end end)
for _, e in ipairs({ "SPELLS_CHANGED", "LEARNED_SPELL_IN_SKILL_LINE", "PLAYER_LEVEL_UP", "PLAYER_LEVEL_CHANGED" }) do
  R.Hear(e, function() G.TrainDirty() end)
end
R.Hear("PLAYER_REGEN_ENABLED", function() if trainAfter then G.TrainCheck() end end)

-- Flight path: a flight master of Travel's graph (D.HUB, world positions) within 300 yards that this character lacks
-- (TV.Usable), on a continent whose map the client has read (TV.DB().readC), so an old character on a fresh install is
-- never told to learn what it knows. Forever's map lists only the paths you found (Travel.lua:492-496), so
-- isUndiscovered is never the source. Looked at as you go; gone once the client names the path (TAXI_NODE_STATUS_CHANGED,
-- ERR_NEWTAXIPATH: Travel.lua reads them)
local FLIGHT_YD = 300
G.FLIGHT_YD = FLIGHT_YD
local flightText, flightFor = nil, nil
function G.FlightNear(me)
  local TV = QB.Travel
  if not (me and TV and TV.Graph and TV.Usable and TV.DB) then return nil end
  local fac = QB.faction or (QB.API.Faction and QB.API.Faction())
  if not fac then return nil end
  local db = TV.DB()
  if not (db.readC and db.readC[me.c]) then return nil end
  local ok, Gr = pcall(TV.Graph, fac)
  if not ok or not Gr then return nil end
  local best, bd
  for i = 1, Gr.h do
    if Gr.kind[i] == "m" and Gr.c[i] == me.c and (Gr.flag[i] == 0 or Gr.flag[i] == 2) and (Gr.taxi[i] or 0) > 0 then
      local d = (Gr.wx[i] - me.wx) ^ 2 + (Gr.wy[i] - me.wy) ^ 2
      if d <= FLIGHT_YD * FLIGHT_YD and (not bd or d < bd) and not TV.Usable(fac, i) then best, bd = i, d end
    end
  end
  if not best then return nil end
  return { name = Gr.town[best], c = Gr.c[best], wx = Gr.wx[best], wy = Gr.wy[best] }
end
R.Add({ key = "flight", neverName = "Flight paths", piece = "step", order = 220, row = "class", groups = { "class" }, timed = true,
  read = function(add, ctx)
    if ctx.inst then return end
    local p = G.FlightNear(ctx.me)
    if not p then return end
    local m = R.Minutes(ctx.me, p) or 0
    local rec = add()
    rec.tex, rec.atlas, rec.lit, rec.desat = 132239, "FlightPath", false, true
    if flightFor ~= p.name then flightFor = p.name; flightText = "Learn the flight path: " .. (p.name or "the flight master") end
    rec.text, rec.name = flightText, "Flight path"
    rec.mins, rec.word, rec.timed = m, R.MinWord(m), true
    rec.why = "Talk to the flight master: a flight path learned is a way the route can take."
    rec.go, rec.clickWord = { name = p.name, c = p.c, wx = p.wx, wy = p.wy }, "show it on the arrow"
  end,
})

-- the step frame's line now (Train, Flight path, Sleeping bag): Remind's record, or nil
function G.Reminder() return R.Step() end
