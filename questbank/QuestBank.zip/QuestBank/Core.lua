-- SPDX-License-Identifier: GPL-3.0-or-later
-- QuestBank core: game state, quest status, the plan, the hand-in run, settings, events, export.
-- Everything here reads the game. Nothing accepts, abandons or hands in a quest for you.
local ADDON, QB = ...
if QB.dormant then return end
QB.version = "6.3.0"
-- the engine, for a host that runs beside QuestBank and must not run a second one (Cute_Quest reads this table
-- instead of its own copy while QuestBank is loaded); QuestBank itself never reads it
QuestBankAPI = QB
QB.MAXLEVEL = 60
QB.LOG_SLOTS = 40 -- quests the Forever log holds (the game's escort prompt has said 25: see QB.EscortLimit)
QB.CAP = 60 -- the level XP runs to in the plans: set from the level lock in ReadState

local D = QB.Data
local API = {}
QB.API = API

----------------------------------------------------------------------------
-- errors: caught where QuestBank runs code, recorded with the stack, and never in your way.
-- /qb errors shows them to copy. (QUESTBANK_DEV makes them fatal again, for the test harness.)
----------------------------------------------------------------------------
local Err = {}
QB.Err = Err
local toldErrors = false

local function catch(e)
  local stack = (debugstack and debugstack(2, 16, 4)) or (debug and debug.traceback and debug.traceback("", 2)) or ""
  return { msg = tostring(e), stack = stack }
end

function Err.Record(msg, stack, where)
  QuestBankDB = QuestBankDB or {}
  QuestBankDB.errors = QuestBankDB.errors or {}
  local list = QuestBankDB.errors
  local now = date and date("%Y-%m-%d %H:%M:%S") or ""
  for _, e in ipairs(list) do
    if e.msg == msg then e.count, e.last = e.count + 1, now; return end
  end
  table.insert(list, 1, { msg = msg, stack = stack, where = where, count = 1, first = now, last = now, version = QB.version })
  while #list > 20 do table.remove(list) end
  if not toldErrors then
    toldErrors = true
    if QB.Print and not QB.quiet then QB:Print("ran into a problem and carried on. /qb errors shows the details to copy into the Discord.") end
  end
end

local function failed(err, where)
  if QUESTBANK_DEV then error(err.msg .. "\n" .. err.stack, 0) end
  Err.Record(err.msg, err.stack, where)
end

-- a function that records its errors instead of raising them. The minimap's, the arrow's and the trails' OnUpdate
-- run through one of these every frame, so a call makes no garbage: its arguments wait in upvalues for the one body
-- made here (Lua 5.1's xpcall passes none), and only an error allocates. A call made while the same one is under way
-- (the code calling itself), or with more than SAFE_ARGS arguments, takes the old way: a table and a closure.
-- (Before 5.4.2 every call took that way: about 250 bytes a frame for each OnUpdate.)
local SAFE_ARGS = 6
function QB.Safe(fn, where)
  local busy, n, a1, a2, a3, a4, a5, a6 = false, 0, nil, nil, nil, nil, nil, nil
  -- (exactly as many arguments as were given: a handler may count them, select("#", ...))
  local function body()
    if n == 0 then return fn() elseif n == 1 then return fn(a1) elseif n == 2 then return fn(a1, a2)
    elseif n == 3 then return fn(a1, a2, a3) elseif n == 4 then return fn(a1, a2, a3, a4)
    elseif n == 5 then return fn(a1, a2, a3, a4, a5) end
    return fn(a1, a2, a3, a4, a5, a6)
  end
  return function(...)
    local cnt = select("#", ...)
    local ok, err
    if busy or cnt > SAFE_ARGS then
      local args = { ... }
      ok, err = xpcall(function() return fn(unpack(args, 1, cnt)) end, catch)
    else
      busy, n, a1, a2, a3, a4, a5, a6 = true, cnt, ...
      ok, err = xpcall(body, catch)
      busy, a1, a2, a3, a4, a5, a6 = false, nil, nil, nil, nil, nil, nil
    end
    if not ok then failed(err, where) end
  end
end

-- call now, the same way (no wrapper made: a table and a closure for the arguments only when there are any)
function QB.Try(where, fn, ...)
  local cnt = select("#", ...)
  local ok, err
  if cnt == 0 then
    ok, err = xpcall(fn, catch)
  else
    local args = { ... }
    ok, err = xpcall(function() return fn(unpack(args, 1, cnt)) end, catch)
  end
  if not ok then failed(err, where) end
end

----------------------------------------------------------------------------
-- blocked actions: the game blocked a protected call and blamed QuestBank. ADDON_ACTION_BLOCKED is the chat line
-- "Interface action failed because of an AddOn"; ADDON_ACTION_FORBIDDEN the window "QuestBank has been blocked from
-- an action only available to the Blizzard UI". Both come with the addon blamed and the function, at the moment of
-- the call, so the stack then is the one that tripped. QuestBankDB.diag.blocked keeps the last 10: the function, when
-- (time()), in combat or not, and that stack with QuestBank's own files by name and every other file's path left out
-- ("(game)" for Blizzard's, "(addon)" for anyone else's). No names. Nothing is said in chat: /qb errors lists them to
-- copy (a host's error list too: Cute_Quest's Bridge.lua). (The client has no event for taint itself.)
----------------------------------------------------------------------------
local OWN = ADDON:gsub("%p", "%%%0")

local function pathOut(path)
  local p = path:gsub("\\", "/")
  local own = p:match("^.-[/@]" .. OWN .. "/(.+)$") or p:match("^%.*" .. OWN .. "/(.+)$")
  if own then return ADDON .. "/" .. own end
  if p:find("Blizzard_", 1, true) or p:find("FrameXML", 1, true) or p:find("SharedXML", 1, true) then return "(game)" end
  return "(addon)"
end

-- every path to a .lua or .xml file in a line: absolute ones (spaces and all) first, then the game's relative ones
local function scrub(line, ext)
  local tail = "[^%[%]<>\"']-%." .. ext
  line = line:gsub("%a:[\\/]" .. tail, pathOut)
  line = line:gsub("^/" .. tail, pathOut)
  line = line:gsub("([%s%[<\"'@])(/" .. tail .. ")", function(pre, path) return pre .. pathOut(path) end)
  line = line:gsub("[^%s%[%]<>\"']+%." .. ext, pathOut)
  return line
end

-- a short stack: both ends of it, at most 8 frames from the top (the blocked call and what made it) and 8 from the
-- bottom (where the chain began: an event, a click, a timer), "..." where the middle is left out. A stale taint has no
-- QuestBank frame in it at all, and then the two ends are all there is to go on. QuestBank's files by name, no other paths
local ENDS = 8
local function gap(line) return line:match("^%.%.%.$") ~= nil end
function Err.CleanStack(stack)
  if type(stack) ~= "string" then return nil end
  local out, frames = {}, 0
  for line in stack:gmatch("[^\n]+") do
    line = line:gsub('%[string "@?([^"]*)"%]', "[%1]")
    line = scrub(scrub(line, "lua"), "xml")
    line = line:gsub("^%s+", ""):gsub("%s+$", ""):sub(1, 160)
    if line ~= "" then
      out[#out + 1] = line
      if not gap(line) then frames = frames + 1 end
    end
  end
  if frames > 2 * ENDS then
    local top, bottom = {}, {}
    for _, line in ipairs(out) do if not gap(line) and #top < ENDS then top[#top + 1] = line end end
    for i = #out, 1, -1 do if not gap(out[i]) and #bottom < ENDS then table.insert(bottom, 1, out[i]) end end
    out = top
    out[#out + 1] = "..."
    for _, line in ipairs(bottom) do out[#out + 1] = line end
  end
  return table.concat(out, "\n")
end

function Err.Blocked(event, who, fn, stack)
  who, fn = QB.Plain(who), QB.Plain(fn)
  if who ~= ADDON then return false end
  fn = type(fn) == "string" and fn:sub(1, 80) or "?"
  QuestBankDB = QuestBankDB or {}
  local db = QuestBankDB
  db.diag = type(db.diag) == "table" and db.diag or {}
  local list = type(db.diag.blocked) == "table" and db.diag.blocked or {}
  db.diag.blocked = list
  local combat = InCombatLockdown and InCombatLockdown() and true or false
  local kind = event == "ADDON_ACTION_FORBIDDEN" and "forbidden" or "blocked"
  local clean = Err.CleanStack(stack)
  local last = list[#list]
  if last and last.fn == fn and last.stack == clean and last.combat == combat and last.kind == kind then
    -- the same call again (a redraw trips it once per frame it touches): counted, not stored twice
    last.n, last.at = (last.n or 1) + 1, time and time() or last.at
  else
    list[#list + 1] = { fn = fn, at = time and time() or 0, combat = combat, stack = clean, kind = kind, qb = QB.version }
    while #list > 10 do table.remove(list, 1) end
  end
  -- (said in chat once a session until the launch round: now the error list's alone, /qb errors)
  return true
end

QB.blockedFrame = CreateFrame("Frame")
QB.blockedFrame:SetScript("OnEvent", function(_, event, who, fn)
  -- the stack first, before anything else is called: the game sends these inside the blocked call. Both ends of it:
  -- the top 8 lines and the bottom 8, the game puts "..." between them
  local stack = debugstack and debugstack(2, 8, 8) or nil
  QB.Try("blocked action", Err.Blocked, event, who, fn, stack)
end)
for _, e in ipairs({ "ADDON_ACTION_BLOCKED", "ADDON_ACTION_FORBIDDEN" }) do pcall(QB.blockedFrame.RegisterEvent, QB.blockedFrame, e) end

----------------------------------------------------------------------------
-- API shims: the Forever client carries the modern API, Classic names are the fallback
----------------------------------------------------------------------------
-- A quest counts as handed in when the game's list of completed quests has it, or its flag says so.
-- The two can disagree (a player's Glowing Shard was in the list while the flag said no), so both
-- are asked. The list is read once and kept up to date on every hand-in.
local doneSet, doneCount, doneRead = nil, 0, -100

local function readDone()
  local t, n = {}, 0
  if C_QuestLog and C_QuestLog.GetAllCompletedQuestIDs then
    local ok, ids = pcall(C_QuestLog.GetAllCompletedQuestIDs)
    if ok and type(ids) == "table" then for i = 1, #ids do t[ids[i]] = true; n = n + 1 end end
  end
  if n == 0 and GetQuestsCompleted then
    local ok, list = pcall(GetQuestsCompleted)
    if ok and type(list) == "table" then for id in pairs(list) do t[id] = true; n = n + 1 end end
  end
  return t, n
end

-- what this character handed in with QuestBank watching, kept per character: uploads showed quests handed in one
-- day and missing from the game's list the next (Seeking the Kor Gem, Bailor's Ore Shipment), offered again as new
local function handedSet(create)
  local db = QuestBankDB
  if not (db and db.plans) then return nil end
  local key = QB.charKey or (UnitName and UnitName("player") and QB:CharKey()) or nil
  if not key then return nil end
  local p = db.plans[key]
  if not p and create then p = QB:Plan() end
  if p then p.handed = p.handed or {} end
  return p and p.handed or nil
end

local doneSig
function API.RefreshDone()
  local t, n = readDone()
  local sig = n
  for id in pairs(t) do sig = sig + id end
  local h = handedSet(false)
  if h then for id in pairs(h) do t[id] = true end end
  local changed = doneSet ~= nil and sig ~= doneSig
  doneSet, doneCount, doneSig = t, n, sig
  doneRead = GetTime and GetTime() or 0
  if changed then
    QB.doneVer = (QB.doneVer or 0) + 1
    if QB.loggedIn and QB.MarkDirty then QB:MarkDirty() end
  end
end

function API.MarkDone(id)
  if not doneSet then API.RefreshDone() end
  if not doneSet[id] then doneSet[id] = true; doneCount = doneCount + 1; QB.doneVer = (QB.doneVer or 0) + 1 end
  local h = handedSet(true)
  if h then h[id] = (time and time()) or 0 end
end

function API.DoneList()
  if not doneSet or doneCount == 0 then API.RefreshDone() end
  local out = {}
  for id in pairs(doneSet) do out[#out + 1] = id end
  table.sort(out)
  return out
end

-- what each source says, for /qb done
function API.DoneSources(id)
  if not doneSet or doneCount == 0 then API.RefreshDone() end
  local flag
  if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then
    local ok, v = pcall(C_QuestLog.IsQuestFlaggedCompleted, id)
    flag = ok and not (issecretvalue and issecretvalue(v)) and v == true
  elseif IsQuestFlaggedCompleted then
    local ok, v = pcall(IsQuestFlaggedCompleted, id)
    flag = ok and not (issecretvalue and issecretvalue(v)) and v == true
  end
  return doneSet[id] and true or false, flag, doneCount
end

function API.IsDone(id)
  -- an empty list usually means the game hasn't sent it yet: look again, but not on every call
  if not doneSet or (doneCount == 0 and (GetTime and GetTime() or 0) - doneRead > 5) then API.RefreshDone() end
  if doneSet[id] then return true end
  if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then
    local ok, v = pcall(C_QuestLog.IsQuestFlaggedCompleted, id)
    return ok and not (issecretvalue and issecretvalue(v)) and v == true
  end
  if IsQuestFlaggedCompleted then
    local ok, v = pcall(IsQuestFlaggedCompleted, id)
    return ok and not (issecretvalue and issecretvalue(v)) and v == true
  end
  return false
end

local function isComplete(questID, flag)
  if C_QuestLog and C_QuestLog.IsComplete then
    local ok, v = pcall(C_QuestLog.IsComplete, questID)
    if ok and v ~= nil then return v and true or false end
  end
  if IsQuestComplete then
    local ok, v = pcall(IsQuestComplete, questID)
    if ok and v ~= nil then return v and true or false end
  end
  return flag == 1 or flag == true
end

function API.Objectives(questID, index)
  local out = {}
  if C_QuestLog and C_QuestLog.GetQuestObjectives then
    local ok, objs = pcall(C_QuestLog.GetQuestObjectives, questID)
    if ok and objs then
      for _, o in ipairs(objs) do
        out[#out + 1] = { text = o.text, done = o.finished and true or false, have = o.numFulfilled, need = o.numRequired }
      end
      return out
    end
  end
  if index and GetNumQuestLeaderBoards and GetQuestLogLeaderBoard then
    for j = 1, (GetNumQuestLeaderBoards(index) or 0) do
      local text, _, finished = GetQuestLogLeaderBoard(j, index)
      out[#out + 1] = { text = text, done = finished and true or false }
    end
  end
  return out
end

-- The quest log's own XP number is not read: on Classic-style clients that means selecting each
-- entry in the game's quest log, which disturbs the log (and at the cap it shows 0 anyway). The
-- quest window at the NPC and the hand-in itself give the game's number without touching the log.

function API.LogQuests()
  local out, order = {}, {}
  local n = 0
  if C_QuestLog and C_QuestLog.GetNumQuestLogEntries then
    n = C_QuestLog.GetNumQuestLogEntries() or 0
  elseif GetNumQuestLogEntries then
    n = GetNumQuestLogEntries() or 0
  end
  for i = 1, n do
    local title, level, isHeader, flag, questID
    if C_QuestLog and C_QuestLog.GetInfo then
      local info = C_QuestLog.GetInfo(i)
      -- (hidden entries are the game's own bookkeeping, not quests you hold)
      if info and not info.isHidden then title, level, isHeader, questID = info.title, info.level, info.isHeader, info.questID end
    elseif GetQuestLogTitle then
      local t, l, _, h, _, c, _, id = GetQuestLogTitle(i)
      title, level, isHeader, flag, questID = t, l, h, c, id
    end
    if title and not isHeader and questID and questID > 0 then
      local e = { id = questID, title = title, level = level, index = i, complete = isComplete(questID, flag) }
      e.objectives = API.Objectives(questID, i)
      out[questID] = e
      order[#order + 1] = e
    end
  end
  return out, order
end

-- how many you carry (bags), or with includeBank, bags and bank together
function API.ItemCount(itemID, includeBank)
  local f = (C_Item and C_Item.GetItemCount) or GetItemCount
  if not f then return 0 end
  local ok, n = pcall(f, itemID, includeBank and true or false)
  return ok and n or 0
end

-- an item's name, link, quality and icon as the game knows them; no name yet when the client hasn't loaded the item
-- (it is asked for, and the next look has it)
function API.ItemInfo(id)
  local f = (C_Item and C_Item.GetItemInfo) or GetItemInfo
  if not (f and id) then return nil end
  local ok, name, link, quality, _, _, _, _, _, _, icon = pcall(f, id)
  name = ok and QB.Plain(name) or nil
  if type(name) ~= "string" then
    if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
    return nil, nil, nil, API.ItemIcon(id)
  end
  link, quality, icon = QB.Plain(link), QB.Plain(quality), QB.Plain(icon)
  return name, type(link) == "string" and link or nil, type(quality) == "number" and quality or nil, icon or API.ItemIcon(id)
end

function API.ItemIcon(itemID, fallback)
  local f = (C_Item and C_Item.GetItemIconByID) or GetItemIcon
  if f and itemID then
    local ok, icon = pcall(f, itemID)
    if ok and icon then return icon end
  end
  return fallback
end

-- the game's try-on click: Ctrl-click, or whatever the Key Bindings' Dressing Room modifier is (IsModifiedClick
-- "DRESSUP", as the game's own item buttons ask); plain Ctrl on a client without the check
function QB.DressClick()
  if IsModifiedClick then
    local ok, v = pcall(IsModifiedClick, "DRESSUP")
    if ok then return v and true or false end
  end
  return (IsControlKeyDown and IsControlKeyDown()) and true or false
end

-- can the dressing room put it on you? The client's own answer (C_Item.IsDressableItemByID); yes where it has none
function API.Dressable(id)
  id = QB.Plain(id)
  if type(id) ~= "number" or id <= 0 then return false end
  local f = C_Item and C_Item.IsDressableItemByID
  if not f then return true end
  local ok, v = pcall(f, id)
  if not ok then return true end
  return QB.Plain(v) ~= false
end

-- the dressing room with an item on you, as Ctrl-clicking its link does in the game: DressUpItemLink takes the link
-- (Blizzard_UIPanels_Game/Mainline/DressUpFrames.lua; the game's item buttons go through DressUpLink to the same place;
-- neither is protected). An item the client hasn't got yet is asked for, and put on when ITEM_DATA_LOAD_RESULT brings it,
-- for a few seconds: a late answer must not open the room out of the blue. True when it was put on, or will be
local dressing = {} -- [item id] = waiting for the client's answer
local dressFrame = CreateFrame("Frame")
QB.dressFrame = dressFrame
local function dressLink(link)
  local f = DressUpItemLink or DressUpLink
  if not (f and type(link) == "string") then return false end
  local ok, took = pcall(f, link)
  return (ok and took) and true or false
end
local function dressDone(id)
  dressing[id] = nil
  if next(dressing) == nil then pcall(dressFrame.UnregisterEvent, dressFrame, "ITEM_DATA_LOAD_RESULT") end
end
dressFrame:SetScript("OnEvent", QB.Safe(function(_, event, itemID, success)
  itemID = QB.Plain(itemID)
  if not (itemID and dressing[itemID]) then return end
  dressDone(itemID)
  if QB.Plain(success) == false then return end
  local _, link = API.ItemInfo(itemID)
  if link then dressLink(link) end
end, "dressing room"))
function API.DressUp(id)
  id = QB.Plain(id)
  if type(id) ~= "number" or id <= 0 then return false end
  if not (DressUpItemLink or DressUpLink) then return false end
  local _, link = API.ItemInfo(id)
  if link then return dressLink(link) end
  if not (C_Item and C_Item.RequestLoadItemDataByID) then return false end
  if next(dressing) == nil then pcall(dressFrame.RegisterEvent, dressFrame, "ITEM_DATA_LOAD_RESULT") end
  dressing[id] = true
  pcall(C_Item.RequestLoadItemDataByID, id)
  C_Timer.After(5, function() if dressing[id] then dressDone(id) end end)
  return true
end

-- Quests an item in your bags would start: the item waits in your bags, no log slot used.
function API.BagQuestStarts()
  local out = {}
  local numSlots = (C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
  local questInfo = (C_Container and C_Container.GetContainerItemQuestInfo) or GetContainerItemQuestInfo
  local itemID = (C_Container and C_Container.GetContainerItemID) or GetContainerItemID
  if not (numSlots and questInfo) then return out end
  for bag = 0, (NUM_BAG_SLOTS or 4) do
    for slot = 1, (numSlots(bag) or 0) do
      local ok, a, b, c = pcall(questInfo, bag, slot)
      if ok then
        local qid, active
        if type(a) == "table" then qid, active = a.questID, a.isActive else qid, active = b, c end
        if qid and qid > 0 and not active then out[qid] = itemID and itemID(bag, slot) or true end
      end
    end
  end
  return out
end

function API.MapID()
  if C_Map and C_Map.GetBestMapForUnit then
    local ok, m = pcall(C_Map.GetBestMapForUnit, "player")
    if ok then return m end
  end
end

-- where you stand (or a member of your party, unit, read on your map), as a place on the continent: {c, wx, wy}. Nil
-- where the client hides it (a secret map id, position or coordinate: the arrow reads this every tick, so nothing
-- here may touch one). Into the table into when given (the minimap's and the arrow's update, 20 times a second, each
-- with a table of its own), else a new one
function API.WorldPosition(unit, into)
  local m = QB.Plain(API.MapID())
  if not (m and C_Map and C_Map.GetPlayerMapPosition) then return nil end
  local ok, pos = pcall(C_Map.GetPlayerMapPosition, m, unit or "player")
  pos = ok and QB.Plain(pos) or nil
  if type(pos) ~= "table" then return nil end
  local x, y = QB.Plain(pos.x), QB.Plain(pos.y)
  if pos.GetXY then
    local ok2, gx, gy = pcall(pos.GetXY, pos)
    if ok2 then x, y = QB.Plain(gx), QB.Plain(gy) end
  end
  if type(x) ~= "number" or type(y) ~= "number" then return nil end
  return QB.Model.World(m, x * 100, y * 100, into)
end

function API.BindName()
  return GetBindLocation and GetBindLocation() or ""
end

-- seconds until the hearthstone is ready (0: it is), with its cooldown's start and duration; nil when the client
-- won't say (no answer, an error, a secret value)
function API.HearthLeft()
  local f = (C_Container and C_Container.GetItemCooldown) or GetItemCooldown
  if type(f) ~= "function" then return nil end
  local ok, start, duration = pcall(f, 6948)
  if not ok then return nil end
  start, duration = QB.Plain(start), QB.Plain(duration)
  if type(start) ~= "number" or type(duration) ~= "number" then return nil end
  if start == 0 then return 0, 0, 0 end
  return math.max(0, start + duration - GetTime()), start, duration
end

-- a hearthstone in your bags; false when the client won't say
function API.HasHearth()
  local f = (C_Item and C_Item.GetItemCount) or GetItemCount
  if type(f) ~= "function" then return false end
  local ok, n = pcall(f, 6948)
  n = ok and QB.Plain(n) or nil
  return type(n) == "number" and n > 0
end

-- the hearthstone is ready within a minute and a half, or its cooldown can't be read (the planner counts on it then)
function API.HearthReady()
  local left = API.HearthLeft()
  return left == nil or left < 90
end

function API.KnowsRiding()
  local known = IsPlayerSpell or IsSpellKnown
  if not known then return false end
  for _, id in ipairs({ 33388, 33391, 34090 }) do
    local ok, v = pcall(known, id)
    if ok and v then return true end
  end
  return false
end

-- the Cozy Sleeping Bag's buff on you: 429959 "Well-Rested" (1.60.1.70338, a hyphen) by its id first; by either name
-- when the id isn't the Legacy perk's 1225478 "Well Rested" (a hidden passive, never the bag's)
local PERK_RESTED, BAG_RESTED = 1225478, 429959
function API.HasWellRested()
  local get = C_UnitAuras and C_UnitAuras.GetAuraDataByIndex
  if get then
    local seen = false
    for i = 1, 60 do
      local ok, a = pcall(get, "player", i, "HELPFUL")
      if not ok or type(a) ~= "table" then break end
      seen = true
      local id, n = QB.Plain(a.spellId), QB.Plain(a.name)
      if id == BAG_RESTED then return true end
      if (n == "Well-Rested" or n == "Well Rested") and id ~= PERK_RESTED then return true end
    end
    if seen then return false end
  end
  if AuraUtil and AuraUtil.FindAuraByName then
    for _, name in ipairs({ "Well-Rested", "Well Rested" }) do
      local ok, found, _, _, _, _, _, _, _, _, id = pcall(AuraUtil.FindAuraByName, name, "player", "HELPFUL")
      if ok and found and QB.Plain(id) ~= PERK_RESTED then return true end
    end
  end
  return false
end

function API.Faction()
  local f = UnitFactionGroup and UnitFactionGroup("player")
  return f == "Horde" and "H" or "A"
end

function API.ClassBit()
  local _, _, id = UnitClass("player")
  if not id then return 0 end
  return 2 ^ (id - 1)
end

function API.RaceBit()
  local _, _, id = UnitRace("player")
  if not id then return 0 end
  return 2 ^ (id - 1)
end

-- one waypoint at a time: TomTom's arrow if you have it, else QuestBank's own arrow, and a link in chat that puts the
-- game's own map pin there when you click it.
-- QuestBank never sets the game's waypoint itself (C_Map.SetUserWaypoint, C_Map.ClearUserWaypoint, C_SuperTrack): the
-- game sends USER_WAYPOINT_UPDATED inside that call, and Blizzard's listeners run in it as QuestBank. The open map's
-- waypoint provider acquires its pin then (SetPassThroughButtons: blocked in combat); and the map's tracking-pin button
-- listens at all times, map open or not, and hands its state to the waypoint provider, which keeps it. A Ctrl+click on
-- the map in a later fight then places Blizzard's pin as QuestBank, and the game blocks it and blames QuestBank. No
-- timing makes the call clean. A click on the link is the player's own: Blizzard's handler (LinkUtil, LinkTypes
-- WorldMapWaypoint, ItemRefHandlers.lua) sets the pin and opens the map on it, as the game's code
--
-- TomTom draws its waypoint on the world map with HereBeDragons-Pins, whose AddWorldMapIconMap and RemoveWorldMapIcon
-- call the map canvas's AcquirePin and RemovePin there and then, map open or shut (HBD-Pins 2.0: worldmapProvider
-- HandlePin, RemovePinByIcon). Both run the scroll container's MarkCanvasDirty, which on an open, settled map writes
-- its scale and scroll. Written inside QuestBank's click, those carry taint that the map's own pins read in combat
-- (Pins.lua says how that ends), with QuestBank in the chain. On a shut map the scroll container has cleared them (its
-- OnHide) and MarkCanvasDirty writes nothing. So while the map is open TomTom is told nothing: the newest waypoint
-- waits, and TomTom hears of it once the map shuts (Pins.lua, P.AfterClose). QuestBank's arrow points at it at once
--
-- Only the real TomTom. Stand-ins answer TomTom:AddWaypoint by setting the game's own waypoint inside QuestBank's call,
-- the thing QuestBank never does: MapPinEnhanced puts in a TomTom of its own that has only AddWaypoint, or hooks the
-- real one's (C_Map.SetUserWaypoint either way); WaypointTracker's bridge can too (it marks itself). With those, QuestBank
-- shows its arrow and prints the link, as with no TomTom
local function addonLoaded(name)
  local loaded = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
  if not loaded then return nil end
  local ok, yes = pcall(loaded, name)
  if not ok then return nil end
  return QB.Plain(yes) == true
end
function API.TomTom()
  local t = TomTom
  if type(t) ~= "table" or not t.AddWaypoint or not t.IsCrazyArrowEmpty or t.isWaypointTrackerBridge then return nil end
  if MapPinEnhanced or addonLoaded("MapPinEnhanced") or addonLoaded("TomTom") == false then return nil end
  return t
end
local tomtomUid, tomtomLater
local function toTomTom(t, w)
  if tomtomUid and t.RemoveWaypoint then pcall(t.RemoveWaypoint, t, tomtomUid) end
  tomtomUid = t:AddWaypoint(w.m, w.x / 100, w.y / 100, { title = w.title, persistent = false, minimap = true, world = true })
end
local function mapOpen() return QB.Pins ~= nil and QB.Pins.MapOpen() end

-- the waypoint TomTom was kept from while the map was open, now that it is shut (nothing while it is still open).
-- True when TomTom got one
function API.TomTomLater()
  local w = tomtomLater
  if not w or mapOpen() then return false end
  tomtomLater = nil
  local t = API.TomTom()
  if not t then return false end
  toTomTom(t, w)
  return true
end

-- the game's own map-pin link for a spot (x and y 0 to 100), or nil where the game has no pins (an instance's map,
-- or a client without them): |Hworldmap:<uiMapID>:<x*10000>:<y*10000>|h, the form C_Map.GetUserWaypointHyperlink makes
function API.WaypointLink(m, x, y)
  if not (m and x and y) or m == 0 or not C_Map or not C_Map.GetUserWaypointFromHyperlink then return nil end
  if C_Map.CanSetUserWaypointOnMap then
    local ok, can = pcall(C_Map.CanSetUserWaypointOnMap, m)
    if not ok or not QB.Plain(can) then return nil end
  end
  local function at(v) return math.floor(math.max(0, math.min(100, v)) * 100 + 0.5) end
  return string.format("|cffffff00|Hworldmap:%d:%d:%d|h[Map pin]|h|r", m, at(x), at(y))
end

-- a spot on a map with no place in the world (an instance's own map): its dungeon's entrance, by the map or the maps
-- it sits in (two levels up at most), as a place and the pin's name. Nil when QuestBank knows no way in
local function entranceOf(m)
  local id = m
  for level = 0, 2 do
    if type(id) ~= "number" then return nil end
    local key = "d" .. id
    for _, cat in ipairs(D.CAT) do
      if cat.key == key then
        local e = cat.entrance
        local p = e and QB.Model.World(e.m, e.x, e.y)
        if p then return p, cat.name .. " entrance" end
        return nil
      end
    end
    if level == 2 or not (C_Map and C_Map.GetMapInfo) then return nil end
    local ok, info = pcall(C_Map.GetMapInfo, id)
    info = ok and QB.Plain(info) or nil
    id = type(info) == "table" and QB.Plain(info.parentMapID) or nil
  end
end

-- the waypoint's line in chat, with the game's map-pin link for the spot (QuestBank never sets the game's own pin: the
-- player's click on the link does, as Blizzard's code). Said for the first waypoint of a session, then only when
-- nothing on screen shows the waypoint (the arrow neither up nor shown for it) or the click was a Shift-click (the
-- game's way to put something in chat); Shift-click on the arrow says it again for the waypoint it points at
-- (API.SayWaypoint). Before 5.4.4 every click said it. API.waypointSaid: said this session
API.waypointSaid = false
local lastWaypoint = {}
function API.SayWaypoint(m, x, y, title, shown)
  if not (m and x and y) then return false end
  local link = API.WaypointLink(m, x, y)
  API.waypointSaid = true
  if QB.quiet then return true end
  QB:Print(string.format("Waypoint: %s (%.0f, %.0f).%s%s", title or "", x, y,
    shown and " The arrow shows the way until you get there." or "",
    link and (" " .. link .. " puts the game's pin there.") or ""))
  return true
end
-- the last waypoint clicked, which the arrow points at ({m, x, y, title}; the arrow's Shift-click), or nil
function API.LastWaypoint() return lastWaypoint.m and lastWaypoint or nil end

-- quiet: the run's own, as the next stop changes (Pins.lua): only TomTom hears of it, QuestBank's arrow follows the
-- route by itself. place: where the arrow points (worked out from m, x, y when not given); false: the route's own, the
-- arrow stays on what it points at, if it is up. about: what the click was for ({ qid, what, ids, item }: Arrow.lua's
-- A:Show), which ends the arrow's showing it besides getting there.
-- A click shows the place on the arrow for now, the arrow on or off (5.4.4; 5.4.3 switched an arrow that was up to
-- "where you last clicked" for good, and the route was lost after one click): it changes no plan, and once you get there
-- or its quest is done the arrow is back on the route (A:Show, A:EndTemp). The place is kept as the last one clicked,
-- for the arrow's "Where you last clicked" when you choose that in its menu
function API.SetWaypoint(m, x, y, title, quiet, place, about)
  local tomtom = API.TomTom()
  local shown = false
  if not quiet and QB.Arrow and place ~= false then
    local p, pin = place or (QB.Model and QB.Model.World and QB.Model.World(m, x, y)), title
    if not p and place == nil then p, pin = entranceOf(m) end
    local set = QB:Settings()
    if p then
      QB.Arrow:Pin(pin, p.c, p.wx, p.wy)
    else
      -- nowhere QuestBank can lead (an island, an instance with no known way in): said so, never the old place
      set.arrowPin = { name = title, none = true }
      QB.Arrow.Invalidate()
    end
    -- shown for now: the arrow up, or the arrow off for this one place until you get there (TomTom's own arrow does
    -- that job, but only as the crow flies: with TomTom QuestBank's shows the way while there is more to it than the
    -- last walk). The last click's goes either way: never the old place
    shown = QB.Arrow:Show(p and pin or title, p, about, tomtom)
    -- (the place shown carries its waypoint: the arrow's Shift-click says this one, never an older click's)
    local t = shown and QB.Arrow.temp
    if t and m and x and y and m ~= 0 then t.wp = { m = m, x = x, y = y, title = title } end
  end
  if not (m and x and y) or m == 0 then return false end
  if tomtom then
    local w = { m = m, x = x, y = y, title = title }
    if mapOpen() then
      tomtomLater = w
      -- (said once a session too, or on a Shift-click: TomTom's arrow shows the waypoint once the map shuts)
      if not quiet and (not API.waypointSaid or (IsShiftKeyDown and IsShiftKeyDown())) then
        API.waypointSaid = true
        QB:Print(string.format("Waypoint: %s (%.0f, %.0f). TomTom gets it when you close the map.", title or "", x, y))
      end
    else
      tomtomLater = nil
      toTomTom(tomtom, w)
    end
    return true
  end
  if quiet then return false end
  -- the arrow up and moved there (it points at it, or says it knows no way) or shown for this one: the line once a
  -- session. The route's own asked for (/qb next: the arrow stays as it is) is always said
  if place ~= false then
    lastWaypoint.m, lastWaypoint.x, lastWaypoint.y, lastWaypoint.title = m, x, y, title
    local shift = IsShiftKeyDown and IsShiftKeyDown()
    if API.waypointSaid and (shown or QB:Settings().arrow) and not shift then return true end
  end
  API.SayWaypoint(m, x, y, title, shown)
  return true
end

----------------------------------------------------------------------------
-- the bank: what each character keeps there, read whenever the bank is open and remembered
-- QuestBankDB.bank[character] = { at = time read, items = { [itemID] = count } }
----------------------------------------------------------------------------
local Bank = {}
QB.Bank = Bank

-- the items quests for your faction ask for, worked out once
local bankItems
local function bankItemList()
  if bankItems then return bankItems end
  local fac = QB.faction or API.Faction()
  local seen, out = {}, {}
  for qid, list in pairs(D.REQ) do
    local r = D.Q[qid]
    local side = r and r[3] or 0
    if side == 0 or (side == 1 and fac == "A") or (side == 2 and fac == "H") then
      for _, it in ipairs(list) do
        if not seen[it[1]] then seen[it[1]] = true; out[#out + 1] = it[1] end
      end
    end
  end
  bankItems = out
  return out
end

function Bank.Scan()
  if not QB.bankOpen then return end
  local items = {}
  for _, id in ipairs(bankItemList()) do
    local extra = API.ItemCount(id, true) - API.ItemCount(id)
    items[id] = extra > 0 and extra or false
  end
  for _, it in ipairs(D.TRACKED_ITEMS) do
    local extra = API.ItemCount(it.id, true) - API.ItemCount(it.id)
    items[it.id] = extra > 0 and extra or false
  end
  local keep = {}
  for id, n in pairs(items) do if n then keep[id] = n end end
  QuestBankDB.bank = QuestBankDB.bank or {}
  QuestBankDB.bank[QB:CharKey()] = { at = time(), items = keep }
end

-- how many sit in your bank, and when that was read (nil: never)
function Bank.Count(itemID)
  if QB.bankOpen then return math.max(0, API.ItemCount(itemID, true) - API.ItemCount(itemID)), time() end
  local b = QuestBankDB and QuestBankDB.bank and QuestBankDB.bank[QB:CharKey()]
  if not b then return 0, nil end
  return b.items[itemID] or 0, b.at
end

-- what a quest asks you to bring: { id, name, need, bags, bank }
function Bank.Items(q)
  local list = D.REQ[q.id]
  if not list then return nil end
  local out = {}
  for _, it in ipairs(list) do
    local bank = Bank.Count(it[1])
    out[#out + 1] = { id = it[1], need = it[2], name = it[3] ~= "" and it[3] or ("item " .. it[1]), bags = API.ItemCount(it[1]), bank = bank }
  end
  return out
end

----------------------------------------------------------------------------
-- helpers
----------------------------------------------------------------------------
-- (a host that runs this engine inside its own addon replaces QB.Print with its own prefix, and sets QB.quiet: the
-- lines a step frame and an arrow already say, a waypoint clicked, a run's start and end, and the errors line, stay out
-- of chat. A quest complete or gone from the log is said only when the player asks, sayXP, in a host too: the merge
-- review, Cute's "Say XP after each hand-in" says so)
function QB:Print(msg)
  if DEFAULT_CHAT_FRAME then
    DEFAULT_CHAT_FRAME:AddMessage("|cffc6af8dQuestBank|r " .. msg)
  else
    print("QuestBank " .. msg)
  end
end

function QB.Comma(n)
  local s = tostring(math.floor((n or 0) + 0.5))
  local k
  repeat s, k = s:gsub("^(%-?%d+)(%d%d%d)", "%1,%2") until k == 0
  return s
end

function QB.Short(n)
  n = n or 0
  if n >= 1000 then return (string.format("%.1fk", n / 1000):gsub("%.0k", "k")) end
  return tostring(n)
end

-- is version a newer than b ("3.3.0" against "3.2.1")
function QB.Newer(a, b)
  local function parts(v)
    local x, y, z = tostring(v or ""):match("^(%d+)%.(%d+)%.?(%d*)")
    return tonumber(x) or 0, tonumber(y) or 0, tonumber(z) or 0
  end
  local a1, a2, a3 = parts(a)
  local b1, b2, b3 = parts(b)
  if a1 ~= b1 then return a1 > b1 end
  if a2 ~= b2 then return a2 > b2 end
  return a3 > b3
end

QB.DOWNLOAD = "https://foreverrank.com/questbank/"

-- a party or guild member runs a newer QuestBank: say so once a session (Settings can turn it off)
function QB:SawVersion(v, who)
  if not v or not v:match("^%d+%.%d+") or not QB.Newer(v, QB.version) then return end
  if QB.newest and not QB.Newer(v, QB.newest.version) then return end
  QB.newest = { version = v, who = who }
  if self:Settings().updates and not QB.toldNewer then
    QB.toldNewer = true
    QB:Print(string.format("QuestBank %s is out (%s runs it); you have %s. Type /qb update for the download link.", v, who or "someone", QB.version))
  end
end

function QB.Clock(minutes)
  local m = math.floor((minutes or 0) + 0.5)
  return string.format("%d:%02d", math.floor(m / 60), m % 60)
end

----------------------------------------------------------------------------
-- the catalog: every quest a character around level 20 can hold, both factions
-- D.Q[id] = { level, req, side, base, mult, turn NPC, giver NPC, category, class mask, flags }
-- flags: 1 dungeon, 2 group, 4 starts from an item, 8 multiplier not read from its page
----------------------------------------------------------------------------
local Q = {}
QB.Quest = Q
local cache = {}

local function npcView(i)
  local n = i and i > 0 and D.NPC[i]
  if not n then return nil end
  return { n = n[1], m = n[2], x = n[3], y = n[4], inside = n[5] < 0, place = n[12], idx = i }
end

-- A quest's view: { id } until a field is read, each field worked out from the catalog's row the first time it is
-- read and kept in the view (a field with no value is looked up again). Before 5.4.2 every view was built whole, 34
-- fields, and the minimap's dungeon count makes one for every quest of the catalog at login: about 7 MB kept (LuaJIT's
-- measure; more in the game's Lua) for quests nobody looks at. What other code writes on a view (liveFull, logXp)
-- stays as before.
--   VIEW[field] = function(id, row, view) -> the value
local floor = math.floor
local VIEW = {
  name = function(id) return D.QN[id] or ("Quest " .. id) end,
  lvl = function(_, r) return r[1] end,
  req = function(_, r) return r[2] end,
  side = function(_, r) return r[3] end,
  base = function(_, r) return r[4] end,
  mult = function(_, r) return r[5] end,
  turnIdx = function(id, r)
    if D.TURNH and D.TURNH[id] and (QB.faction or API.Faction()) == "H" then return D.TURNH[id] end
    return r[6]
  end,
  giveIdx = function(_, r) return r[7] end,
  turn = function(_, _, v) return npcView(v.turnIdx) end,
  give = function(_, r) return npcView(r[7]) end,
  cat = function(_, r) return D.CAT[r[8]] end,
  cls = function(_, r) return r[9] end,
  flags = function(_, r) return r[10] end,
  pre = function(id) return D.PRE[id] end,
  tip = function(id) return D.TIPS[id] end,
  bag = function(id) return D.BAGQ[id] end,
  follow = function(id) return D.FOLLOW[id] end,
  race = function(id) return D.RACE[id] end,
  excl = function(id) return D.EXCL[id] end,
  nextSteps = function(id) return D.NEXT[id] end,
  note = function(id) return D.NOTE and D.NOTE[id] end, -- where a number comes from, or what Blizzard changed since
  icon = function(id, _, v)
    local bag, cat = v.bag, v.cat
    return D.QICON[id] or (bag and bag[3] ~= 2 and API.ItemIcon(bag[1])) or API.ItemIcon(D.QITEM[id])
      or (cat and cat.icon) or D.TEX.questGeneric
  end,
}
-- the flag bits, true or false
local FLAG = {
  dungeon = 1, group = 2,
  unconfirmed = 8,
  classic = 16,        -- from the Classic database, not seen in Forever yet
  dungeonMult = 32,    -- multiplier taken from its dungeon's other quests
  xpUnknown = 64,
  sodLeftover = 128,   -- Season of Discovery data whose NPC isn't known in Forever
  nerfed = 256,        -- multiplier computed from the pre-cut read (D.NERF): the extra above x1 halved
  confirmed = 512,     -- XP as the game paid it after the cut (a hand-in or quest window, build 70170+)
  wanted = 1024,       -- a wanted poster
  escort = 2048,       -- an escort
  repeatable = 4096,   -- repeatable: in the reward finders alone
  near = 8192,         -- kept as read: the game paid within a few percent of this number
  seenOnly = 16384,    -- known only from players' notes (not on Wowhead or in the Classic database)
  reqStated = 32768,   -- the required level as Blizzard's notes give it
  surveyOnly = 65536,  -- known from the quest survey alone (Survey.lua): no giver, place or side
  turnIn = 131072,     -- a Craftsman's Writ's delivery: no XP, in the reward finders alone
}
for k, b in pairs(FLAG) do VIEW[k] = function(_, r) return floor(r[10] / b) % 2 == 1 end end
Q.FIELDS = VIEW -- (the harness compares every field with the views as 5.4.1 built them)

local viewMT = { __index = function(v, k)
  local f = VIEW[k]
  if not f then return nil end
  local id = rawget(v, "id")
  local r = D.Q[id]
  if not r then return nil end
  local x = f(id, r, v)
  if x ~= nil then rawset(v, k, x) end
  return x
end }

function Q.Get(id)
  local c = cache[id]
  if c ~= nil then return c or nil end
  if not D.Q[id] then cache[id] = false; return nil end
  c = setmetatable({ id = id }, viewMT)
  cache[id] = c
  return c
end

-- a quest's row changed under the cache (the quest survey adds and fills in rows): read it afresh next time
function Q.Forget(id) cache[id] = nil end

function Q.Full(q)
  return q.liveFull or QB.Model.Full(q)
end

-- Model reads this: the game's number if it reported one, else Classic base x the Forever multiplier
function Q.Raw(q)
  if q.liveFull then return q.liveFull end
  return math.floor((q.base or 0) * (q.mult or 1) + 0.5)
end

function Q.Label(id)
  if type(id) == "table" then
    local names, seen = {}, {}
    for _, x in ipairs(id) do
      local n = Q.Label(x)
      if not seen[n] then seen[n] = true; names[#names + 1] = n end
    end
    return table.concat(names, " or ")
  end
  return D.STEPNAME[id] or D.QN[id] or ("quest " .. id)
end

-- a prerequisite: one quest, or a list of which any one will do
-- the quests each plain step leads to (every quest whose chain lists it), built once from D.PRE
local laterOf
local function laterSteps(id)
  if not laterOf then
    laterOf = {}
    for x, pre in pairs(D.PRE or {}) do
      for _, p in ipairs(pre) do
        if type(p) ~= "table" then laterOf[p] = laterOf[p] or {}; table.insert(laterOf[p], x) end
      end
    end
  end
  return laterOf[id]
end

local NO_STEPS = {}
-- a later step of this quest's chain is in your log or done: the game offers a step only once the ones before it
-- are handed in, so this one is behind you. Returns that later step and "held" or "done".
function Q.Behind(id)
  local s = QB.state
  for _, x in ipairs(laterSteps(id) or NO_STEPS) do
    if s and s.log and s.log[x] then return x, "held" end
    if API.IsDone(x) then return x, "done" end
  end
  return nil
end

local function preDone(p)
  if type(p) == "table" then
    for _, x in ipairs(p) do if API.IsDone(x) or Q.Behind(x) then return true end end
    return false
  end
  return API.IsDone(p) or Q.Behind(p) ~= nil
end
Q.PreDone = preDone

-- the step of this group (or the step itself) that is in your log
local function heldOf(p)
  local s = QB.state
  if not (s and s.log) then return nil end
  if type(p) ~= "table" then return s.log[p] and p or nil end
  for _, x in ipairs(p) do if s.log[x] then return x end end
  return nil
end
Q.HeldOf = heldOf

-- the chain up to and including this quest, for tooltips: "A Watchful Eye > Looking Further > Morganth"
function Q.ChainText(q)
  if not q.pre then return nil end
  local parts = {}
  for _, p in ipairs(q.pre) do parts[#parts + 1] = (preDone(p) and "|cff808080" or "") .. Q.Label(p) .. (preDone(p) and "|r" or "") end
  parts[#parts + 1] = q.name
  return table.concat(parts, " > ")
end

function Q.ForMe(q)
  local fac = QB.faction or API.Faction()
  if q.side == 1 and fac ~= "A" then return false end
  if q.side == 2 and fac ~= "H" then return false end
  if q.cls and q.cls > 0 then
    local bit = API.ClassBit()
    if bit > 0 and (math.floor(q.cls / bit) % 2) == 0 then return false end
  end
  if q.race then
    local bit = API.RaceBit()
    if bit > 0 and bit <= 128 and (math.floor(q.race / bit) % 2) == 0 then return false end
  end
  return true
end

----------------------------------------------------------------------------
-- XP straight from the game: what the quest log, the NPC's quest window or a hand-in reported.
-- QuestBankDB.live[id] = { full = XP at full value, lvl = your level then, src = "log" | "npc" | "turnin" | "party" }
----------------------------------------------------------------------------
local Live = {}
QB.Live = Live

-- A quest's reward items: what your own quest window showed ("game"), else what the game told the quest survey
-- (Survey.lua: "survey"), else the catalog's list ("catalog"), else "unknown" (no source lists them yet) or "none" (the
-- quest gives no items; "survey" when the game said so). Returns { c = choose one, r = always }, how
function Q.Rewards(q)
  local own = QuestBankDB and QuestBankDB.disc and QuestBankDB.disc.q and QuestBankDB.disc.q[q.id]
  if own and type(own.rw) == "table" then return own.rw, "game" end
  local D = QB.Data
  local how = D.RSURV and D.RSURV[q.id] and "survey" or "catalog"
  if D.RITEMS and D.RITEMS[q.id] then return D.RITEMS[q.id], how end
  if D.RUNK and D.RUNK[q.id] then return nil, "unknown" end
  return nil, how == "survey" and "survey" or "none"
end

-- the game's number behind a reading taken under the +3% buff: the game rounds quest XP to its grid (5 up to 100,
-- 10 up to 500, 25 up to 1,000, 50 above), and the buff pays that times 1.03, give or take one (390 shows 401,
-- 1,250 shows 1,288). A reading on the grid is taken as it is: a few buffed values land on the grid themselves
-- (850 shows 875, 340 shows 350, 5,000 shows 5,150) and can't be told from a real number by arithmetic alone
function QB.Unbuff(xp)
  local R = QB.Model and QB.Model.RoundXp
  if not R or type(xp) ~= "number" or xp <= 0 or R(xp) == xp then return xp end
  local g = R(xp / 1.03)
  for _, cand in ipairs({ g, R(g - 1), R(g + 60) }) do
    if cand > 0 and math.abs(cand * 1.03 - xp) <= 1 then return cand end
  end
  return xp
end

function Live.Record(id, xp, level, src)
  local q = Q.Get(id)
  if not (q and xp and xp > 0 and level) then return end
  local pct = QB.Model.Pct(q.lvl, level)
  if pct < 100 then return end -- a grey quest's number says little about its full value
  -- a temporary +3% XP buff on the player (Well Rested from the sleeping bag, it seems) shows the game's number times
  -- 1.03: kept as the game's own number, so the reading stays right once the buff is gone
  local full = QB.Unbuff(xp)
  -- a number far off what the quest could pay is someone else's quest, not this one's
  local listed = QB.Model.Listed(q)
  if listed > 0 and (full > listed * 6 or full < listed * 0.2) then return end
  -- a party member's number within a few percent of the catalog's confirms it rather than correcting it: their
  -- game may carry a bonus yours doesn't (the old build's rest stacks), and your own windows and hand-ins still win
  if src == "party" and listed > 0 and math.abs(full - listed) <= listed * 0.05 then return end
  QuestBankDB.live = QuestBankDB.live or {}
  local old = QuestBankDB.live[id]
  if old and old.src ~= "party" and src == "party" then return end
  QuestBankDB.live[id] = { full = full, lvl = level, src = src, at = date("%Y-%m-%d") }
  if q.liveFull ~= full then QB.liveVer = (QB.liveVer or 0) + 1 end
  q.liveFull = full
  if QB.Sync and src ~= "party" then QB.Sync:QueueLive(id, full, level) end
end

function Live.Apply()
  local db = QuestBankDB
  db.live = db.live or {}
  -- Blizzard cut dungeon quests' extra XP (D.NERF, 2026-10-01): what the game said about those quests before the
  -- cut is stale, so it is forgotten once; fresh quest windows and hand-ins teach the new numbers. A pre-cut
  -- number is at least 1.4 times the cut one, so a reading well above the catalog's value is the stale kind and
  -- one at or below it is fresh and stays. (Era 2 was 3.4.4's purge; 3.4.6 runs once more for the quests it
  -- left out, keeping what 3.4.4 and 3.4.5 users learned since.)
  local era = db.liveEra or 0
  if era < 3 then -- (by era, not by D.NERF: the cut happened whatever the catalog's later state)
    for id, v in pairs(db.live) do
      local q = Q.Get(id)
      if q then
        local stale = false
        if q.nerfed or q.confirmed or (q.mult or 1) > 1 then
          stale = (v.full or 0) > QB.Model.Listed(q) * 1.15
        elseif q.dungeon and q.unconfirmed and not q.xpUnknown and era < 2 then
          stale = true -- an unread dungeon quest: the old reading may carry the old extra (a quest with no XP in
                       -- the catalog keeps its reading: a high number beats none)
        end
        if stale then db.live[id] = nil; q.liveFull = nil end
      end
    end
    db.liveEra = 3
  end
  for id, v in pairs(db.live) do
    local q = Q.Get(id)
    if q then
      -- a reading saved before 3.5.3 may carry the +3% buff: kept as the game's own number from here on
      local f = QB.Unbuff(v.full)
      if f ~= v.full then v.full = f end
      q.liveFull = f
    end
  end
end

-- a value from the client, or nil when the client hides it (a secret value): for ids and names before any use
function QB.Plain(v)
  if issecretvalue and issecretvalue(v) then return nil end
  return v
end

-- the game's own art where the client has the atlas, QuestBank's file otherwise. True when it was the atlas. The
-- texture's corners are reset first: set after an atlas they could replace the atlas's own part of its file
function QB.Art(tex, atlas, file)
  local ok, info = false, nil
  if atlas and C_Texture and type(C_Texture.GetAtlasInfo) == "function" then ok, info = pcall(C_Texture.GetAtlasInfo, atlas) end
  local use = ok and info ~= nil and tex.SetAtlas ~= nil
  tex:SetTexCoord(0, 1, 0, 1)
  if use then tex:SetAtlas(atlas, false) else tex:SetTexture(file) end
  return use
end

-- what the game hands addons for a quest's XP on this client, the last dozen times (window and hand-in): the
-- uploads show whether the number is there, hidden (a secret value) or missing, which decides how the catalog learns
function QB.NoteXPSeen(how, id, xp)
  local db = QuestBankDB
  if not db then return end
  db.diag = db.diag or {}
  local d = db.diag.xp or {}
  db.diag.xp = d
  local secret = issecretvalue or function() return false end
  local kind = secret(xp) and "secret" or type(xp)
  -- the helpful auras up at the time, by spell id: a +3% XP buff comes and goes, and these name it
  local auras
  if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
    auras = {}
    for i = 1, 40 do
      local ok, a = pcall(C_UnitAuras.GetAuraDataByIndex, "player", i, "HELPFUL")
      if not ok or not a then break end
      local sid = a.spellId
      if type(sid) == "number" and not secret(sid) then auras[#auras + 1] = sid end
      if #auras >= 16 then break end
    end
  end
  d[#d + 1] = { how = how, id = secret(id) and -1 or id, kind = kind, v = kind == "number" and xp or nil,
                lvl = UnitLevel("player"), at = date("%Y-%m-%d %H:%M"), auras = auras }
  while #d > 12 do table.remove(d, 1) end
end

-- the client's build and interface number, and whether the retired ForeverProbe addon is still installed for this
-- character (disabled, not loadable and the game's reason, or loaded and which version). The probe part is only
-- written while ForeverProbe is there: the old Windows uploader reads it, and once the folder is gone it has
-- nothing to give advice about. No names
function QB.NoteAddons()
  local db = QuestBankDB
  if not db then return end
  db.diag = db.diag or {}
  local A = C_AddOns or {}
  local function call(f, ...)
    if type(f) ~= "function" then return nil end
    local ok, a, b, c, d, e, g = pcall(f, ...)
    if not ok then return nil end
    return a, b, c, d, e, g
  end
  local plain = function(v) return QB.Plain(v) end
  local name = "ForeverProbe"
  local exists = call(A.DoesAddOnExist, name)
  local info = A.GetAddOnInfo or GetAddOnInfo
  local _, title, _, loadable, reason = call(info, name)
  -- nil, not false, when the client gave no way to ask
  if exists == nil and type(info) == "function" then exists = title ~= nil end
  local function flag(v) if v == nil or (issecretvalue and issecretvalue(v)) then return nil end return v and true or false end
  exists = flag(exists)
  local function why(v) v = plain(v); return type(v) == "string" and v ~= "" and v or nil end
  local loading, loaded = call(A.IsAddOnLoaded or IsAddOnLoaded, name)
  local me = plain(UnitName("player")) -- a hidden name would make these calls error; nil asks for all characters
  local state = call(A.GetAddOnEnableState, name, me)
  local forMe, forMeWhy = call(A.IsAddOnLoadable, name, me)
  local loadError = call(A.DoesAddOnHaveLoadError, name)
  local checkOn = flag(call(A.IsAddonVersionCheckEnabled)) -- true: out-of-date addons are blocked
  forMe = flag(forMe)
  local _, build, _, iface = GetBuildInfo()
  db.diag.addons = {
    at = date("%Y-%m-%d %H:%M"), build = plain(build), iface = plain(iface), qb = QB.version,
    versionCheck = checkOn,
    maxQuests = (QB.EscortLimit()), -- what the game's escort prompt counts as a full log (25 on older builds, 40 on 70235)
    probe = exists and {
      exists = exists, -- always true: the old uploader reads it
      loaded = flag(loaded) or flag(loading) or false,
      loadable = flag(loadable) or false,
      reason = why(reason),
      enabled = type(plain(state)) == "number" and state or nil, -- 0 off, 1 some characters, 2 all
      forMe = forMe, forMeWhy = why(forMeWhy),
      loadError = flag(loadError) or nil,
      version = exists and plain(call(A.GetAddOnMetadata or GetAddOnMetadata, name, "Version")) or nil,
      iface = exists and plain(call(A.GetAddOnInterfaceVersion, name)) or nil,
      running = ForeverProbeDB ~= nil and type(ForeverProbeDB) == "table" and type(ForeverProbeDB.meta) == "table"
        and plain(ForeverProbeDB.meta.addon) or nil, -- what the loaded probe wrote last; nil when it never ran
    } or nil,
  }
end

function Live.Source(q)
  local v = QuestBankDB.live and QuestBankDB.live[q.id]
  if not v then return nil end
  local where = { log = "your quest log", npc = "the quest window", turnin = "a hand-in", party = "a party member's game" }
  return string.format("the game (%s, level %d)", where[v.src] or v.src, v.lvl)
end

-- the quest the NPC window shows, and the XP it offers
local function windowXP(src, event)
  local id = GetQuestID and GetQuestID()
  local xp = GetRewardXP and GetRewardXP()
  QB.NoteXPSeen(event == "QUEST_DETAIL" and "detail" or "complete", id, xp)
  if issecretvalue and (issecretvalue(id) or issecretvalue(xp)) then return end -- hidden from addons: nothing to learn
  if id and id > 0 and xp and xp > 0 then Live.Record(id, xp, UnitLevel("player"), src) end
end
QB.WindowXP = windowXP

----------------------------------------------------------------------------
-- settings: account-wide switches, and one plan per character
----------------------------------------------------------------------------
local DEFAULTS = {
  mounted = "auto", goal = "hour", routeMode = "now", tab = 6, pins = true,
  minimap = { angle = 205, hide = false }, share = { party = true, guild = true },
  post = { party = true, guild = true, auto = true }, updates = true,
  -- how far above and below your level suggestions reach ("auto": 12 above while banking, 4 while
  -- questing, 7 below), and the zones, dungeons (by D.CAT key) and continents (0 Eastern Kingdoms,
  -- 1 Kalimdor) you told QuestBank to leave out of its suggestions
  rangeAbove = "auto", rangeBelow = "auto", skipCat = {}, skipCont = {},
  -- off until asked for: accept quests for you (at an NPC, and ones a party member shares), hand finished ones in
  -- for you (Auto.lua decides when that is wise), and two party-chat lines. Accept for me is a choice (5.4.4): "off",
  -- "route" (quests on your route: your pick-up list and the chains you are on) or "worth" (any quest worth taking:
  -- never grey, never under the planner's low-value line); autoAcceptOther: what "worth" does with one outside your
  -- route, "accept" it or "leave" the game's quest window to you
  autoAccept = "off", autoAcceptOther = "accept", autoTurnIn = false, sayAccept = false, sayComplete = false,
  autoKey = "shift", -- hold this key at an NPC to decide a quest yourself: shift, ctrl, alt, or none (Auto.lua)
  -- where you are decides: each context may override autoAccept, autoTurnIn, sayAccept, sayComplete and clockShow;
  -- a key left out inherits the setting above (QB:Opt). Checked in this order: dungeon, pvp, party, cap
  profiles = { dungeon = {}, pvp = {}, party = {}, cap = {} },
  clock = { show = false }, clockLevelMsg = true, -- the timer strip (Timer.lua) and the level-up line
  -- the route on the minimap (Minimap.lua): the stops and their lines, your pick-up list, dungeon entrances, the
  -- objectives of the quests in your log, the target's name
  minimapPins = true, minimapLines = true, minimapPickups = true, minimapEntrances = true,
  minimapObjectives = true, minimapLabel = true,
  -- how the minimap's markers are drawn: QuestTrail's look (Krom's coloured diamonds, glyphs, step circles and the
  -- compass dial; the default) or the game's own icons and numbered pins. QuestTrail's settings: the marker size in
  -- pixels (mmRing, 8 to 40), the ! and ? as a share of it (mmGlyphPct), each quest's own colour or one colour for
  -- all (mmColor "quest" or "single", oneColor), the strokes' width and opacity (zmWidth 2 to 24, zmAlpha 0.2 to 1),
  -- your arrow's size on the minimap (mmArrowSize, the party dots follow it), the golden path (goldenPath; its pieces
  -- in metres, its width, its opacity and its colour), the compass dial's size in screen pixels (compassSize 24 to
  -- 128) and a dark backdrop behind it (compassBg). The strokes and the golden path a quarter thinner since 5.4.4
  -- (6 pixels; 8 before, and a save still at 8 is moved to 6 once: QB:Settings)
  markerStyle = "questtrail", mmRing = 18, mmGlyphPct = 100, mmColor = "quest", oneColor = { 1, 0.82, 0 },
  zmWidth = 6, zmAlpha = 1, mmArrowSize = 32,
  goldenPath = true, gpSpacing = 15, gpWidth = 6, gpAlpha = 0.9, gpColor = { 1, 0.82, 0 },
  compassSize = 48, compassBg = false,
  -- the direction arrow's look (Arrow.lua): QuestBank's own arrow ("questbank": the game's tutorial arrow coloured by
  -- your heading, its glow and pulses; the default again since 5.4.4) or QuestTrail's compass ("compass")
  arrowStyle = "questbank",
  -- QuestBank's quest icons on the world map and the Map page, in percent of the game's own pins' art (their click area
  -- stays the game's): half since 5.4.4 for a save without one; a new install takes the game's own size (QB:Settings)
  mapIconPct = 50,
  -- the minimap's far zoom over the game's tiles and its drag (MinimapView.lua); back to you after a drag; your party
  -- and the quest's areas on the far ground; the stops the strokes join (MinimapRoute.lua; QuestTrail's 16)
  mmExtended = true, mmCenter = true, mmParty = true, mmAreas = true, minimapSteps = 16,
  -- the interact light (Glow.lua): its style (sparkle, light, or the game's own highlight), NPCs lit too (quest NPCs,
  -- and the trainers you can use), every other NPC too (everyNpc), plain objects too, kept on in a fight, and the
  -- game's health bar over what it lights (plates: the soft-interact nameplate; off since 5.4.4)
  glow = { on = true, style = "sparkle", npcs = true, everyNpc = false, other = true, combat = false, plates = false },
  walkRecord = true, walkShow = false, -- walked trails (Walk.lua): noted as you go; drawn on the minimap when asked
  -- the camp bar (Camp.lua): Well Fed, the campfire (Basic Campfire or a kit), camp features with their cooldown, the
  -- sleeping bag; hidden in dungeons when quietInstance. campBar = false hides the bar. buffs: the missing-buffs banner
  -- when you leave a town. 5.4.4's suggestions, each its own: sit (by a fire near you), wood (a seller when the fire
  -- burned out), bagChain (where the sleeping bag's quest chain goes on)
  remind = { camp = true, food = true, bag = true, fire = true, quietInstance = true, buffs = true, sit = true, wood = true, bagChain = true, party = true }, campBar = true,
  arrowMode = "route", -- what the direction arrow points at: route, handin, pickup, or pin (Arrow.lua)
  -- the arrow guides you step by step, by the flight paths you know, boats and the hearthstone (Travel.lua); off, it
  -- points straight at its target. arrowHearth: the hearthstone may be one of the steps
  arrowTravel = true, arrowHearth = true,
  noteGame = true, -- note the spells and item tooltips the Forever client shows, for foreverrank.com (Game.lua)
  survey = true, -- ask the game about quests by id, out of combat, and use their rewards at once (Survey.lua)
  -- quest icons on each zone's world map (QuestMap.lua, Forever only): all of them, then where quests you can take
  -- start (!), where finished ones are handed in (?), and the objectives and quest-item drops of the quests in your log
  mapIcons = true, mapGive = true, mapTurn = true, mapObj = true,
  mapPage = true, -- the Map key and the sidebar open QuestBank's own map page (MapPage.lua), not the game's map
  -- the Map page's switches beyond those: the dungeons' entrances (on the world map too), and on the page the route (its
  -- pins, strokes and the arrow's step) and the flight paths
  mapDungeons = true, mapRoute = true, mapFlights = true,
  -- the kinds the Dungeon Journal lists and pins (DungeonMap.lua): "other" is chests and events
  djShow = { boss = true, rare = true, trash = false, other = true },
  -- the Quest Log's reward finders (Best gear, Trinkets, Recipes): also quests you can take within 2 levels, not only now
  finderAhead = false,
  -- the Guide (6.0, Guide.lua and StepFrame.lua): on, the step frame shown, unlocked, at scale 1 where it was dragged.
  -- welcome: "fresh" asks the auto choice in the step frame once; "ask" asks a 5.x save whether to guide (QB.Migrate600)
  guide = { on = true, frame = true, locked = false, scale = 1, hideTracker = true },
  minimapGivers = true, -- a ! on the minimap for every quest you can take now (Minimap.lua)
  mapLowLevel = false, -- (6.1.1) quests the game counts as trivial (grey): their ! on the world map, the Map page and the minimap
  wholeRoute = false, -- (6.1.1) the strokes on to the stops after the one the arrow leads to (Minimap.lua, MapPage.lua): one at a time
  tipProgress = true,   -- "Kobold Vermin: 3/8 (Kobold Camp Cleanup)" in mob and object tooltips (Tips.lua)
}

function QB:Settings()
  QuestBankDB = QuestBankDB or {}
  local db = QuestBankDB
  db.chars = db.chars or {}
  for k, v in pairs(db) do
    if type(v) == "table" and v.completed and k ~= "chars" then db.chars[k] = v; db[k] = nil end
  end
  db.settings = db.settings or {}
  local s = db.settings
  local fresh = next(s) == nil
  for k, v in pairs(DEFAULTS) do
    if s[k] == nil then
      if type(v) == "table" then
        local c = {}
        for kk, vv in pairs(v) do c[kk] = vv end
        s[k] = c
      else
        s[k] = v
      end
    end
  end
  -- (6.1.1's new switch inside a table a save already has: the default)
  if type(s.guide) == "table" and s.guide.hideTracker == nil then s.guide.hideTracker = true end
  -- (the windows round) a new install draws the quest icons at the game's own size: half-size art beside the game's
  -- full-size pins looked soft ("icons on map are scuffed as they are wrong size"); a save keeps the size it has
  if fresh then s.mapIconPct = 100 end
  db.turnins = db.turnins or {}
  db.runs = db.runs or {}
  db.plans = db.plans or {}
  if not QB.pruned then QB.pruned = true; QB.PruneLogs(db) end
  if s.v544 == nil then QB.Migrate544(s) end
  if s.v600 == nil then QB.Migrate600(s, fresh) end
  return s
end

-- A save from before 5.4.4, once: Accept for me was a switch (on: Quests worth taking, as it took every quest that
-- wasn't grey; the context rows keep their on and off, read by Auto.lua's AcceptMode), the strokes' and the golden
-- path's width 8 the default (no setting ever showed them: the old default moves to the new one), and a click pinned
-- the arrow for good (arrowMode "pin" came from a click: back to the route)
function QB.Migrate544(s)
  s.v544 = true
  if s.autoAccept == true then s.autoAccept = "worth" elseif s.autoAccept ~= "route" and s.autoAccept ~= "worth" then s.autoAccept = "off" end
  if s.zmWidth == 8 then s.zmWidth = 6 end
  if s.gpWidth == 8 then s.gpWidth = 6 end
  if s.arrowMode == "pin" then s.arrowMode = "route" end
end

-- 6.0: the Guide. A fresh install guides from the first login: the step frame, QuestBank's arrow, and the welcome
-- card that asks the auto choice (s.welcome "fresh"). A save from 5.x is asked once in the step frame instead
-- ("ask"); until it says yes the Guide is off and nothing else of its settings moves: 6.0's two new switches (the
-- minimap's ! for every quest you can take, the progress in mob tooltips) start off for it too, as the DEFAULTS
-- would have turned them on behind a "Not now"; Yes turns them on with the Guide (StepFrame.lua)
function QB.Migrate600(s, fresh)
  s.v600 = true
  if fresh then
    s.guide.on, s.guide.frame, s.arrow, s.welcome = true, true, true, "fresh"
  else
    s.guide.on, s.welcome = false, "ask"
    s.minimapGivers, s.tipProgress = false, false
  end
end

-- The saved hand-in runs, kept to their newest (5.4.2: they grew for as long as the account played, 3 to 6 KB each,
-- and nothing reads the old ones). The hand-ins themselves are not cut: about 145 bytes each and a few hundred a
-- character, nowhere near the memory the lag came from, and the site's upload merge (tools/probe_pull.py merge_seen)
-- counts a hand-in's own XP reading once only while that hand-in is still in the list
QB.MAX_RUNS = 20     -- hand-in runs: 3 to 6 KB each (every quest planned and paid); the newest are what is looked at
local function keepNewest(list, max)
  local n = type(list) == "table" and #list or 0
  if n <= max then return end
  local drop = n - max
  for i = 1, max do list[i] = list[i + drop] end
  for i = n, max + 1, -1 do list[i] = nil end
end
function QB.PruneLogs(db)
  keepNewest(db.runs, QB.MAX_RUNS)
end

-- where you are, for the settings that change with it: the contexts active now, most specific first
QB.CONTEXTS = { "dungeon", "pvp", "party", "cap" }
function QB.Contexts()
  local out = {}
  local inside, kind
  if IsInInstance then
    local ok, a, b = pcall(IsInInstance)
    if ok then inside, kind = QB.Plain(a), QB.Plain(b) end
  end
  if inside == true and (kind == "party" or kind == "raid") then out[#out + 1] = "dungeon" end
  local pvp = inside == true and (kind == "pvp" or kind == "arena")
  if not pvp and GetZonePVPInfo then
    local ok, z = pcall(GetZonePVPInfo)
    z = ok and QB.Plain(z) or nil
    pvp = z == "combat" or z == "hostile"
  end
  if pvp then out[#out + 1] = "pvp" end
  if IsInGroup and QB.Plain(IsInGroup()) == true then out[#out + 1] = "party" end
  if QB.Lock and QB:Lock() then out[#out + 1] = "cap" end
  return out
end

-- a setting as it applies right now: the first active context that overrides it, else the plain setting.
-- clockShow reads settings.clock.show when nothing overrides it
function QB:Opt(key)
  local s = self:Settings()
  local prof = type(s.profiles) == "table" and s.profiles or {}
  for _, ctx in ipairs(QB.Contexts()) do
    local p = prof[ctx]
    if type(p) == "table" and p[key] ~= nil then return p[key] end
  end
  if key == "clockShow" then return type(s.clock) == "table" and s.clock.show == true end
  return s[key]
end

function QB:CharKey()
  if QB.charKey then return QB.charKey end
  local realm = (GetNormalizedRealmName and GetNormalizedRealmName()) or (GetRealmName and GetRealmName()) or "?"
  return (UnitName("player") or "?") .. "-" .. realm
end

-- the realm's name comes two ways (with spaces, and without), and at logout only the spaced one answers, so a
-- character's saved tables could split in two keys: fold the spaced one into the normalized one, once, at login
function QB:MergeCharKeys()
  local db, key = QuestBankDB, QB.charKey
  local plain = GetRealmName and GetRealmName()
  if not (db and key and plain) then return end
  local other = (UnitName("player") or "?") .. "-" .. plain
  if other == key then return end
  for _, name in ipairs({ "plans", "chars", "held", "bank", "travel" }) do
    local t = db[name]
    if type(t) == "table" and t[other] ~= nil then
      if t[key] == nil then
        t[key] = t[other]
      elseif name == "plans" and type(t[key]) == "table" and type(t[other]) == "table" then
        local a, b = t[key], t[other]
        for _, f in ipairs({ "add", "cut", "seen", "removed", "handed", "rep" }) do
          if type(b[f]) == "table" then
            a[f] = a[f] or {}
            for k, v in pairs(b[f]) do if a[f][k] == nil then a[f][k] = v end end
          end
        end
        for k, v in pairs(b) do if a[k] == nil then a[k] = v end end
      elseif name == "chars" and type(t[key]) == "table" and type(t[other]) == "table" then
        local a, b = t[key], t[other]
        local na, nb = #(a.completed or {}), #(b.completed or {})
        if (b.saved or "") > (a.saved or "") then
          if nb < na then b.completed = a.completed end
          t[key] = b
        elseif nb > na then
          a.completed = b.completed
        end
      end
      t[other] = nil
    end
  end
end

function QB:Plan()
  local s = self:Settings()
  local db = QuestBankDB
  local key = self:CharKey()
  local p = db.plans[key]
  if not p then
    p = { add = {}, cut = {}, seen = {}, removed = {} }
    -- 2.0 kept one account-wide list of explicit choices
    if s.plan then
      for id, on in pairs(s.plan) do if on then p.add[id] = true end end
      s.plan = nil
    end
    db.plans[key] = p
  end
  p.add, p.cut, p.seen, p.removed = p.add or {}, p.cut or {}, p.seen or {}, p.removed or {}
  p.handed, p.rep = p.handed or {}, p.rep or {}
  p.skip = p.skip or {} -- quests skipped for good (QB:SetSkipped): [id] = true
  p.auto = p.auto or {} -- the Guide's own picks (Guide.lua, G.Fill): [id] = true; never one of p.add
  return p
end

function QB:Mounted()
  local s = self:Settings().mounted
  if s == "auto" then return API.KnowsRiding(), true end
  return s == true, false
end

----------------------------------------------------------------------------
-- the level lock. Banking a log only makes sense while the game holds your level at a cap: you
-- finish quests, keep them, and hand them all in the hour the cap goes up. QuestBank finds the lock
-- three ways: you turned XP off, the game reports your level as its highest for now (Season of
-- Discovery's clients reported their phase caps like that), or a hand-in at your level paid no XP
-- when it should have. Otherwise you're questing: hand in as you go, and no rush.
--   lock   held at a cap: bank, and plan the hour after it lifts
--   rush   the cap went up: cash the bank in, until the hand-in run ends
--   quest  levelling as usual
----------------------------------------------------------------------------
-- the highest level the game lets you reach for now
local CAP_FNS = { "GetMaxPlayerLevel", "GetMaxLevelForPlayerExpansion" } -- (asked many times a second: one list)
function API.GameCap()
  local cap = QB.MAXLEVEL
  for _, name in ipairs(CAP_FNS) do
    local fn = _G[name]
    if fn then
      local ok, v = pcall(fn)
      if ok and type(v) == "number" and v >= 10 and v < cap then cap = v end
    end
  end
  return cap
end

-- the lock learned from hand-ins, for this realm, and only while it's fresh (caps last weeks, not months)
local function learnedLock()
  local all = QuestBankDB and QuestBankDB.lock
  local mine = type(all) == "table" and all[QB.RealmKey()]
  if type(mine) == "table" and mine.level and (time() - (mine.at or 0)) < 30 * 86400 then return mine.level end
end

function QB.RealmKey()
  return (GetNormalizedRealmName and GetNormalizedRealmName()) or (GetRealmName and GetRealmName()) or "?"
end

-- your choice, per character: "auto" (QuestBank looks), "on" (bank at the level you chose it), "off"
function QB:LockChoice()
  local p = self:Plan()
  return p.lock or "auto", p
end

function QB:SetLock(value)
  local p = self:Plan()
  p.lock = value ~= "auto" and value or nil
  p.lockAt = value == "on" and self.state.level or nil
  -- whatever the last lock was, your choice replaces it; a lock found again is noted again
  if QuestBankDB.held then QuestBankDB.held[self:CharKey()] = nil end
  self:MarkDirty()
end

-- nil, or the level the game holds you at and the level XP runs to once it lifts. Reads only.
function QB:Lock()
  local choice, p = self:LockChoice()
  local level = self.state.level or 1
  if choice == "off" or level >= QB.MAXLEVEL then return nil end
  local held
  if choice == "on" then
    if p.lockAt and level > p.lockAt then return nil end -- you levelled past it (ReadState tidies up)
    held = p.lockAt or level
  elseif IsXPUserDisabled and IsXPUserDisabled() then
    held = level
  else
    local cap = API.GameCap()
    if level >= cap then held = cap
    elseif learnedLock() == level then held = level end
  end
  if not held then return nil end
  local nextCap = (p.nextCap and p.nextCap > held) and p.nextCap or math.min(held + 10, QB.MAXLEVEL)
  return held, nextCap
end

-- what the last lock was, for the rush after it lifts
function QB:Held()
  return QuestBankDB and QuestBankDB.held and QuestBankDB.held[self:CharKey()]
end

function QB:Mode()
  if self:Lock() then return "lock" end
  local run = QB.Run and QB.Run.Get()
  if run then return run.mode == "quest" and "quest" or "rush" end
  -- the lock just lifted and you haven't levelled since: your first hand-in starts the run
  local held = self:Held()
  if held and self:LockChoice() ~= "off" and (self.state.level or 1) <= held.level then return "rush" end
  return "quest"
end

-- XP amounts that matter scale with the level: 500 XP is a lot at level 3 and nothing at 50. These
-- were tuned at level 20, so the factor is 1 there.
function QB.Scale(level)
  local T = QB.Data.TO_NEXT
  level = math.max(1, math.min(level or 20, #T))
  return T[level] / T[20]
end

-- a follow-up step worth walking to: for you, not done or held, not a Season of Discovery leftover, not
-- in a place you skipped, and within reach of your level (two above while questing, none at a lock).
-- One gate for the arrow's chain walk and for what a quest leads on to, so the two can't drift apart.
local function stepOpen(nq, lvl, banking, s)
  return nq ~= nil and Q.ForMe(nq) and not API.IsDone(nq.id) and not s.log[nq.id] and not nq.sodLeftover and not nq.repeatable
    and not Q.Behind(nq.id) and not QB:SkipsQuest(nq) and (nq.req or 1) <= lvl + (banking and 0 or 2)
end
-- (questing: a chain's head carries the steps it opens, Lists.lua's bundle)
function QB:StepOpen(nq, lvl) return stepOpen(nq, lvl or self.state.level or 1, false, self.state) end

-- a quest behind a step of its chain you have not taken yet (Status's "First: ..."; a step you hold or finished puts every
-- step before it behind you, and one behind a step you hold is next: "Hand in X first"), worked out without a status
-- table: it counts only in its head's bundle (Lists.lua)
function QB:Locked(q)
  local pre = q and q.pre
  if not pre then return false end
  local from = 1
  for k = #pre, 1, -1 do
    if Q.PreDone(pre[k]) or Q.HeldOf(pre[k]) then from = k break end
  end
  for k = from, #pre do
    if not Q.PreDone(pre[k]) and not Q.HeldOf(pre[k]) then return true end
  end
  return false
end

-- a chain worth carrying on: the best later step you could take (up to three steps on), what it
-- pays and how many steps on. At a lock it's the step to bank instead, and only when it pays more
-- than this one; questing, it's where the chain leads next.
function QB:Upgrade(q)
  if not (q and q.nextSteps) then return nil end
  local s = self.state
  local lvl = s.level or 1
  local banking = self:Banking()
  local here = QB.Model.XpAt(q, lvl)
  local best, bestV, bestDepth
  local seen = {}
  local function walk(x, depth)
    if depth > 3 or not x.nextSteps then return end
    for _, nid in ipairs(x.nextSteps) do
      local nq = Q.Get(nid)
      if nq and not seen[nid] and stepOpen(nq, lvl, banking, s) then
        seen[nid] = true
        local v = QB.Model.XpAt(nq, lvl)
        -- a step handed in inside a dungeon can't be banked; the one after it can
        if not (banking and nq.turn and nq.turn.inside) and (not bestV or v > bestV) then best, bestV, bestDepth = nq, v, depth end
        walk(nq, depth + 1)
      end
    end
  end
  walk(q, 1)
  if not best or bestV <= 0 then return nil end
  if banking and bestV <= here + 300 * QB.Scale(lvl) then return nil end
  return best, bestV, bestDepth
end

-- banking words only where banking happens
function QB:Banking() return self:Mode() ~= "quest" end

-- two plain lines in party chat (raid chat in a raid), only when asked for in Settings and only while grouped, signed
-- the way a player would read it: "QuestBank: Kobold Camp Cleanup - completed"
QB.SAY = { accept = "QuestBank: %s - accepted", complete = "QuestBank: %s - completed" }
-- the one chat line 6.0 adds: after the welcome card's Done (StepFrame.lua), once a character; nothing else of the
-- Guide, the step frame, the tooltips or the minimap prints
QB.WELCOME = "QuestBank is guiding you. /qb opens the full window; right-click the step frame for its options."
function QB:Announce(kind, title)
  if kind == "accept" and self:Opt("sayAccept") ~= true then return end
  if kind == "complete" and self:Opt("sayComplete") ~= true then return end
  local channel = (IsInGroup and LE_PARTY_CATEGORY_INSTANCE and IsInGroup(LE_PARTY_CATEGORY_INSTANCE)) and "INSTANCE_CHAT"
    or ((IsInRaid and IsInRaid()) and "RAID") or ((IsInGroup and IsInGroup()) and "PARTY") or nil
  if not channel or not SendChatMessage then return end
  local clean = tostring(title or "a quest"):gsub("|", ""):sub(1, 200)
  pcall(SendChatMessage, string.format(QB.SAY[kind] or QB.SAY.complete, clean), channel)
end

----------------------------------------------------------------------------
-- what may be suggested: the level window and the skipped places (Settings, the Plan cards, /qb skip)
----------------------------------------------------------------------------
-- levels above and below yours that suggestions reach, and whether each is QuestBank's own choice
function QB:Range()
  local s = self:Settings()
  local autoA, autoB = s.rangeAbove == "auto", s.rangeBelow == "auto"
  local above = autoA and (self:Banking() and 12 or 4) or s.rangeAbove
  local below = autoB and 7 or s.rangeBelow
  return above, below, autoA, autoB
end

QB.CONTINENTS = { [0] = "Eastern Kingdoms", [1] = "Kalimdor" }

-- is this category (and, for class and other quests, the turn-in NPC's continent) skipped?
function QB:Skipped(catIdx, cont)
  local s = self:Settings()
  local c = catIdx and D.CAT[catIdx]
  if c then
    if s.skipCat[c.key] then return true end
    -- a place knows its continent; a dungeon that doesn't (a battleground, a new one) is never split
    -- quest by quest over its turn-in NPCs
    if c.cont ~= nil then cont = c.cont elseif c.dungeon then return false end
  end
  return cont ~= nil and cont >= 0 and s.skipCont[cont] == true
end

function QB:SkipsQuest(q)
  if self:IsSkipped(q.id) then return true end -- (the quest itself skipped: QB:SetSkipped)
  local r = D.Q[q.id]
  local turn = D.NPC[q.turnIdx]
  return r ~= nil and self:Skipped(r[8], turn and turn[5])
end

-- one string for everything skipped, so cached suggestion lists know when to refresh
function QB:SkipSignature()
  local s, parts = self:Settings(), {}
  for k in pairs(s.skipCat) do parts[#parts + 1] = k end
  for k in pairs(s.skipCont) do parts[#parts + 1] = "c" .. k end
  table.sort(parts)
  if (QB.skipVer or 0) > 0 then parts[#parts + 1] = "q" .. QB.skipVer end -- (a quest skipped or routed again)
  return table.concat(parts, ",")
end

-- the skipped places by name, continents first
function QB:SkipList()
  local s, names = self:Settings(), {}
  for k = 0, 1 do if s.skipCont[k] then names[#names + 1] = QB.CONTINENTS[k] end end
  local zones = {}
  for _, c in ipairs(D.CAT) do if s.skipCat[c.key] then zones[#zones + 1] = c.name end end
  table.sort(zones)
  for _, n in ipairs(zones) do names[#names + 1] = n end
  return names
end

function QB:SetSkip(key, on)
  local s = self:Settings()
  if type(key) == "number" then s.skipCont[key] = on and true or nil else s.skipCat[key] = on and true or nil end
  if QB.UI then QB.UI:Refresh() end
end

-- a continent, zone or dungeon by name (or part of one): flips it, and says what and which way
function QB:ToggleSkip(want)
  want = (want or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  if want == "" then return nil end
  local s = self:Settings()
  for k = 0, 1 do
    local n = QB.CONTINENTS[k]:lower()
    if n == want or (#want >= 4 and n:find(want, 1, true) == 1) then
      self:SetSkip(k, not s.skipCont[k])
      return QB.CONTINENTS[k], s.skipCont[k] == true
    end
  end
  local best
  for _, c in ipairs(D.CAT) do
    local n = c.name:lower()
    if n == want then best = c break end
    if n:find(want, 1, true) and (not best or #c.name < #best.name) then best = c end
  end
  if not best then return nil end
  self:SetSkip(best.key, not s.skipCat[best.key])
  return best.name, s.skipCat[best.key] == true
end

----------------------------------------------------------------------------
-- the join prompt for escort quests. When a party member accepts an escort, the game asks the others
-- ("X has started a quest", QUEST_ACCEPT_CONFIRM). Which prompt it shows is decided by the UI's MAX_QUESTS
-- (Blizzard_Game/Mainline/EventImplementation.lua): at or above it, "your quest log is full", its Yes greyed out by
-- the same comparison. Forever's UI carried 25 there while the log holds 40; 1.60.1 (70235) sets it from the log's
-- size (Blizzard_FrameXMLBase/Constants.lua: Constants.QuestLogConsts.MAXIMUM_NUM_QUESTS_LOG_CAN_ACCEPT, 40).
-- 3.3.4 to 3.6.0 wrote 40 into MAX_QUESTS themselves. Not any more: a value an addon writes into a global carries
-- the addon's taint, the game reads it as the prompt opens, and the prompt then opens as QuestBank (StaticPopup_Show
-- writes the popup system's list of popups on screen as QuestBank: the harm Auto.lua tells of for hiding one). So
-- QuestBank only reads the number: a client that still counts fewer than the log holds gets told, once a session,
-- why Yes is grey. The number goes into QuestBankDB.diag.addons too (QB.NoteAddons), so the uploads show which it is.
----------------------------------------------------------------------------
-- the number of quests the game's prompt counts as a full log, and whether that is fewer than the Forever log holds
function QB.EscortLimit()
  local n = QB.Plain(MAX_QUESTS)
  if type(n) ~= "number" then return nil, false end
  return n, n < QB.LOG_SLOTS and QB.Game ~= nil and QB.Game.Forever()
end

-- an escort started with your log past the prompt's count: true (Auto.lua's word about the prompt is left out too).
-- Nothing is said unprompted (until the launch round, once a session in chat): /qb escort tells why the Yes is grey
function QB:EscortPrompt()
  local limit, short = QB.EscortLimit()
  return (short and (self.state.logCount or 0) >= limit) and true or false
end
function QB:OnTheDay() return self:Banking() and "on the day" or "at your level" end

----------------------------------------------------------------------------
-- state
----------------------------------------------------------------------------
QB.state = { level = 1, xp = 0, log = {}, logOrder = {}, bagStarts = {} }
local function emptyRoute() return { legs = {}, t = 0, xp = 0, level = 0, at60 = 0, count = 0, byQuest = {}, unplaced = {}, waiting = {}, empty = true } end
QB.routeNow, QB.routePlan = emptyRoute(), emptyRoute()
local turnedIn = {} -- this session, so a hand-in is never mistaken for an abandon

-- quests that left your log without being handed in
local function trackRemovals(s)
  if not QB.logReady then return end
  local p = QB:Plan()
  -- a pick-up mark never outlives its quest: it goes as the quest is handed in, and as it is taken (abandoned later,
  -- it is not on the list again of its own accord)
  for id in pairs(p.add) do if API.IsDone(id) or s.log[id] then p.add[id] = nil end end
  for id, title in pairs(p.seen) do
    if not s.log[id] then
      if not turnedIn[id] and not API.IsDone(id) then
        local q = Q.Get(id)
        local value = q and QB.Model.XpAt(q, s.level) or nil
        p.removed[id] = { title = title, at = time and time() or 0, value = value }
        -- (said only when asked for since the review round: "Say quest XP in chat", sayXP, the step frame's menu; and
        -- then in a quiet host too, as the hand-in's line is: the player's own ask, the merge review)
        if QB.loggedIn and QB:Settings().sayXP == true then
          QB:Print(string.format("%s left your log without a hand-in%s. The route no longer counts it.", title,
            value and (" (worth about " .. QB.Comma(value) .. " XP)") or ""))
        end
      end
      p.seen[id] = nil
    end
  end
  for id, e in pairs(s.log) do
    p.seen[id] = e.title
    p.removed[id] = nil
  end
end

-- the game's own number for every quest you hold: the quest log shows each quest's XP at your level. Exact for
-- this level (q.logXp), and the full value is learned from it when the quest is not grey (Live, source "log").
function QB.ReadLogXp(s)
  if not GetQuestLogRewardXP then return end
  local vals, seen, dup, valued = {}, {}, 0, 0
  for _, e in ipairs(s.logOrder) do
    local ok, xp = pcall(GetQuestLogRewardXP, e.id)
    if ok and type(xp) == "number" and not (issecretvalue and issecretvalue(xp)) and xp > 0 then
      vals[e.id] = xp
      valued = valued + 1
      if seen[xp] then dup = dup + 1 end
      seen[xp] = true
    end
  end
  -- a client answering with the selected quest's number for every id repeats one value: trust none of it then
  if valued >= 3 and dup + 1 >= valued then vals = {} end
  for _, e in ipairs(s.logOrder) do
    local q = Q.Get(e.id)
    local xp = vals[e.id]
    if q then q.logXp = xp end
    if xp then
      e.xp = xp
      Live.Record(e.id, xp, s.level, "log")
    end
  end
  for id, q in pairs(cache) do if q and rawget(q, "logXp") and not s.log[id] then q.logXp = nil end end
end

function QB:ReadState()
  local s = self.state
  s.level = UnitLevel("player") or 1
  s.xp = UnitXP("player") or 0
  s.xpMax = UnitXPMax("player") or 1
  s.log, s.logOrder = API.LogQuests()
  QB.ReadLogXp(s)
  if QB.Run and QB.Run.Check then QB.Run.Check(s.level) end
  s.logCount = #s.logOrder
  s.mapID = API.MapID()
  s.bagStarts = API.BagQuestStarts()
  local _, class = UnitClass("player")
  s.class = class
  s.name = UnitName("player")
  QB.faction = API.Faction()
  local choice, p = QB:LockChoice()
  if choice == "on" and p.lockAt and s.level > p.lockAt then p.lock, p.lockAt = nil, nil end
  local held, nextCap = QB:Lock()
  QuestBankDB.held = QuestBankDB.held or {}
  local key = QB:CharKey()
  local run = QB.Run and QB.Run.Get()
  if held then
    QuestBankDB.held[key] = { level = held, next = nextCap }
  elseif QuestBankDB.held[key] and not run and (s.level > QuestBankDB.held[key].level or choice == "off") then
    QuestBankDB.held[key] = nil -- the bank is behind you
  end
  local was = QB:Held()
  local cap
  if nextCap then
    cap = nextCap
  elseif was and (run or s.level <= was.level) then
    -- the rush: the new cap if the game says, else the one you expected
    local game = API.GameCap()
    cap = (game > was.level and game < QB.MAXLEVEL) and game or was.next
  else
    cap = API.GameCap()
  end
  QB.CAP = math.max(cap or QB.MAXLEVEL, s.level)
  QB.mode = QB:Mode()
  trackRemovals(s)
  -- a quest that just turned complete: say so once. A quest that just arrived: party chat, if asked
  QB.wasComplete = QB.wasComplete or {}
  local firstRead = QB.wasInLog == nil
  QB.wasInLog = QB.wasInLog or {}
  local inLog = {}
  for _, e in ipairs(s.logOrder) do
    inLog[e.id] = true
    if not firstRead and not QB.wasInLog[e.id] and QB.loggedIn then QB:Announce("accept", e.title) end
    local before = QB.wasComplete[e.id]
    if e.complete and before == false and QB.loggedIn then
      local q = Q.Get(e.id)
      local value = q and QB.Model.XpAt(q, s.level)
      if QB:Settings().sayXP == true then -- (asked for: sayXP, as the hand-in's line, in a quiet host too)
        QB:Print(string.format("%s is complete%s%s.", e.title, QB:Banking() and ": banked" or ", hand it in",
          value and value > 0 and (", worth about " .. QB.Comma(value) .. " XP " .. QB:OnTheDay()) or ""))
      end
      QB:Announce("complete", e.title)
    end
    QB.wasComplete[e.id] = e.complete and true or false
  end
  QB.wasInLog = inLog
  return s
end

-- a log entry's progress line, kept with the entry (ReadState makes new entries when the log changes; an entry no
-- longer read goes with it)
local progressOf = setmetatable({}, { __mode = "k" })
local function progressText(entry)
  local done = progressOf[entry]
  if done then return done end
  local parts = {}
  for _, o in ipairs(entry.objectives or {}) do
    if not o.done then
      if o.have and o.need and o.need > 0 then
        parts[#parts + 1] = o.have .. "/" .. o.need
      elseif o.text then
        parts[#parts + 1] = o.text
      end
    end
  end
  done = #parts == 0 and "In your log" or ("In your log: " .. table.concat(parts, ", "))
  progressOf[entry] = done
  return done
end

-- The statuses whose words never change are one table each, shared (5.4.2: QB:Status runs for every quest the routes
-- consider, twice a refresh, and made a table, a string and Bank.Items' list each time: about 400 KB a refresh with
-- the window shut). Nothing changes a status once made; one that names a quest, a count or an item is made each time,
-- except an item that starts a quest and a level, kept by quest and by level
local ST = {
  done = { code = "done", text = "Handed in already" },
  banked = { code = "banked", text = "Banked, ready to hand in" },
  ready = { code = "banked", text = "Ready to hand in" },
  bagBanked = { code = "banked", text = "Banked in your bags", bag = true },
  bagReady = { code = "banked", text = "In your bags, ready", bag = true },
  bagstart = { code = "bagstart", text = "Starts from an item in your bags" },
  wrong = { code = "wrong", text = "Not for your faction, race or class" },
  todo = { code = "todo", text = "Not started" },
}
local lockedAt, itemStart = {}, setmetatable({}, { __mode = "k" }) -- (by level; by the quest's D.BAGQ entry)

-- what a quest asks you to bring, counted without making Bank.Items' list: the items still to take out of the bank,
-- whether bags and bank hold all of it, and how many of those are in the bank
local function itemsHeld(list)
  local fromBank, all, inBank = 0, true, 0
  for _, it in ipairs(list) do
    local need, bags, bank = it[2], API.ItemCount(it[1]), Bank.Count(it[1])
    if bags < need and bags + bank >= need then fromBank = fromBank + (need - bags) end
    if bags + bank < need then all = false end
    inBank = inBank + math.max(0, math.min(bank, need - bags))
  end
  return fromBank, all, inBank
end

-- code: done | banked | active | partial | bagstart | item | locked | prereq | todo | wrong
function QB:Status(q)
  local s = self.state
  if API.IsDone(q.id) then return ST.done end
  local e = s.log[q.id]
  local items = D.REQ[q.id]
  if e then
    if e.complete then return QB:Banking() and ST.banked or ST.ready end
    local text = progressText(e)
    if items then
      local fromBank = itemsHeld(items)
      if fromBank > 0 then text = text .. string.format(". Take %d out of your bank", fromBank) end
    end
    return { code = "active", text = text }
  end
  if not q.excl then
    local x, how = Q.Behind(q.id)
    if x then
      return { code = "todo", text = "Probably behind you", behind = true, later = x, how = how }
    end
  end
  local bag = q.bag
  if bag and bag[3] == 1 then
    local n = API.ItemCount(bag[1])
    if n >= bag[2] then return QB:Banking() and ST.bagBanked or ST.bagReady end
    if n > 0 then return { code = "partial", text = n .. "/" .. bag[2] .. " in your bags" } end
  elseif s.bagStarts[q.id] or (bag and bag[3] == 0 and API.ItemCount(bag[1]) > 0) then
    return ST.bagstart
  end
  local fromItem = bag and bag[3] == 0
  if not Q.ForMe(q) then return ST.wrong end
  if q.excl then
    for _, other in ipairs(q.excl) do
      if API.IsDone(other) or s.log[other] then
        return { code = "wrong", text = "Ruled out: you took " .. Q.Label(other) .. " instead" }
      end
    end
  end
  if s.level < (q.req or 1) then
    local st = lockedAt[q.req]
    if not st then st = { code = "locked", text = "Needs level " .. q.req }; lockedAt[q.req] = st end
    return st
  end
  if q.pre then
    -- a step you hold or finished means every step before it is behind you
    local from = 1
    for k = #q.pre, 1, -1 do
      local p = q.pre[k]
      if preDone(p) or heldOf(p) then from = k break end
    end
    local left = 0
    for k = from, #q.pre do if not preDone(q.pre[k]) then left = left + 1 end end
    for k = from, #q.pre do
      local p = q.pre[k]
      if not preDone(p) then
        local held = heldOf(p)
        local steps = left > 1 and string.format(" (%d steps)", left) or ""
        if held then return { code = "prereq", text = "Hand in " .. Q.Label(held) .. " first" .. steps, pre = p } end
        return { code = "prereq", text = "First: " .. Q.Label(p) .. steps, pre = p }
      end
    end
  end
  if fromItem then
    local st = itemStart[bag]
    if not st then st = { code = "item", text = "Starts from an item: " .. (bag[4] or "a drop") }; itemStart[bag] = st end
    return st
  end
  if items then
    local _, all, bank = itemsHeld(items)
    if all then
      return { code = "todo", text = "Not started, and you already have what it asks for" .. (bank > 0 and string.format(" (%d in your bank)", bank) or "") }
    end
  end
  return ST.todo
end

----------------------------------------------------------------------------
-- the plan: what you hold (minus what you cut) plus what you chose to fetch
----------------------------------------------------------------------------
function QB:IsCut(id) return self:Plan().cut[id] and true or false end

-- Skip this quest (5.4.4): out of the route for good, per character, wherever the route points at it (the arrow and its
-- menu, the route's rows, the pins), and never back through Accept for me, Now, Available or the arrow until routed
-- again (the same place's Route it again). A quest you hold is cut as well, so the route's own rules leave it out
function QB:IsSkipped(id) return id ~= nil and self:Plan().skip[id] == true end
function QB:SetSkipped(id, on)
  local p = self:Plan()
  if not id then return false end
  on = on and true or nil
  if p.skip[id] == on then return false end
  p.skip[id] = on
  QB.skipVer = (QB.skipVer or 0) + 1
  local q = Q.Get(id)
  if self.state.log[id] or (q and self:Status(q).bag) then p.cut[id] = on end
  if on then p.add[id] = nil end
  self:MarkDirty()
  return true
end

-- what a quest leads on to, for you: the XP of its follow-up steps (three on at most) at your level,
-- the ones you haven't done or taken. Questing, a quest that opens a chain is worth more than it pays.
function QB:ChainLead(id)
  local q = Q.Get(id)
  if not (q and q.nextSteps) then return 0 end
  local s, level = self.state, self.state.level or 1
  local seen, sum = { [id] = true }, 0
  -- of two steps that rule each other out, only the first met counts
  local function exclTaken(nq)
    if not nq.excl then return false end
    for _, o in ipairs(nq.excl) do if seen[o] then return true end end
    return false
  end
  local function walk(x, depth)
    if depth > 3 or not x.nextSteps then return end
    for _, nid in ipairs(x.nextSteps) do
      local nq = Q.Get(nid)
      if nq and not seen[nid] and stepOpen(nq, level, false, s) and not exclTaken(nq) then
        seen[nid] = true
        sum = sum + QB.Model.XpAt(nq, level)
        walk(nq, depth + 1)
      end
    end
  end
  walk(q, 1)
  return sum
end

-- the alternative of an either-or prerequisite that is yours: one you hold, else one for your faction,
-- class and race, else the first
function QB:PreStep(p)
  if type(p) ~= "table" then return Q.Get(p) end
  local s = self.state
  for _, id in ipairs(p) do if s.log[id] and Q.Get(id) then return Q.Get(id) end end
  for _, id in ipairs(p) do
    local q = Q.Get(id)
    if q and Q.ForMe(q) then return q end
  end
  return Q.Get(p[1])
end

-- the steps of a chain still ahead of this quest, in order: { q = the step (false if the catalog lacks
-- it), held = it is in your log, so what is left of it is the hand-in }
function QB:ChainSteps(q)
  if not (q and q.pre) then return nil end
  local s = self.state
  local from = 1
  for k = #q.pre, 1, -1 do
    local p = q.pre[k]
    if preDone(p) or heldOf(p) then from = k break end
  end
  local steps = {}
  for k = from, #q.pre do
    local p = q.pre[k]
    if not preDone(p) then
      local h = heldOf(p)
      if h and not Q.Get(h) then
        steps[#steps + 1] = { q = false, held = true } -- you hold a step the catalog lacks: nothing to aim at but its hand-in
      else
        local sq = self:PreStep(p)
        steps[#steps + 1] = { q = sq or false, held = (sq and s.log[sq.id]) and true or false }
      end
    end
  end
  return #steps > 0 and steps or nil
end

-- what a quest behind a chain costs you first: the steps left, the XP they pay at your level, and the
-- minutes of moving between their NPCs from where you stand, by the hand-in route's own travel model
function QB:ChainCost(q)
  local steps = self:ChainSteps(q)
  if not steps then return nil end
  local s = self.state
  local M, fac = QB.Model, self.faction or API.Faction()
  local mf = M.Factor(self:Mounted())
  local wp = API.WorldPosition()
  local prev = wp and M.Place(fac, wp.c, wp.wx, wp.wy) or nil
  local minutes, known, xp = 0, true, 0
  local function hop(to)
    if not to then known = false return end
    if prev then
      local leg = M.Between(prev, to, fac, mf)
      if leg == math.huge then known = false else minutes = minutes + leg end -- no way known: the minutes aren't
    end
    prev = to
  end
  for _, st in ipairs(steps) do
    local sq = st.q
    if sq then
      xp = xp + M.XpAt(sq, s.level or 1)
      if not st.held then hop(M.NpcPlace(sq.giveIdx, fac)) end
      hop(M.NpcPlace(sq.turnIdx, fac))
    else
      known = false
    end
  end
  hop(M.NpcPlace(q.giveIdx, fac))
  return { n = #steps, xp = xp, minutes = known and math.floor(minutes + 0.5) or nil, first = steps[1].q or nil }
end
function QB:IsAdded(id) return self:Plan().add[id] and true or false end
function QB:IsAuto(id) return id ~= nil and self:Plan().auto[id] == true end
-- the Guide runs while questing (banking keeps 5.x's planner as it is)
function QB:GuideOn() return self:Settings().guide.on == true and self:Mode() == "quest" end

function QB:InPlan(q, st)
  if self:IsCut(q.id) or self:IsSkipped(q.id) then return false end
  st = st or self:Status(q)
  if st.code == "done" or st.code == "wrong" then return false end
  if self.state.log[q.id] or st.bag then return true end
  return self:IsAdded(q.id) or (self:IsAuto(q.id) and self:GuideOn())
end

-- in the log: cut it or keep it; not in the log: fetch it or not. A skipped quest is routed again (un-skipped, and
-- put on the pick-up list where you don't hold it): the ! on Available, Pick up and the map pin's Shift-click say so,
-- where 5.4.4 as first built put it on the list and left it skipped, out of the route
function QB:ToggleAdd(id)
  local p = self:Plan()
  local q = Q.Get(id)
  if self:IsSkipped(id) then
    self:SetSkipped(id, false)
    if not (self.state.log[id] or (q and self:Status(q).bag)) then p.add[id] = true end
    self:MarkDirty()
    return
  end
  if self.state.log[id] or (q and self:Status(q).bag) then
    p.cut[id] = (not p.cut[id]) or nil
  else
    p.add[id] = (not p.add[id]) or nil
  end
  self:MarkDirty()
end

-- on the pick-up list or off it, whichever it is now (the window's Pick up all and Remove all). Never a cut: a quest
-- in your log or your bags is left as it is. True when it changed
function QB:SetAdded(id, on)
  local q = Q.Get(id)
  if self.state.log[id] or (q and self:Status(q).bag) then return false end
  local p = self:Plan()
  if (p.add[id] == true) == (on and true or false) then return false end
  p.add[id] = on and true or nil
  self:MarkDirty()
  return true
end

-- quests kept as items in your bags, for your faction, class and race: worked out once
local bagQuests
function QB:BagQuests()
  if bagQuests then return bagQuests end
  local out = {}
  for id in pairs(D.BAGQ) do
    local q = Q.Get(id)
    if q and Q.ForMe(q) then out[#out + 1] = id end
  end
  table.sort(out)
  bagQuests = out
  return out
end

-- entries for the planner: { q, st, after }. What it has looked at is marked in two tables kept between calls with
-- the call's number (it runs twice a refresh, for a few hundred quests)
local seenAt, inListAt, entriesGen = {}, {}, 0
function QB:RouteEntries(mode)
  entriesGen = entriesGen + 1
  local gen = entriesGen
  local list = {}
  local s = self.state
  local function consider(id)
    if seenAt[id] == gen then return end
    seenAt[id] = gen
    local q = Q.Get(id)
    if not q then return end
    local st = self:Status(q)
    -- a delivery you're handed on the day is planned behind its first step, unless you already hold it
    if q.follow and not s.log[id] and not st.bag then return end
    local want
    if mode == "plan" then
      want = self:InPlan(q, st)
    else
      want = st.code == "banked" and not self:IsCut(id) and not self:IsSkipped(id)
    end
    if want then list[#list + 1] = { q = q, st = st } end
  end
  for _, e in ipairs(s.logOrder) do consider(e.id) end
  for id in pairs(s.bagStarts) do consider(id) end
  for _, id in ipairs(QB:BagQuests()) do consider(id) end
  if mode == "plan" then for id in pairs(self:Plan().add) do consider(id) end end
  if mode == "plan" and QB:GuideOn() then for id in pairs(self:Plan().auto) do consider(id) end end -- the Guide's picks (Guide.lua)
  -- quests handed to you on the day by another hand-in, delivered at once
  for _, e in ipairs(list) do inListAt[e.q.id] = gen end
  for id, parent in pairs(D.FOLLOW) do
    local q = inListAt[parent] == gen and inListAt[id] ~= gen and Q.Get(id)
    if q and not API.IsDone(id) and Q.ForMe(q) then
      list[#list + 1] = { q = q, st = { code = "follow", text = "Given when you hand in " .. Q.Label(parent) }, after = parent }
    end
  end
  return list
end

-- how far along a quest in your log is, summed over its counted objectives: have, need
function QB:Progress(id)
  local e = self.state.log[id]
  if not e then return nil end
  local have, need = 0, 0
  for _, o in ipairs(e.objectives or {}) do
    if o.need and o.need > 0 then
      have, need = have + math.min(o.have or 0, o.need), need + o.need
    end
  end
  if need == 0 then return nil end
  return have, need
end

-- quests in your log the catalog does not know
function QB:Unknown()
  local out = {}
  for _, e in ipairs(self.state.logOrder) do
    if not Q.Get(e.id) then out[#out + 1] = e end
  end
  return out
end

----------------------------------------------------------------------------
-- the hand-in run: what you handed in, when, and what it paid
----------------------------------------------------------------------------
local Run = {}
QB.Run = Run

function Run.Get()
  local run = QuestBankDB and QuestBankDB.run
  if run and run.key == QB:CharKey() then return run end
end

-- quietly: the run started by itself (the first paying hand-in after a lock: onTurnIn), nothing said; the Route page's
-- Start run says so
function Run.Start(quietly)
  local r = QB.routeNow
  local run = { started = time(), key = QB:CharKey(), level = QB.state.level, xp = QB.state.xp, done = {}, plan = {},
                mode = QB.mode == "quest" and "quest" or "rush",
                predicted = r and r.xp or 0, predictedT = r and r.t or 0, hearthUsed = false }
  if r then
    for _, leg in ipairs(r.legs) do
      for _, row in ipairs(leg.rows) do run.plan[row.q.id] = { t = leg.t, xp = row.xp, stop = leg.stop.name } end
    end
  end
  QuestBankDB.run = run
  -- the game's pin doesn't follow the route (QuestBank never sets it: API.SetWaypoint); the arrow does, and TomTom's
  local hint = ""
  if not QB:Settings().arrow and not API.TomTom() then hint = " /qb arrow points you from stop to stop." end
  if not (QB.quiet or quietly) then QB:Print("Hand-in run started. Each quest is ticked off with the XP it paid, and the rest is planned again from where you stand." .. hint) end
  Run.ArmHour()
  QB:MarkDirty()
end

-- quietly: the run ended by itself (Run.Check), nothing said
function Run.Stop(quietly)
  local run = Run.Get()
  if not run then return end
  run.ended = time()
  local got, n = 0, 0
  for _, d in pairs(run.done) do got, n = got + (d.xp or 0), n + 1 end
  run.got, run.count = got, n
  table.insert(QuestBankDB.runs, run)
  keepNewest(QuestBankDB.runs, QB.MAX_RUNS)
  QuestBankDB.run = nil
  -- the bank is cashed in: questing from here, until the next lock
  if QuestBankDB.held and not QB:Lock() then QuestBankDB.held[QB:CharKey()] = nil end
  QB.mode = QB:Mode()
  if not (QB.quiet or quietly) then QB:Print(string.format("Run ended: %d quests, %s XP in %s.", n, QB.Comma(got), QB.Clock((run.ended - run.started) / 60))) end
  if n > 0 then Run.Offer("done", run) end
  QB:MarkDirty()
end

-- a hand-in run ends by itself when it has outlived the hour it was for: two hours have passed, or an hour and
-- a half with you three levels past where it started. (The owner's run from the level-20 cap was still
-- on at level 24, and everything spoke of banking.)
function Run.Check(level)
  local run = Run.Get()
  if not run or run.mode == "quest" then return end
  local mins = (time() - run.started) / 60
  if mins > 120 or (mins > 90 and (level or 0) >= (run.level or level or 0) + 3) then
    -- (said in chat until the launch round; the Route page shows the run, or that there is none)
    if QB.tracing then QB.Trace("run: ended by itself after %d min", math.floor(mins)) end
    Run.Stop(true)
  end
end

function Run.Elapsed()
  local run = Run.Get()
  if not run then return 0 end
  return (time() - run.started) / 60
end

function Run.Record(id, xp, name)
  local run = Run.Get()
  if not run then return end
  run.done[id] = { xp = xp, t = Run.Elapsed(), name = name, n = run.n and run.n + 1 or 1 }
  run.n = (run.n or 0) + 1
end

-- minutes ahead of the plan (negative: behind), from the last hand-in the plan timed
function Run.Pace()
  local run = Run.Get()
  if not run then return nil end
  local lastT, planT
  for id, d in pairs(run.done) do
    local p = run.plan[id]
    if p and (not lastT or d.t > lastT) then lastT, planT = d.t, p.t end
  end
  if not lastT then return nil end
  return planT - lastT
end

function Run.Totals()
  local run = Run.Get()
  if not run then return 0, 0 end
  local got, n = 0, 0
  for _, d in pairs(run.done) do got, n = got + (d.xp or 0), n + 1 end
  return got, n
end

----------------------------------------------------------------------------
-- telling your party and guild: QuestBank offers a post, you read it and press Post (UI:PostDialog).
-- Offered at each level of a hand-in run, when its first hour is up, and when it ends.
----------------------------------------------------------------------------
local function levelNow()
  return QB.Model.Frac(UnitLevel("player") or QB.state.level, UnitXP("player") or 0)
end

local function quests(n) return n == 1 and "1 quest" or (n .. " quests") end
local function minutes(m) return math.max(1, math.floor(m + 0.5)) end

-- the message, and a line on why it's offered. kind: level (arg: the new level), hour, done (arg: the ended run), status
function Run.PostText(kind, arg)
  local run = kind == "done" and arg or Run.Get()
  if run and kind == "level" then
    local got, n = Run.Totals()
    return string.format("Level %d, %d min into my hand-in run: %s handed in, +%s XP. (QuestBank)", arg,
      minutes(Run.Elapsed()), quests(n), QB.Comma(got)), "You reached level " .. arg .. "."
  elseif run and kind == "hour" and run.hour then
    return string.format("First hour of my hand-in run: level %.1f, %s handed in, +%s XP. (QuestBank)",
      run.hour.level, quests(run.hour.n), QB.Comma(run.hour.xp)), "The first hour of your hand-in run is up."
  elseif run and kind == "done" then
    return string.format("Hand-in run done: level %.1f to %.1f in %d min, %s, +%s XP. (QuestBank)",
      QB.Model.Frac(run.level or 1, run.xp or 0), levelNow(), minutes((run.ended - run.started) / 60),
      quests(run.count or 0), QB.Comma(run.got or 0)), "Your hand-in run is over."
  elseif run then
    local got, n = Run.Totals()
    return string.format("%d min into my hand-in run: level %.1f, %s handed in, +%s XP. (QuestBank)",
      minutes(Run.Elapsed()), levelNow(), quests(n), QB.Comma(got)), "Your hand-in run so far."
  end
  local now, plan = QB.routeNow, QB.routePlan
  local banked = (now and not now.empty) and now.level or levelNow()
  local full = (plan and not plan.empty) and plan.level or banked
  local hour = (plan and not plan.empty) and plan.at60 or banked
  if not QB:Banking() then
    return string.format("Level %.1f: the quests ready in my log take me to %.1f, my plan to %.1f. (QuestBank)",
      levelNow(), banked, full), "Your quest log and your plan."
  end
  if QB.mode == "rush" then
    return string.format("The cap is up: my bank takes me to level %.1f, my full plan to %.1f (%.1f inside the first hour). (QuestBank)",
      banked, full, hour), "Your bank and your plan."
  end
  return string.format("My banked quests take me to level %.1f when the cap goes up, my full plan to %.1f (%.1f inside the first hour). (QuestBank)",
    banked, full, hour), "Your bank and your plan."
end

-- only an offer: nothing is posted until you press Post
function Run.Offer(kind, arg)
  if not (QB:Settings().post.auto and QB.UI and QB.Sync) then return end
  local ch = QB.Sync.PostChannels()
  if not (ch.party or ch.guild) then return end
  local msg, why = Run.PostText(kind, arg)
  QB.UI:PostDialog(msg, why, true)
end

-- the first hour: noted once, when it's up (again after a /reload, if it hasn't passed)
function Run.ArmHour()
  local run = Run.Get()
  if not run or run.hour then return end
  local left = 3600 - (time() - run.started)
  if left <= 0 then return end
  local started = run.started
  C_Timer.After(left, QB.Safe(function()
    local r = Run.Get()
    if not r or r.started ~= started or r.hour then return end
    local got, n = Run.Totals()
    r.hour = { level = levelNow(), n = n, xp = got }
    Run.Offer("hour")
  end, "run: the first hour"))
end

----------------------------------------------------------------------------
-- recompute: two routes, cached until something they depend on changes, planned in the background
----------------------------------------------------------------------------
-- What a plan depends on, and nothing else: a route is planned again only when one of these changed. Your level (not
-- the XP within it: 5.4.3 planned again every fiftieth of a level), the mount, the goal, the faction, the hearthstone
-- ready or used, the cap, the mode, your hand-ins (by how many there have been), a jump in place for a route from
-- where you stand (a flight, a boat, a hearth, a portal, a loading screen: Target.lua; 5.4.3 counted the flight master
-- nearest you as the crow flies, which changed as you walked), a hand-in in reach left behind (Target.lua, once), the
-- flight paths you know and the hearthstone's bind (Travel.lua's TV.ver), and the route's quests with their state and
-- the XP the game reported for each of them. Crossing a zone's border, a bag event or a kill changes none of it, nor
-- the XP the game shows for a quest outside the route (a quest giver's window, a party member's report: 5.4.4 as first
-- built counted any of those, and planned the route again from where you stood). PARTS names them for /qb trace
local PARTS = { "your level", "the mount", "the goal", "the faction", "the hearthstone", "the cap", "the mode",
                "a hand-in", "a jump in place", "a hand-in in reach left behind", "the flight paths or the bind" }
local function signature(list, opts)
  local parts = { opts.level, tostring(opts.mounted), opts.goal, opts.fac, tostring(opts.noHearth), opts.cap or 0, opts.mode or "",
                  QB.doneVer or 0, opts.start and (QB.jumpVer or 0) or "-", opts.start and (QB.reachVer or 0) or "-",
                  QB.Travel and QB.Travel.ver or 0 }
  for _, e in ipairs(list) do
    local live, code = e.q.liveFull, e.st and e.st.code or ""
    parts[#parts + 1] = live and (e.q.id .. code .. "=" .. live) or (e.q.id .. code)
  end
  return table.concat(parts, ":"), parts
end

-- /qb trace: what changed between two signatures' parts, in words (a quest's part is its id and state, then "=" and
-- the XP the game reported for it)
local function whatChanged(was, now)
  if not was then return "the first plan" end
  local out = {}
  for i, name in ipairs(PARTS) do if was[i] ~= now[i] then out[#out + 1] = name end end
  local quests, xp = #was ~= #now, false
  for i = #PARTS + 1, math.max(#was, #now) do
    if was[i] ~= now[i] then
      if tostring(was[i]):match("^[^=]*") == tostring(now[i]):match("^[^=]*") then xp = true else quests = true end
    end
  end
  if quests then out[#out + 1] = "your quests or their state" end
  if xp then out[#out + 1] = "the game's XP numbers" end
  return #out > 0 and table.concat(out, ", ") or "nothing (asked again)"
end

function QB:Recompute(sync)
  self:ReadState()
  local set = self:Settings()
  local mode = QB.mode
  local opts = {
    level = self.state.level, xp = self.state.xp, mounted = (self:Mounted()),
    goal = mode == "quest" and "rate" or set.goal, fac = QB.faction, cap = QB.CAP, mode = mode,
  }
  local nowOpts = {}
  for k, v in pairs(opts) do nowOpts[k] = v end
  -- mid-run, or questing: the route from where you stand. (At a lock you log out where the route starts.) Where you
  -- stand is read when the route is planned again for another reason, or after a jump in place (QB.jumpVer)
  local run = Run.Get()
  if run or mode == "quest" then
    local wp = API.WorldPosition()
    if wp then
      -- (on an open map off the two continents, Zephras Isle, no flight master: the route walks from you all the same)
      local place = QB.Model.Place(QB.faction, wp.c, wp.wx, wp.wy)
      if place.hub > 0 or QB.Model.Off(place.c) then nowOpts.start, nowOpts.jump = wp, QB.jumpVer or 0 end
    end
    nowOpts.noHearth = (run and run.hearthUsed) or not API.HearthReady()
    nowOpts.goal = mode == "quest" and "rate" or "route" -- (questing: levels an hour, the quests' work counted; Model.lua)
    -- (in the air or as a ghost nothing is handed in where you are: no stop in reach goes first, Model.lua)
    nowOpts.noReach = QB.Target and QB.Target.NoHandin and QB.Target.NoHandin() or nil
    if mode == "quest" then opts.start, opts.jump, opts.noHearth, opts.noReach = nowOpts.start, nowOpts.jump, nowOpts.noHearth, nowOpts.noReach end
  end
  local now, plan = self:RouteEntries("now"), self:RouteEntries("plan")
  local sigNow, partsNow = signature(now, nowOpts)
  local sigPlan, partsPlan = signature(plan, opts)
  local needNow = sigNow ~= self.sigNow
  local needPlan = sigPlan ~= self.sigPlan
  if not (needNow or needPlan) then return self.routeNow, self.routePlan end
  local want = sigNow .. "|" .. sigPlan
  if self.pending == want and not sync then return self.routeNow, self.routePlan end
  if QB.tracing then
    local wp = nowOpts.start
    local was, is = self.partsPlan, partsPlan
    if needNow then was, is = self.partsNow, partsNow end
    QB.Trace("re-plan%s%s: %s%s", needNow and " (ready now)" or "", needPlan and " (the plan)" or "", whatChanged(was, is),
      wp and string.format("; you at %d: %.0f, %.0f", wp.c, wp.wx, wp.wy) or "")
  end
  local function work()
    -- each starts from the last route, so a change can only move it to a better one, and keeps its first stop unless
    -- another is clearly better (Model.lua)
    local was = QB.tracing and QB.Target and QB.Target.Route()
    local wasFirst = was and was.legs and was.legs[1] and was.legs[1].stop.name
    if needNow then self.routeNow, self.sigNow, self.partsNow = QB.Model.Plan(now, nowOpts, self.routeNow), sigNow, partsNow end
    if needPlan then self.routePlan, self.sigPlan, self.partsPlan = QB.Model.Plan(plan, opts, self.routePlan), sigPlan, partsPlan end
    if QB.tracing and QB.Target then
      local r = QB.Target.Route()
      local first = r and r.legs and r.legs[1] and r.legs[1].stop.name
      local alt = r and r.alt
      QB.Trace("first stop: %s%s%s", tostring(wasFirst or "none"), first == wasFirst and " kept" or (" -> " .. tostring(first or "none")),
        alt and string.format(" (%.1f min; %s first %.1f min)", r.t or 0, tostring(alt.first), alt.t or 0) or "")
    end
  end
  if sync then
    self.pending = nil
    QB.Model.Cancel()
    work()
  else
    self.pending = want
    QB.Model.Async(work, function()
      QB.pending = nil
      QB:Changed()
    end)
  end
  self.dirty = false
  return self.routeNow, self.routePlan
end

-- XP a quest is worth on the day: from a route, else at your level
function QB:Value(id)
  for _, r in ipairs({ self.routePlan, self.routeNow }) do
    if r and r.byQuest and r.byQuest[id] then return r.byQuest[id], true end
  end
  local q = Q.Get(id)
  if not q then return nil end
  return QB.Model.XpAt(q, self.state.level), false
end

----------------------------------------------------------------------------
-- export: the file someone can read to check your plan
----------------------------------------------------------------------------
local function completedIDs()
  API.RefreshDone()
  return API.DoneList()
end

local function bagItems()
  local found = {}
  local numSlots = (C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
  local itemID = (C_Container and C_Container.GetContainerItemID) or GetContainerItemID
  local itemLink = (C_Container and C_Container.GetContainerItemLink) or GetContainerItemLink
  local itemInfo = C_Container and C_Container.GetContainerItemInfo
  if not (numSlots and itemID) then return {} end
  for bag = 0, (NUM_BAG_SLOTS or 4) do
    for slot = 1, (numSlots(bag) or 0) do
      local id = itemID(bag, slot)
      if id then
        local count = 1
        if itemInfo then
          local info = itemInfo(bag, slot)
          if info and info.stackCount then count = info.stackCount end
        elseif GetContainerItemInfo then
          local _, c = GetContainerItemInfo(bag, slot)
          count = c or 1
        end
        local link = itemLink and itemLink(bag, slot)
        local e = found[id]
        if not e then
          e = { id = id, name = link and link:match("%[(.-)%]") or nil, count = 0 }
          found[id] = e
        end
        e.count = e.count + count
      end
    end
  end
  local list = {}
  for _, e in pairs(found) do list[#list + 1] = e end
  table.sort(list, function(a, b) return a.id < b.id end)
  return list
end

function QB:Snapshot(reason)
  local s = self:ReadState()
  local _, race = UnitRace("player")
  local log = {}
  for _, e in ipairs(s.logOrder) do
    log[#log + 1] = { id = e.id, title = e.title, level = e.level, complete = e.complete, objectives = e.objectives }
  end
  local done = completedIDs()
  local prev, stale = QuestBankDB.chars[self:CharKey()], nil
  if #done == 0 and prev and type(prev.completed) == "table" and #prev.completed > 0 then done, stale = prev.completed, true end
  -- the summary is written into the character's table, not a new one: what is kept beside it goes on (the timers'
  -- work and pace, the Guide's, the run speed, the colours, the tracker's; 6.2's first build lost the work measured at
  -- every login and logout)
  local c = type(prev) == "table" and prev or {}
  QuestBankDB.chars[self:CharKey()] = c
  c.saved, c.reason, c.version = date("%Y-%m-%d %H:%M"), reason, QB.version
  c.level, c.xp, c.xpMax, c.class, c.race = s.level, s.xp, s.xpMax, s.class, race
  c.faction, c.completed, c.completedStale, c.log, c.bags = UnitFactionGroup("player"), done, stale, log, bagItems()
  return #done, #log
end

----------------------------------------------------------------------------
-- events
----------------------------------------------------------------------------
-- the login: the character's key, the state read, every part's Init, the first plan a few seconds on. From the
-- PLAYER_LOGIN event; or from a host that loaded the engine on demand after it, which never sees that event
-- (Cute_Quest's Bridge.lua). Once a session
function QB:Login()
  if QB.loginDone then return end
  QB.loginDone = true
  local nr = GetNormalizedRealmName and GetNormalizedRealmName()
  if nr then QB.charKey = (UnitName("player") or "?") .. "-" .. nr; QB:MergeCharKeys() end
  QB:ReadState()
  if QB.Minimap then QB.Minimap:Create() end
  if QB.Pins then QB.Pins:Init() end
  if QB.QuestMap then QB.QuestMap:Init() end
  if QB.Sync then QB.Sync:Init() end
  if QB.Discover then QB.Discover:Init() end
  if QB.Survey then QB.Survey:Init() end
  if QB.Game then QB.Game:Init() end
  if QB.Loot then QB.Loot:Init() end
  if QB.Observe then QB.Observe:Init() end
  if QB.Timer then QB.Timer:Init() end
  if QB.Link then QB.Link:Init() end
  if QB.Mini then QB.Mini:Init() end
  if QB.MapPage then QB.MapPage:Init() end
  if QB.Glow then QB.Glow:Init() end
  if QB.Walk then QB.Walk:Init() end
  if QB.Legacy then QB.Legacy:Init() end
  if QB.Camp then QB.Camp:Init() end
  if QB.Travel then QB.Travel:Init() end
  if QB.Arrow then QB.Arrow:Init() end
  if QB.Target then QB.Target:Init() end
  if QB.StepFrame then QB.StepFrame:Init() end -- (the Guide's step frame, StepFrame.lua)
  if QB.Tips then QB.Tips:Init() end -- (quest progress in mob and object tooltips, Tips.lua)
  -- after the other addons have loaded and run their own login code
  C_Timer.After(12, QB.Safe(QB.NoteAddons, "addon note"))
  Run.ArmHour()
  C_Timer.After(8, QB.Safe(function() QB:Snapshot("login") end, "login snapshot"))
  C_Timer.After(4, QB.Safe(function() QB:Changed() end, "login"))
end

local frame = CreateFrame("Frame")
QB.eventFrame = frame
local pending = false

-- something the plan depends on changed: refresh what is on screen a moment later
function QB:MarkDirty()
  if QB.Arrow and QB.Arrow.Invalidate then QB.Arrow.Invalidate() end
  self.dirty = true
  QB.dirtyVer = (QB.dirtyVer or 0) + 1 -- (what is kept until the plan's inputs change: Lists.lua's places)
  if pending then return end
  pending = true
  C_Timer.After(0.3, QB.Safe(function()
    pending = false
    QB:Changed()
  end, "refresh"))
end

function QB:Changed()
  -- a count, for what is kept until the data changes (the minimap's list, the dungeons' done counts): first, so what
  -- is drawn below already counts as new
  QB.changed = (QB.changed or 0) + 1
  QB.Try("plan", QB.Recompute, QB)
  if QB.Guide then QB.Try("guide", QB.Guide.Replan) end -- the Guide's steps from the route just planned (Guide.lua)
  if QB.StepFrame and QB.StepFrame.frame then QB.Try("step frame", QB.StepFrame.Refresh) end
  -- the window shows what was just worked out, without working it out again
  QB.fresh = true
  if QB.UI and QB.UI.frame and QB.UI.frame:IsShown() then QB.Try("window", QB.UI.Refresh, QB.UI) end
  QB.fresh = false
  if QB.Pins then QB.Try("map pins", QB.Pins.Update, QB.Pins) end -- and the quest icons after them (Pins.lua)
  if QB.Sync then QB.Try("party sync", QB.Sync.Changed, QB.Sync) end
end

local function onTurnIn(questID, xpReward)
  QB.NoteXPSeen("turnin", questID, xpReward)
  if issecretvalue and issecretvalue(questID) then return end
  local hidden = (issecretvalue and issecretvalue(xpReward)) and true or false
  if hidden then xpReward = nil end -- hidden from addons: "not told", never 0 (see below)
  turnedIn[questID] = true
  API.MarkDone(questID)
  local q = Q.Get(questID)
  Live.Record(questID, xpReward, QB.state.level or UnitLevel("player"), "turnin")
  local predicted = QB.routeNow and QB.routeNow.byQuest and QB.routeNow.byQuest[questID]
  table.insert(QuestBankDB.turnins, {
    id = questID, xp = xpReward, predicted = predicted, level = UnitLevel("player"), at = date("%Y-%m-%d %H:%M:%S"),
    mult = q and q.mult, base = q and q.base, hidden = hidden or nil,
  })
  local level = UnitLevel("player") or 0
  -- the lock, learned: a quest worth XP at this level paid none (the cap holds for every character on
  -- the realm, so it counts account-wide), until a hand-in at that level pays again
  local expected = q and QB.Model.XpAt(q, level) or 0
  -- the line in chat for each hand-in only when asked for (sayXP, "Say quest XP in chat": the step frame's menu); off
  -- by default since the launch round, in QuestBank and in Cute (the step frame and the Route page show the XP)
  local say = QB:Settings().sayXP == true
  if hidden then
    -- the game hid the number: nothing to learn about locks, no run to start; a run under way counts the plan's figure
    Run.Record(questID, predicted or 0, q and q.name)
    if q and say then
      QB:Print(string.format("%s handed in. The game hides its XP from addons%s.", QB.Link.Format(q),
        (predicted and predicted > 0) and string.format("; the plan counted %s", QB.Comma(predicted)) or ""))
    end
    return
  end
  -- (at a cap the game throws XP away, so the bar sits at 0: a stray quest that pays nothing isn't a lock)
  local locks = type(QuestBankDB.lock) == "table" and not QuestBankDB.lock.level and QuestBankDB.lock or {}
  QuestBankDB.lock = locks
  local realm = QB.RealmKey()
  if (xpReward or 0) == 0 and expected >= 100 * QB.Scale(level) and level < QB.MAXLEVEL and (UnitXP("player") or 0) == 0
    and not (IsXPUserDisabled and IsXPUserDisabled()) then
    locks[realm] = { level = level, at = time() }
  elseif (xpReward or 0) > 0 and locks[realm] and level >= locks[realm].level then
    locks[realm] = nil
  end
  -- the first banked quest that pays after a lock starts the hand-in run by itself
  if not Run.Get() and predicted and QB.mode ~= "quest" and (xpReward or 0) > 0 then Run.Start(true) end
  Run.Record(questID, xpReward, q and q.name)
  if not (q and say) then return end
  if (xpReward or 0) == 0 and predicted and predicted > 0 then
    QB:Print(string.format("%s paid no XP (the level cap?). The plan counted %s for it.", QB.Link.Format(q), QB.Comma(predicted)))
    return
  end
  local msg = string.format("%s: +%s XP", q.name, QB.Comma(xpReward or 0))
  if predicted and xpReward and xpReward > 0 and math.abs(predicted - xpReward) > 25 then
    msg = msg .. string.format(" (plan said %s)", QB.Comma(predicted))
  end
  QB:Print(msg)
end

frame:SetScript("OnEvent", QB.Safe(function(_, event, a1, a2, a3)
  -- (the Guide hears every event of this frame, as Auto does for the quest window's; it marks the plan dirty itself)
  if event ~= "ADDON_LOADED" and QB.Guide and QB.Guide.OnEvent then QB.Try("guide", QB.Guide.OnEvent, event, a1, a2) end
  if event == "PLAYER_DEAD" or event == "PLAYER_UNGHOST" or event == "PLAYER_ALIVE" or event == "TRAINER_SHOW" or event == "QUEST_FINISHED" then return end -- (the Guide's alone: no re-plan for a release, a trainer's or a reward window)
  if event == "PLAYER_REGEN_ENABLED" then
    -- the fight over: the step frame's item button changes that waited (StepFrame.lua); no re-plan
    if QB.StepFrame and QB.StepFrame.OnRegen then QB.Try("step frame", QB.StepFrame.OnRegen) end
    return
  end
  if event == "ADDON_LOADED" then
    -- (the quest survey's rows first: the game's XP for one of them applies like any other's)
    if a1 == ADDON then QB:Settings(); if QB.Survey then QB.Try("quest survey", QB.Survey.Load) end; Live.Apply() end
    return
  elseif event == "QUEST_ACCEPT_CONFIRM" then
    -- the game's own prompt answers it: you say yes there (Auto.lua says why QuestBank no longer does)
    local said = QB:EscortPrompt(QB.Plain(a1), QB.Plain(a2))
    if QB.Auto and not said then QB.Auto.OnEvent(event, a1, a2) end
    return
  elseif event == "QUEST_PROGRESS" or event == "QUEST_GREETING" or event == "GOSSIP_SHOW" then
    if QB.Auto then QB.Auto.OnEvent(event, a1, a2) end
    return
  elseif event == "QUEST_DETAIL" or event == "QUEST_COMPLETE" then
    local before = QB.liveVer
    windowXP("npc", event)
    if QB.Auto then QB.Auto.OnEvent(event, a1, a2) end -- after the window's XP is on record
    if QB.liveVer == before then return end -- nothing new: the plan stands
  elseif event == "PLAYER_LOGIN" then
    QB:Login()
    return
  elseif event == "PLAYER_LOGOUT" then
    QB:Snapshot("logout")
    return
  elseif event == "QUEST_LOG_UPDATE" then
    if not QB.logReady then
      API.RefreshDone()
      QB.logReady = true
      QB:ReadState()
      QB.loggedIn = true
    elseif doneCount == 0 then
      API.RefreshDone() -- the game's completed list arrives a little after login; look again on every update until it does
    end
  elseif event == "QUEST_TURNED_IN" then
    onTurnIn(a1, a2)
  elseif event == "PLAYER_LEVEL_UP" then
    -- a moment later, once the XP bar has caught up
    local level = a1
    if Run.Get() and level then C_Timer.After(1, QB.Safe(function() Run.Offer("level", level) end, "run: level up")) end
  elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
    -- only the hearthstone (and astral recall) matter: the route can't use it again this run
    if a1 ~= "player" or not (a3 == 8690 or a3 == 556) then return end
    if Run.Get() then Run.Get().hearthUsed = true end
  elseif event == "UNIT_AURA" then
    -- only the sleeping bag's Well Rested changes a plan
    if a1 ~= "player" then return end
    local rested = API.HasWellRested() and true or false
    if rested == QB.lastRested then return end
    QB.lastRested = rested
  elseif event == "PLAYER_XP_UPDATE" then
    -- kills move the bar all the time: what shows it is refreshed when it has moved a fiftieth of a level (the routes are
    -- planned again for a level, not for the XP within one: the signature above)
    local T = QB.Data.TO_NEXT
    local lvl = UnitLevel("player") or 1
    local step = math.floor((UnitXP("player") or 0) * 50 / (T[lvl] or 1))
    if step == QB.xpStep then return end
    QB.xpStep = step
  elseif event == "BANKFRAME_OPENED" then
    QB.bankOpen = true
    Bank.Scan()
  elseif event == "BANKFRAME_CLOSED" then
    Bank.Scan()
    QB.bankOpen = false
  elseif event == "PLAYERBANKSLOTS_CHANGED" or (event == "BAG_UPDATE_DELAYED" and QB.bankOpen) then
    -- moving a stack fires this for every slot: scan once, a moment later
    if QB.bankScanSoon then return end
    QB.bankScanSoon = true
    C_Timer.After(0.5, QB.Safe(function()
      QB.bankScanSoon = false
      if QB.bankOpen then Bank.Scan() end
      QB:MarkDirty()
    end, "bank scan"))
    return
  end
  QB:MarkDirty()
end, "game event"))

for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "PLAYER_LOGOUT", "QUEST_LOG_UPDATE", "QUEST_TURNED_IN", "QUEST_ACCEPT_CONFIRM",
  "QUEST_ACCEPTED", "QUEST_REMOVED", "BAG_UPDATE_DELAYED", "PLAYER_LEVEL_UP", "PLAYER_XP_UPDATE",
  "ZONE_CHANGED_NEW_AREA", "UNIT_AURA", "HEARTHSTONE_BOUND", "UNIT_SPELLCAST_SUCCEEDED", "QUEST_DETAIL", "QUEST_COMPLETE",
  "QUEST_PROGRESS", "QUEST_GREETING", "GOSSIP_SHOW",
  "BANKFRAME_OPENED", "BANKFRAME_CLOSED", "PLAYERBANKSLOTS_CHANGED",
  "PLAYER_DEAD", "PLAYER_UNGHOST", "PLAYER_ALIVE", "TRAINER_SHOW", "QUEST_FINISHED", -- (the Guide: your corpse, your trainer, the reward window shut, Guide.lua)
  "PLAYER_REGEN_ENABLED" }) do -- (the step frame's secure item button, changed once a fight is over, StepFrame.lua)
  if (e == "UNIT_AURA" or e == "UNIT_SPELLCAST_SUCCEEDED") and frame.RegisterUnitEvent then
    pcall(frame.RegisterUnitEvent, frame, e, "player") -- not every unit in sight
  else
    pcall(frame.RegisterEvent, frame, e)
  end
end

----------------------------------------------------------------------------
-- slash
----------------------------------------------------------------------------
SLASH_QUESTBANK1 = "/questbank"
SLASH_QUESTBANK2 = "/qb"
local slash
SlashCmdList.QUESTBANK = function(msg) QB.Try("/qb " .. tostring(msg or ""), slash, msg) end
slash = function(msg)
  msg = (msg or ""):gsub("^%s+", ""):gsub("%s+$", "")
  local cmd, rest = msg:match("^(%S*)%s*(.-)$")
  cmd = (cmd or ""):lower()
  if cmd == "export" then
    local done, inLog = QB:Snapshot("manual")
    QB:Print(done .. " completed quests and " .. inLog .. " in your log saved. Type /reload to write the file.")
  elseif cmd == "reset" then
    QB:Settings().pos, QB:Settings().post.pos = nil, nil
    if QB.UI.frame then QB.UI.frame:ClearAllPoints(); QB.UI.frame:SetPoint("CENTER") end
    if QB.UI.postFrame then QB.UI.postFrame:ClearAllPoints(); QB.UI.postFrame:SetPoint("TOP", 0, -120) end
  elseif cmd == "minimap" and rest == "debug" then
    -- the minimap's far view, its ground and the quest's areas, for a report
    if QB.MiniView then QB.MiniView.Debug() end
  elseif cmd == "minimap" and rest == "reset" then
    -- the minimap's own size and place again, other addons' buttons back on its rim
    if QB.Mini then QB.Mini.ResetFree() end
    QB:Print("The minimap is back to the game's size and place, and its buttons are on the rim.")
  elseif cmd == "minimap" then
    local m = QB:Settings().minimap
    m.hide = not m.hide
    if QB.Minimap then QB.Minimap:Update() end
  elseif (cmd == "sparkle" or cmd == "sparkles" or cmd == "glow") and QB.Glow then
    -- the interact light (Glow.lua): reset puts the game's settings it changed back and switches it off
    QB.Glow.Command(rest)
  elseif cmd == "route" then
    QB.UI:Open(3)
  elseif cmd == "prep" or cmd == "plan" or cmd == "available" then
    QB.UI:Open(2)
  elseif cmd == "party" then
    QB.UI:Open(4)
  elseif cmd == "start" then
    QB:Recompute(true); Run.Start()
  elseif cmd == "stop" then
    Run.Stop()
  elseif cmd == "post" then
    QB.UI:PostDialog(Run.PostText("status"))
  elseif cmd == "arrow" then
    local want = rest:lower():gsub("^%s+", ""):gsub("%s+$", "")
    if QB.Arrow.MODES[want] then
      QB.Arrow:SetMode(want)
      if not QB:Settings().arrow then QB.Arrow:Set(true) end
      QB:Print("The arrow points at " .. QB.Arrow.MODES[want] .. ".")
    elseif want == "on" or want == "off" then
      QB.Arrow:Set(want == "on")
      QB:Print(want == "on" and ("Direction arrow on: it points at " .. QB.Arrow.MODES[QB.Arrow.Mode()] .. ".") or "Direction arrow off.")
    elseif want == "travel" or want == "straight" then
      QB:Settings().arrowTravel = want == "travel"
      QB:Print(want == "travel" and "The arrow shows the way step by step: the flight paths you know, boats, zeppelins, the tram and your hearthstone. /qb way lists the steps."
        or "The arrow points straight at what it points at. /qb arrow travel shows the way step by step again.")
    else
      QB.Arrow:Set(not QB:Settings().arrow)
      QB:Print(QB:Settings().arrow and ("Direction arrow on: it points at " .. QB.Arrow.MODES[QB.Arrow.Mode()] .. ". Right-click it to choose: the route, the nearest hand-in or pick-up, or where you last clicked; /qb arrow route, handin, pickup or pin does the same. Drag it where you like.") or "Direction arrow off.")
    end
  elseif cmd == "buffs" and QB.Camp then
    -- the missing-buffs banner, now (Camp.lua)
    QB.Camp.Command()
  elseif cmd == "trace" and QB.Target then
    -- not listed anywhere: why the route and the arrow change, for a report (Target.lua)
    QB.Target.TraceCommand(rest, function(m) QB:Print(m) end)
  elseif cmd == "way" and QB.Travel then
    -- the steps to what the arrow points at, the flight paths QuestBank counts on, and the hearthstone
    for _, line in ipairs(QB.Travel.WayLines()) do QB:Print(line) end
  elseif cmd == "legacy" and QB.Legacy then
    -- every Legacy perk's rank, and what QuestBank counts with (Legacy.lua)
    if rest == "read" then QB.Legacy.Read() end
    for _, line in ipairs(QB.Legacy.Report()) do QB:Print(line) end
  elseif cmd == "discoveries" then
    local nq, nn, nc = QB.Discover.Count()
    local function n(k, one, many) return k == 1 and ("1 " .. one) or (k .. " " .. many) end
    local game = ""
    if QB.Game and QB.Game.On() then
      local ni, ns = QB.Game.Count()
      game = ", " .. n(ni, "item", "items") .. ", " .. n(ns, "spellbook", "spellbooks")
      if QB.Loot then
        local nl = QB.Loot.Count()
        game = game .. ", " .. n(nl, "drop source", "drop sources")
      end
    end

    QB:Print(string.format("Noted in game so far: %s, %s, %s%s. They stay in your saved file, QuestBank.lua. Upload it at foreverrank.com/questbank/, or let QuestBank Uploader send it on Windows, and it goes into the next release for everyone.",
      n(nq, "quest", "quests"), n(nn, "quest NPC", "quest NPCs"), n(nc, "chain step", "chain steps"), game))
  elseif cmd == "survey" and QB.Survey then
    -- what the quest survey has asked the game on this build (Survey.lua); find <text>: the surveyed quests whose title
    -- has the text, with their rewards
    local sub, text = rest:match("^(%S*)%s*(.-)$")
    if (sub or ""):lower() == "find" then
      QB.Survey.Find(text, function(m) QB:Print(m) end)
    else
      QB.Survey.Report(function(m) QB:Print(m) end)
    end
  elseif cmd == "update" or cmd == "version" then
    QB:Print("You run QuestBank " .. QB.version .. (QB.newest and (". Newest seen: " .. QB.newest.version .. " (" .. (QB.newest.who or "?") .. ").") or "."))
    QB.UI:CopyLink("QuestBank download page", QB.DOWNLOAD)
  elseif cmd == "settings" or cmd == "options" then
    QB.UI:Open(5)
  elseif cmd == "sync" and QB.Sync then
    if rest ~= "" then QB.Sync:Whisper(rest) else QB.Sync:Broadcast(true) end
  elseif cmd == "pins" and QB.Pins then
    QB.Pins:Toggle()
  elseif cmd == "icons" and QB.QuestMap then
    QB.QuestMap:Toggle()
  elseif cmd == "next" and QB.Pins then
    QB.Pins:PinNext(true)
  elseif cmd == "guide" then
    -- the Guide on or off (the player asks: one line answers)
    local s = QB:Settings().guide
    s.on = not s.on
    if s.on and QB:Settings().welcome == "ask" then
      -- a 5.x save never asked: the command is the answer: no question, the frame, the arrow and 6.0's two
      -- switches as Yes gives them (StepFrame.lua)
      local all = QB:Settings()
      all.welcome, s.frame, all.arrow, all.minimapGivers, all.tipProgress = nil, true, true, true, true
      if QB.Arrow then QB.Arrow:Set(true) end
      if QB.Mini and QB.Mini.Invalidate then QB.Mini.Invalidate() end
    end
    QB:MarkDirty()
    if QB.StepFrame then QB.StepFrame.Apply() end
    QB:Print(s.on and "QuestBank is guiding you: the step frame and the arrow lead; /qb guide turns it off." or "The Guide is off. /qb guide turns it on; the window and its pages work as before.")
  elseif cmd == "step" then
    -- the step frame shown or hidden
    local s = QB:Settings().guide
    s.frame = not s.frame
    if QB.StepFrame then QB.StepFrame.Apply() end
  elseif cmd == "errors" then
    if rest == "clear" then
      QuestBankDB.errors = {}
      if type(QuestBankDB.diag) == "table" then QuestBankDB.diag.blocked = nil end
      QB:Print("Error list cleared.")
    elseif QB.UI then
      QB.UI:ShowErrors()
    end
  elseif cmd == "map" or cmd == "maps" then
    -- the Map page (MapPage.lua), on a zone when one is named; another name, that dungeon in the journal. /qb map game
    -- gives the Map key and the sidebar back to the game's map (Settings brings QuestBank's back)
    local MP = QB.MapPage
    local zone = rest ~= "" and MP.Find(rest)
    if rest:lower() == "game" then
      QB:Settings().mapPage = false
      if QB.UI.frame and QB.UI.tab == 8 then QB.UI:ShowTab(QB.UI.lastTab or 1) end
      QB:Print("The Map key and the sidebar's Map open the game's world map now. Settings turns QuestBank's map back on.")
    elseif rest ~= "" and not (zone and MP.On()) then
      QB.DMap.Command(rest)
    elseif MP.On() then
      QB.UI:Open(8)
      if zone then MP.Go(zone, "user") end
    else
      QB.UI.OpenMap()
    end
  elseif cmd == "journal" then
    QB.DMap.Command(rest)
  elseif cmd == "bigmap" or cmd == "map-open" then
    -- the Map: the game's world map on your zone (bigmap: the command of the minimap's old big map)
    if QB.UI and QB.UI.OpenMap then QB.UI.OpenMap() end
  elseif cmd == "events" then
    -- not listed anywhere: the event probe's counts (Observe.lua), for the owner to read off before an upload
    QB.Observe.Report(function(m) QB:Print(m) end)
  elseif cmd == "probe" then
    -- not listed anywhere: the old Windows uploader still tells players to type it. ForeverProbe is retired
    QB.NoteAddons()
    QB:Print(QB.Game and QB.Game.RETIRED or "QuestBank now notes what ForeverProbe did. You can delete the ForeverProbe folder from Interface\\AddOns.")
    QB:Print("The Windows uploader is QuestBank Uploader: foreverrank.com/questbank/")
  elseif cmd == "escort" then
    -- 3.3.4 to 3.6.0 corrected the game's number here (on, off); QuestBank only reads it now (QB.EscortLimit)
    local limit, short = QB.EscortLimit()
    if short then
      QB:Print(string.format("The game's join prompt for escort quests counts %d quests as a full log; yours holds %d. With %d or more its Yes stays grey. QuestBank leaves the game's number alone: an addon that changes it makes the prompt open as that addon, and the game blames it for what it then blocks.",
        limit, QB.LOG_SLOTS, limit))
    elseif limit then
      QB:Print(string.format("The game's join prompt for escort quests counts %d quests as a full log: with fewer, its Yes works.", limit))
    else
      QB:Print("This client's join prompt for escort quests has no quest count QuestBank can read.")
    end
  elseif cmd == "skip" then
    local want = rest:lower():gsub("^%s+", ""):gsub("%s+$", "")
    if want == "" then
      local names = QB:SkipList()
      QB:Print(#names > 0 and ("Skipping " .. table.concat(names, ", ") .. ": nothing there is suggested. /qb skip and a name puts one back; /qb skip none clears the list.")
        or "Nothing skipped. Type /qb skip and a zone, dungeon or continent, like /qb skip Kalimdor or /qb skip Wailing Caverns, and QuestBank stops suggesting quests there. Settings has the same, and each Plan card has a Skip button.")
    elseif want == "none" or want == "clear" then
      local s = QB:Settings()
      s.skipCat, s.skipCont = {}, {}
      if QB.UI then QB.UI:Refresh() end
      QB:Print("Nothing is skipped any more.")
    else
      local label, on = QB:ToggleSkip(want)
      if not label then QB:Print(string.format("No zone, dungeon or continent called \"%s\". /qb skip Kalimdor, /qb skip Eastern Kingdoms, or a zone or dungeon name.", rest))
      elseif on then QB:Print(label .. " is skipped: nothing there is suggested. /qb skip " .. label .. " brings it back.")
      else QB:Print(label .. " is back in the suggestions.") end
    end
  elseif cmd == "done" then
    QB:ReadState()
    local ids = {}
    if tonumber(rest) then
      ids[1] = tonumber(rest)
    elseif rest ~= "" then
      local want = rest:lower()
      for id, name in pairs(D.QN) do
        if name:lower():find(want, 1, true) then ids[#ids + 1] = id end
      end
      table.sort(ids)
    end
    if #ids == 0 then QB:Print("Type /qb done and a quest name or ID, like /qb done Glowing Shard.") end
    for i = 1, math.min(6, #ids) do
      local id = ids[i]
      local q = Q.Get(id)
      local inList, flag, count = API.DoneSources(id)
      QB:Print(string.format("%d %s: %s. The game's list of %d completed quests: %s. The quest's own flag: %s.", id,
        D.QN[id] or "?", q and QB:Status(q).text or "not in QuestBank's catalog", count, inList and "yes" or "no",
        flag == nil and "can't ask" or (flag and "yes" or "no")))
    end
  else
    QB.UI:Toggle()
  end
end
